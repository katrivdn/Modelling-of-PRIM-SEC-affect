#################################################
## INTERNSHIP 2020/21 KOBE DESENDER            ##
## Affect and decision making                  ##
## Study 2: incidental affect                  ##
## does an affective prime affect the          ##
## judgement of a subsequent, ambiguous target?##
#################################################
## overview of the results:
##
## 1. respPos
## (a) main effect of prime
## higher positive response rate when prime is positive, compared to scrambled, 
## compared to negative. 
## 2. RT
## (a) effect of prime
## prime SCR RT are slower compared to RT prime negative and prime positive
## (b) main effect of TrialN, faster RTs for higher trial number.

library(lme4)
library(lmerTest)
library(effects)
library(MuMIn)
library(lmerTest)

filepath = "C:\\Users\\Katri\\Documents\\Unief\\experimentele psy\\INTERNSHIP\\PRIMSEC affect openCode - GitHub\\data\\"
# import data
data.long = read.csv(file = paste(filepath,"batch1\\merged data\\study2.csv",sep=""))
head(data.long)
colnames(data.long)
data.long <- subset(data.long, TrialType!='FILLER') ## remove fillers from dataset
contrasts(relevel(data.long$prime_cond,"SCR"))

# analysis respPos: did the participant judge the target as being positive? And could that be predicted by the affective prime?
model1 <- glmer(respPos~prime_cond+(1|participant)+(1|priming),data=data.long,family=binomial)
model2 <- glmer(respPos~prime_cond+(prime_cond+1|participant)+(1|priming),data=data.long,family=binomial,control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)))
## is singular
## plot the effect
plot(effect('prime_cond',model1))
## testStat
Anova(model1)
summary(model1)
# how much of the variance can we explain with this last model?
r.squaredGLMM(model1)
fixef(model1)


# analysis of RT
model1 <- lmer(response.rt~prime_cond+(1|participant)+(1|priming),data=data.long,control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)))
# is singular
model1 <- lmer(response.rt~prime_cond+(1|participant),data.long)
model2 <- lmer(response.rt~prime_cond+TrialN+(1|participant),data=data.long,control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)))
anova(model1,model2)
## yes
model3 <- lmer(response.rt~prime_cond+TrialN+(1+prime_cond|participant),control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)),data=data.long)
## singular
## check assumptions for normal distribution of residuals
plot(model2)
qqmath(model2)

## change to log scale
data.long$RTlog <- log(data.long$response.rt)
# modelling again:
model1 <- lmer(RTlog~prime_cond+(1|participant),data=data.long)
model2 <- lmer(RTlog~prime_cond+TrialN+(1|participant),data=data.long)
anova(model1,model2)
## yes
model3 <- lmer(RTlog~prime_cond+TrialN+(1+prime_cond|participant),data=data.long,control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)))
##
anova(model2,model3)
# no

## check again assumptions for normal distribution of residuals
plot(model2)
qqmath(model2)

## plot the effect
plot(effect('prime_cond',model2))
plot(effect('TrialN',model2))
# look at the results of this last model
Anova(model2)
summary(model2)
# how much of the variance can we explain with this last model?
r.squaredGLMM(model2)
fixef(model2)


## statistical test
anova(model2)
summary(model2)
