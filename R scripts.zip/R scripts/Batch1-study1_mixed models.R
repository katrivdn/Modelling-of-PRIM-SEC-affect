#################################################
## INTERNSHIP 2020/21 KOBE DESENDER            ##
## Affect and decision making                  ##
## Study 1: look at whether affective objects  ##
## are processed more efficiently compared to  ##
## neutral objects.                            ##
#################################################
## overview of the results:
##
## 1. accuracy 
## (a) Main effect of difficulty and overbalance
## i.e. how more difficult the trial, how lower the ACC
## i.e. an overbalance of neutral faces resulted in higher accuracies
## (b) an interaction effect between difficulty and overbalance
## i.e. slope parameter for difficulty is slightly more pronounced in the affective
## compared to the neutral condition (small effect)
## (c) an interaction effect between overbalance and condition
## i.e. higher slope for overbalance when the condition is negative 
## (greater difference in accuracy between neutral and negative faces vs. neutral and positive faces); 
## note: the accuracy for neutral faces is however higher in the positive condition. 
## (d) an three-way interaction effect between difficulty, overbalance and condition
## 
## 2. reaction times
## (a) main effect of difficulty (higher RT more difficult)
## (b) interaction effect (p = 0.007) of overbalance and cond
## slower RT in overbalance neutral vs. overbalance affective when condition is negative
## no difference in RT for neutral vs. affective when condition is positive. 

#to for effect function to work: 
#install.packages("effects")
#install.packages("lme4")
library(lme4)
library(lmerTest)
library(effects)
library(MuMIn)
library(car)
library(lattice)
filepath = "C:\\Users\\Katri\\Documents\\Unief\\experimentele psy\\INTERNSHIP\\PRIMSEC affect openCode - GitHub\\data\\"
# import data
data.long = read.csv(file = paste(filepath,"batch1\\merged data\\study1.csv",sep=""))
head(data.long)
data.long <- subset(data.long, overbalance!='even')

## --> for the analysis of mixed models, I followed the steps as formulated in: 
## Barr, Dale J. "Random effects structure for testing interactions in linear mixed-effects models." Frontiers in psychology 4 (2013): 328.

# analyse the data for accuracy using a general linear mixed effects model
## 1. First model, start with condition of interest
ACC_1 <- glmer(response.corr ~ difficulty*overbalance*Cond+(1|participant),family = binomial, data=data.long,control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)))
# yup
ACC_2 <- glmer(response.corr ~ difficulty*overbalance*Cond+(1+difficulty|participant),family = binomial, data=data.long,control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)))
# model has singular fit
ACC_3 <- glmer(response.corr ~ difficulty*overbalance*Cond+(1+overbalance|participant),family = binomial, data=data.long,control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)))
# model has singular fit
ACC_4 <- glmer(data=data.long,response.corr~difficulty*overbalance*Cond+(1+Cond|participant),family = binomial,control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)))
## model has singular fit

## plot the effect
plot(effect('overbalance',ACC_1))
plot(effect('difficulty:overbalance',ACC_1))
plot(effect('overbalance:Cond',ACC_1))
plot(effect('Cond',ACC_1))
plot(effect('difficulty:overbalance:Cond',ACC_1))

## let us now have a look at ACC_1, what is the effect of overbalance on accuracy?
summary(ACC_1)
Anova(ACC_1)
# how much of the variance can we explain with this last model?
r.squaredGLMM(ACC_1)
fixef(ACC_1)




# analyse the data for RTs using a general linear mixed effects model
## 1. First model, start with condition of interest
data.corr <- subset(data.long, response.corr!=0)
RT_1 <- lmer(response.rt ~ difficulty*overbalance*Cond+(1|participant), data=data.corr)
RT_2 <- lmer(response.rt ~ difficulty*overbalance*Cond+(1+difficulty|participant), data=data.corr)
## RT_2 is singular 
RT_3 <- lmer(response.rt ~ difficulty*overbalance*Cond+(1+overbalance|participant), data=data.corr)
anova(RT_1,RT_3)
## nope
RT_4 <- lmer(response.rt ~ difficulty*overbalance*Cond+(1+Cond|participant), data=data.corr)
anova(RT_1,RT_4)
# yup
## check residuals to see if they meet our assumptions
plot(RT_4)
plot(data.corr$response.rt,residuals(RT_4))
qqmath(RT_4)

## residuals aren't normally distributed; so change RT to log scale
data.corr$RTlog <- log(data.corr$response.rt)
## 1. First model, start with condition of interest
RT_1 <- lmer(RTlog ~ difficulty*overbalance*Cond+(1|participant), data=data.corr)
RT_2 <- lmer(RTlog ~ difficulty*overbalance*Cond+(1+difficulty|participant), data=data.corr)
## RT_2 is singular 
RT_3 <- lmer(RTlog ~ difficulty*overbalance*Cond+(1+overbalance|participant), data=data.corr)
anova(RT_1,RT_3)
## nope
RT_4 <- lmer(RTlog ~ difficulty*overbalance*Cond+(1+Cond|participant), data=data.corr)
anova(RT_1,RT_4)
## verify again for normal distribution of residuals
plot(RT_4)
str(re<-ranef(RT_4,condVar = TRUE))
qqmath(RT_4) 

## plot the effect
plot(effect('difficulty',RT_4))
plot(effect('overbalance:Cond',RT_4))
plot(effect('Cond',RT_4))

## let us now have a look at RT_4 what is the effect of overbalance on accuracy?
summary(RT_4)
anova(RT_4)
# how much of the variance can we explain with this last model?
r.squaredGLMM(RT_4)
fixef(RT_4)

