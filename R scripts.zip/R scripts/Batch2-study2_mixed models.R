#################################################
## INTERNSHIP 2020/21 KOBE DESENDER            ##
## Affect and decision making                  ##
## Study 2: incidental affect   - BATCH2       ##
## does an affective prime affect the          ##
## judgement of a subsequent, ambiguous target?##
#################################################
## overview of the results:
##
## 1. respPos
## (a) main effect of prime condition, with higher positive response rate 
## when the prime was positive, compared to scramble and negative.
##
## 2. RT
## (a) main effect of prime condition: scramble primes lead to slower reaction times,
## compared to positive and finally negative responding.
## (b) main effect of Trial Number, with faster reaction times for higher TrialN
##

library(lme4)
library(lmerTest)
library(effects)
library(MuMIn)
library(lmerTest)

filepath = "C:\\Users\\Katri\\Documents\\Unief\\experimentele psy\\INTERNSHIP\\PRIMSEC affect openCode - GitHub\\data\\"
# import data
data.long = read.csv(file = paste(filepath,"batch2\\merged data\\study2(batch2).csv",sep=""))
head(data.long)
colnames(data.long)
data.long <- subset(data.long, TrialType!='FILLER') ## remove fillers from dataset
contrasts(relevel(data.long$prime_cond,"SCR"))

# analysis respPos: did the participant judge the target as being positive? And could that be predicted by the affective prime?
model1 <- glmer(respPos~prime_cond+(1|participant)+(1|priming),data=data.long,family=binomial,control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)))
model2 <- glmer(respPos~prime_cond+(1+prime_cond|participant)+(1|priming),data=data.long,family=binomial,control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)))
## compare model 1 to model 2
anova(model1,model2)
## yes

## plot the effect
plot(effect('prime_cond',model2))
## testStat
anova(model2)
summary(model2)
# how much of the variance can we explain with this last model?
r.squaredGLMM(model2)
fixef(model2)

# analysis of RT
model1 <- lmer(response.rt~prime_cond+(1|participant)+(1|priming),data=data.long)
#singular
model1 <- lmer(response.rt~prime_cond+(1|participant),data=data.long)
model2 <- lmer(response.rt~prime_cond+TrialN+(1|participant),data=data.long,control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)))
anova(model1,model2)
## yes
model3 <- lmer(response.rt~prime_cond+TrialN+(1+prime_cond|participant),control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)),data=data.long)
anova(model2,model3)
## yes

## check assumptions for normal distribution of residuals
plot(model3)
qqmath(model3)

## change to log scale
data.long$RTlog <- log(data.long$response.rt)
# modelling again:
model1 <- lmer(RTlog~prime_cond+(1|participant),data=data.long)
model2 <- lmer(RTlog~prime_cond+TrialN+(1|participant),data=data.long)
anova(model1,model2)
## yes
model3 <- lmer(RTlog~prime_cond+TrialN+(1+prime_cond|participant),data=data.long,control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)))
## compare
anova(model3,model2)
##yes
## check again assumptions for normal distribution of residuals
plot(model3)
qqmath(model3)

## plot the effect
plot(effect('prime_cond',model3))
plot(effect('TrialN',model3))

# look at the results of this last model
anova(model3)
summary(model3)
# how much of the variance can we explain with this last model?
r.squaredGLMM(model2)
fixef(model2)

