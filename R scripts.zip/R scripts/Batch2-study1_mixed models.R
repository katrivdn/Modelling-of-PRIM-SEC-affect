#################################################
## INTERNSHIP 2020/21 KOBE DESENDER            ##
## Affect and decision making                  ##
## Study 1: look at whether affective objects  ##
## are processed more efficiently compared to  ##
## neutral objects.                            ##
## --> this is batch 2                         ##
#################################################
## overview of the results:
##
## 1. accuracy 
## (a) higher accuracy for majority of neutral faces compared to
## either happy or angry faces - no significant difference between 
## happy or angry faces. 
## (b) interaction effect: accuracy was higher for neutral faces especially
## for easy trials.
## 
## 2. reaction times
## (a) only a main effect of difficulty.

#to for effect function to work: 
#install.packages("effects")
#install.packages("lme4")
library(lme4)
library(lmerTest)
library(effects)
library(MuMIn)
library(car)
library(lattice)
filepath = "C:\\Users\\Katri\\Documents\\Unief\\experimentele psy\\INTERNSHIP\\PRIMSEC affect openCode - GitHub\\data\\"
# import data
data.long = read.csv(file = paste(filepath,"batch2\\merged data\\study1.csv",sep=""))
head(data.long)

## --> for the analysis of mixed models, I followed the steps as formulated in: 
## Barr, Dale J. "Random effects structure for testing interactions in linear mixed-effects models." Frontiers in psychology 4 (2013): 328.

# analyse the data for accuracy using a general linear mixed effects model
## 1. First model, start with condition of interest
ACC_1 <- glmer(response.corr ~ difficulty*overbalance+(1|participant),family = binomial, data=data.long,control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)))
# yup
ACC_2 <- glmer(response.corr ~ difficulty*overbalance+(1+difficulty|participant),family = binomial, data=data.long,control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)))
# model has singular fit
ACC_3 <- glmer(response.corr ~ difficulty*overbalance+(1+overbalance|participant),family = binomial, data=data.long,control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)))
# compare ACC_3 to ACC_1
anova(ACC_1,ACC_3)
## ACC_3 better fit

## let us now have a look at ACC_3, what is the effect of overbalance on accuracy?
summary(ACC_3)
# how much of the variance can we explain with this last model?
r.squaredGLMM(ACC_3)
fixef(ACC_3)
## plot the effect
plot(effect('overbalance',ACC_3))
plot(effect('difficulty:overbalance',ACC_3))
Anova(ACC_3)

# analyse the data for RTs using a general linear mixed effects model
## 1. First model, start with condition of interest
data.corr <- subset(data.long, response.corr!=0) ## only look at correct trials
RT_1 <- lmer(response.rt ~ difficulty*overbalance+(1|participant), data=data.corr,control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)))
RT_2 <- lmer(response.rt ~ difficulty*overbalance+(1+difficulty|participant), data=data.corr,control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)))
## RT_2 is singular 
RT_3 <- lmer(response.rt ~ difficulty*overbalance+(1+overbalance|participant), data=data.corr,control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)))
anova(RT_1,RT_3)
## yes

## check residuals to see if they meet our assumptions
plot(RT_3)
plot(data.corr$response.rt,residuals(RT_3))
qqmath(RT_3)

## residuals aren't normally distributed; so change RT to log scale
data.corr$RTlog <- log(data.corr$response.rt)
## 1. First model, start with condition of interest
RT_1 <- lmer(RTlog ~ difficulty*overbalance+(1|participant), data=data.corr)
RT_2 <- lmer(RTlog ~ difficulty*overbalance+(1+difficulty|participant), data=data.corr)
## RT_2 is singular 
RT_3 <- lmer(RTlog ~ difficulty*overbalance+(1+overbalance|participant), data=data.corr,control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=10000)))
anova(RT_1,RT_3)
## yes

## verify again for normal distribution of residuals
plot(RT_4)
str(re<-ranef(RT_4,condVar = TRUE))
qqmath(RT_4) 

## plot the effect
plot(effect('difficulty',RT_3))
plot(effect('overbalance',RT_3))

## significance testing
summary(RT_3)
anova(RT_3)
# how much of the variance can we explain with this last model?
r.squaredGLMM(RT_3)
fixef(RT_3)

