# -*- coding: utf-8 -*-
"""
Created on Mon Dec  7 09:25:31 2020

STUDY1 - first batch: data-clean up and visualization of the data.
This script gives an overview of the following aspects of the experiment:
    * the distribution of RTs overall
    * the distribution of RTs per participant per trial (to check whetehr there is an effect per trial)
    * difference bewteen RTs distribution before and after removing outliers
    * The RT and choice / accuracy distribution for our conditions of interest  (depending on whether it is experiment 1 or 2)
Author: Katrien Vandenbroeck
Date: December 2020
Project: Internship project MA2 

@author: Katrien Vandenbroeck
"""
# =============================================================================
# Experiment 1
# short description: looking at the effects of emotional faces on reaction time and accuracy. 
# design: 8 faces, sometimes majority of emotional sometimes of neutral faces. 
# 3 difficulty conditions: hard/even/easy. 
# =============================================================================

import pandas as pd
import os
from os import listdir
import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns
import numpy as np
import matplotlib.gridspec as gridspec
pd.set_option('display.max_rows', 10) ## set limit to print
pd.set_option('display.max_columns', 5) ## set limit to print
mpl.style.use('seaborn')
mpl.style.use('tableau-colorblind10')
#%% import data for study 1
## define path to data
path = os.getcwd()+r'\data\batch1\raw data'
all_files = [f for f in listdir(path) if 'study1' in f and '.csv' in f]
print('number of datafiles for study 1: {0}'.format(len(all_files)))
li = []
# concatenate all datafiles into one file:
for filename in all_files:
    df = pd.read_csv(path+'\\'+filename)
    df = df
    li.append(df)
d1 = pd.concat(li, axis=0, ignore_index=True)
## select only experimental trials (ignore training)
data = d1.loc[d1['StartExp']==True]
## select only relevant columns
data = data[['response.keys', 'response.corr','StartExp', 'aff', 'Cond', 'difficulty','study', 'overbalance','CorResp',
       'Leeftijd*', 'participant', 'Gender*', 'date', 'expName', 'response.rt', 'Experimental_trial.thisTrialN']]

#%% remove trials for which RTs are bellow 100ms 
print("remove trials RTs<100ms, i.e. {0:2f}% of trials".format(len(data.loc[data['response.rt']<=0.100])/len(data)*100))
data = data.loc[data['response.rt']>0.100]

#%% add index value for trials
trial_nb = [range(0,len(values)) for participant,values in data.groupby('participant')]
data['TrialN'] = np.concatenate(trial_nb)

#%% overall RT distributions
sns.distplot(a=data['response.rt'][data['response.rt']>0], hist = True, kde = True,
                     kde_kws = {'shade': True, 'linewidth': 3},label=['d','k'])

#%% view mean rt and response accruacy for each participant
for d,values in data.groupby('participant'):
    print('--------')
    p = sns.lmplot(data=values, x = 'TrialN', y='response.rt')
    p.set_axis_labels(d)
    print(str(d)+'meanACC: '+str(values['response.corr'].mean()))
    print(str(d)+'meanACC per cond:' + str(values.groupby('difficulty')['response.corr'].mean()))
# NOTES
## (1) 8 participants showed random responses: pt 27766 (ACC=0.49); pt28837 (ACC=0.58); pt 28978 (ACC=0.54); pt 29092 (ACC=0.54)
##                          pt 292178 (ACC=0.57); pt29554 (ACC=0.62, maar easy --> ACC 0.66); pt29677 (ACC = 0.5); pt29917(ACC = 0.50)
## (2) many participants performed poorly on the hard trials --> maybe not gathering all necessary evidence, but focussing only on a small region.
# remove participants performance was random:
delete = [27766,28837,28978,29092,292178,29554,29677,29917]
data = data[~data.participant.isin(delete)]
data.groupby('participant') ['response.corr'].mean()
data.groupby('difficulty')['response.corr'].mean()
print("total number of pt exp1: " + str(len(np.unique(data['participant']))))

#%% mean age and gender of participants
print('mean age: ' + str(data['Leeftijd*'].mean()))
sex = []
for part, s in data.groupby('participant')['Gender*']:
    sex.append(list(s)[0])
print('percentage F: ' + str(sex.count('V')/len(sex)))

#%% remove outliers greater than 3.5 seconds
outliers = []
for d,values in data.groupby('participant'):
    outliers.append(values['response.rt']<3.5)
#how many trials removed?
left = sum(np.concatenate(outliers))
trials_kept = (1-left/len(data))*100
print("removed outliers, i.e. {:.2f}% of trials".format(trials_kept))
data  = data[np.concatenate(outliers)]

#%% check again for outliers
for d,values in data.groupby('participant'):
    plt.title(d)
    sns.lmplot(data=values, x = 'TrialN', y='response.rt')

#%%
# =========#
# PLOTTING #
# =========#
plt.figure(figsize=(14,7))
gs = gridspec.GridSpec(1, 2,wspace=0.2)
#1. ACC & RT mean
## A/ Accuracy
plt.subplot(gs[0,0:1])
plt.ylabel('ACC')
plt.xticks([])
plt.title('A',size=20,position=(-0.1,0))
c = ['#66a61e','#7570b3']
i = 0
for d,values in data.groupby('overbalance'):
    if d!= 'even':
        meanACCpp = np.array(values.groupby('participant')['response.corr'].mean())
        meanACC   = meanACCpp.mean() ## overall mean
        sdACC     = meanACCpp.std()  ##standard deviation
        plt.vlines(d,meanACC-sdACC,meanACC+sdACC,linestyles = '-',color=c[i])
        plt.hlines(meanACC-sdACC,-0.05+i,0.05+i,linestyles = '-',color=c[i])
        plt.hlines(meanACC+sdACC,-0.05+i,0.05+i,linestyles = '-',color=c[i])
        plt.scatter(np.random.normal(i,0.04,len(meanACCpp)),meanACCpp,color = c[i],label=d,alpha=0.5)
        plt.scatter([d],meanACC,color = c[i])
        plt.legend()
        i +=1
## B/ RTs
plt.subplot(gs[0,1:2])
plt.ylabel('RTs')
plt.ylim(0.5,1.7)
plt.xticks([])
plt.title('B',size=20,position=(-0.1,0))
i = 0
for d,values in data.groupby('overbalance'):
    if d!= 'even':
        meanRTpp = np.array(values.groupby('participant')['response.rt'].mean())
        meanRT   = meanRTpp.mean() ## overall mean
        sdRT     = meanRTpp.std()  ##standard deviation
        plt.vlines(d,meanRT-sdRT,meanRT+sdRT,linestyles = '-',color=c[i])
        plt.hlines(meanRT-sdRT,-0.05+i,0.05+i,linestyles = '-',color=c[i])
        plt.hlines(meanRT+sdRT,-0.05+i,0.05+i,linestyles = '-',color=c[i])
        plt.scatter(np.random.normal(i,0.04,len(meanACCpp)),meanRTpp,color = c[i],alpha=0.5)
        plt.scatter([d],meanRT,color = c[i])

        i +=1       

#2. present the data distribution
data['RT'] = data['response.rt']
data.loc[data['response.corr']==0, 'RT'] = -data['response.rt']
sns.displot(data[data['overbalance']!='even'],x="RT", hue="overbalance",kind="kde", fill=True,height=7, aspect=2,palette = c,hue_order=['affective','neutral'])

