# -*- coding: utf-8 -*-
"""
Created on Mon Dec  7 09:25:31 2020

STUDY1 - first batch: data-clean up and visualization of the data.
This script gives an overview of the following aspects of the experiment:
    * the distribution of RTs overall
    * the distribution of RTs per participant per trial (to check whetehr there is an effect per trial)
    * difference bewteen RTs distribution before and after removing outliers
    * The RT and choice / accuracy distribution for our conditions of interest  (depending on whether it is experiment 1 or 2)
Author: Katrien Vandenbroeck
Date: December 2020
Project: Internship project MA2 

@author: Katrien Vandenbroeck
"""
# =============================================================================
# Experiment 1
# short description: looking at the effects of emotional faces on reaction time and accuracy. 
# design: 8 faces, sometimes majority of emotional sometimes of neutral faces. 
# 3 difficulty conditions: hard/even/easy. 
# =============================================================================

import pandas as pd
import os
from os import listdir
import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns
import numpy as np
pd.set_option('display.max_rows', 10) ## set limit to print
pd.set_option('display.max_columns', 5) ## set limit to print
mpl.style.use('seaborn')
mpl.style.use('tableau-colorblind10')
#%% import data for study 1
## define path to data
path = os.getcwd()+r'\data\batch1\raw data'
all_files = [f for f in listdir(path) if 'study1' in f and '.csv' in f]
print('number of datafiles for study 1: {0}'.format(len(all_files)))
li = []
# concatenate all datafiles into one file:
for filename in all_files:
    df = pd.read_csv(path+'\\'+filename)
    df = df
    li.append(df)
d1 = pd.concat(li, axis=0, ignore_index=True)
## select only experimental trials (ignore training)
data = d1.loc[d1['StartExp']==True]
## select only relevant columns
data = data[['response.keys', 'response.corr','StartExp', 'aff', 'Cond', 'difficulty','study', 'overbalance','CorResp',
       'Leeftijd*', 'participant', 'Gender*', 'date', 'expName', 'response.rt', 'Experimental_trial.thisTrialN']]

#%% remove trials for which RTs are bellow 100ms 
print("remove trials RTs<100ms, i.e. {0:2f}% of trials".format(len(data.loc[data['response.rt']<=0.100])/len(data)*100))
data = data.loc[data['response.rt']>0.100]

#%% add index value for trials
trial_nb = [range(0,len(values)) for participant,values in data.groupby('participant')]
data['TrialN'] = np.concatenate(trial_nb)

#%% overall RT distributions
sns.distplot(a=data['response.rt'][data['response.rt']>0], hist = True, kde = True,
                     kde_kws = {'shade': True, 'linewidth': 3},label=['d','k'])

#%% view mean rt and response accruacy for each participant
for d,values in data.groupby('participant'):
    print('--------')
    p = sns.lmplot(data=values, x = 'TrialN', y='response.rt')
    p.set_axis_labels(d)
    print(str(d)+'meanACC: '+str(values['response.corr'].mean()))
    print(str(d)+'meanACC per cond:' + str(values.groupby('difficulty')['response.corr'].mean()))
# NOTES
## (1) 8 participants showed random responses: pt 27766 (ACC=0.49); pt28837 (ACC=0.58); pt 28978 (ACC=0.54); pt 29092 (ACC=0.54)
##                          pt 292178 (ACC=0.57); pt29554 (ACC=0.62, maar easy --> ACC 0.66); pt29677 (ACC = 0.5); pt29917(ACC = 0.50)
## (2) many participants performed poorly on the hard trials --> maybe not gathering all necessary evidence, but focussing only on a small region.
# remove participants performance was random:
delete = [27766,28837,28978,29092,292178,29554,29677,29917]
data = data[~data.participant.isin(delete)]
data.groupby('participant') ['response.corr'].mean()
data.groupby('difficulty')['response.corr'].mean()
print("total number of pt exp1: " + str(len(np.unique(data['participant']))))

#%% mean age and gender of participants
print('mean age: ' + str(data['Leeftijd*'].mean()))
sex = []
for part, s in data.groupby('participant')['Gender*']:
    sex.append(list(s)[0])
print('percentage F: ' + str(sex.count('V')/len(sex)))

#%% remove outliers greater than 3.5 seconds
outliers = []
for d,values in data.groupby('participant'):
    outliers.append(values['response.rt']<3.5)
#how many trials removed?
left = sum(np.concatenate(outliers))
trials_kept = (1-left/len(data))*100
print("removed outliers, i.e. {:.2f}% of trials".format(trials_kept))
data  = data[np.concatenate(outliers)]

#%% check again for outliers
for d,values in data.groupby('participant'):
    plt.title(d)
    sns.lmplot(data=values, x = 'TrialN', y='response.rt')

#%%
# =========#
# PLOTTING #
# =========#
c = ['#66a61e','#7570b3']
#%%
f, (ax1,ax2) = plt.subplots(nrows=1, ncols=2,figsize=(14,7))
#1. ACC & RT mean
## A/ Accuracy
## aggregate the data
data_agg = data[data['overbalance']!='even'].groupby(['participant','difficulty', 'overbalance','Cond'])['response.corr'].mean().reset_index()

#A1 - condition Positive
# Show each observation with a scatterplot
sns.stripplot(x="difficulty", y="response.corr", hue="overbalance",
              data=data_agg[data_agg['Cond']=='Positive'], dodge=True, alpha=.25, zorder=1,palette=c,ax=ax1)

# Show the conditional means
sns.pointplot(x="difficulty", y="response.corr", hue="overbalance", 
              data=data_agg[data_agg['Cond']=='Positive'],join=False, dodge=0.4,alpha=.25, zorder=1,palette=c,ax=ax1)
# change axis name
handles, labels = ax1.get_legend_handles_labels()
ax1.legend(handles[0:2], labels[0:2], title="overbalance",
          handletextpad=0, columnspacing=1,
          loc="upper right", ncol=2, frameon=True,facecolor='white')
ax1.set(xlabel='', ylabel='ACC',title="Cond: Positive",ylim=[0.3,1])

#A2 - condition Negative
# Show each observation with a scatterplot
sns.stripplot(x="difficulty", y="response.corr", hue="overbalance", 
              data=data_agg[data_agg['Cond']=='Negative'], dodge=True, alpha=.25, zorder=1,palette=c,ax=ax2)

# Show the conditional means
sns.pointplot(x="difficulty", y="response.corr", hue="overbalance", 
              data=data_agg[data_agg['Cond']=='Negative'],join=False, dodge=0.4, alpha=.25, zorder=1,palette=c,ax=ax2)

# change axis name
handles, labels = ax1.get_legend_handles_labels()
ax2.legend([],[], frameon=False)
ax2.set(xlabel='', ylabel='',title="Cond: Negative",ylim=[0.3,1])

f.savefig(r"C:\Users\Katri\Documents\Unief\experimentele psy\INTERNSHIP\2020-21_PRIM_SEC_AFFECT\paper draft\Figures\overviewdata_study1(Batch1)_ACC.pdf")
#%%
## B/ RTs
 ## aggregate the data
data_agg = data[(data['overbalance']!='even')&(data['response.corr']==1)].groupby(['participant','difficulty', 'Cond','overbalance'])['response.rt'].mean().reset_index()
f, (ax1,ax2) = plt.subplots(nrows=1, ncols=2,figsize=(14,7))

#A1 - condition Positive
# Show each observation with a scatterplot
sns.stripplot(x="difficulty", y='response.rt', hue="overbalance",
              data=data_agg[data_agg['Cond']=='Positive'], dodge=True, alpha=.25, zorder=1,palette=c,ax=ax1)

# Show the conditional means
sns.pointplot(x="difficulty", y='response.rt', hue="overbalance", 
              data=data_agg[data_agg['Cond']=='Positive'],join=False, dodge=0.4,alpha=.25, zorder=1,palette=c,ax=ax1)
# change axis name
handles, labels = ax1.get_legend_handles_labels()
ax1.legend(handles[0:2], labels[0:2], title="overbalance",
          handletextpad=0, columnspacing=1,
          loc="upper right", ncol=2, frameon=True,facecolor='white')
ax1.set(xlabel='', ylabel='RT',title="Cond: Positive",ylim=[0.4,1.5])

#A2 - condition Negative
# Show each observation with a scatterplot
sns.stripplot(x="difficulty", y='response.rt', hue="overbalance",
              data=data_agg[data_agg['Cond']=='Negative'], dodge=True, alpha=.25, zorder=1,palette=c,ax=ax2)

# Show the conditional means
sns.pointplot(x="difficulty", y='response.rt', hue="overbalance", 
              data=data_agg[data_agg['Cond']=='Negative'],join=False, dodge=0.4,alpha=.25, zorder=1,palette=c,ax=ax2)
# change axis name
handles, labels = ax1.get_legend_handles_labels()
ax2.legend([],[], frameon=False)
ax2.set(xlabel='', ylabel='',title="Cond: Negative",ylim=[0.4,1.5])
f.savefig(r"C:\Users\Katri\Documents\Unief\experimentele psy\INTERNSHIP\2020-21_PRIM_SEC_AFFECT\paper draft\Figures\overviewdata_study1(Batch1)_RT.pdf")
#%%
#2. present the data distribution
data['RT'] = data['response.rt']
data.loc[data['response.corr']==0, 'RT'] = -data['response.rt']
sns.displot(data[data['overbalance']!='even'],x="RT", hue="overbalance",kind="kde", fill=True,height=7, aspect=2,palette = c,hue_order=['affective','neutral'])

