# -*- coding: utf-8 -*-
"""
Created on Mon Mar  1 13:18:35 2021
Study 2 - batch 2; same as study 2 batch 1 (judge a set of ambiguous faces + aff priming)
but responses were allowed during prime presentation.

@author: Katri
"""
# =============================================================================
# Experiment 2
# short description: looking at the effects of emotional prime on judgement. 
# design: prime + 8 faces, fillers: happy/angry; target: surprised. 
# =============================================================================

import pandas as pd
import os
from os import listdir
import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns
import numpy as np
import matplotlib.gridspec as gridspec
pd.set_option('display.max_rows', 10) ## set limit to print
pd.set_option('display.max_columns', 5) ## set limit to print
mpl.style.use('seaborn')
mpl.style.use('tableau-colorblind10')
#%%
# =============================================================================
# Experiment 2
# short description: looking at the effects of emotional faces on reaction time and accuracy. 
# design: 8 faces, sometimes majority of emotional sometimes of neutral faces. 2 difficulty conditions: hard/easy. 
# =============================================================================
# import data
path = os.getcwd()+r'\data\batch2\raw data'
all_files = [f for f in listdir(path) if 'study2' in f and '.csv' in f]
li = []
for filename in all_files:
    df = pd.read_csv(path+'\\'+filename)
    df = df
    li.append(df)
d1 = pd.concat(li, axis=0, ignore_index=True)
# remove training
data = d1.loc[d1['StartEXP']==True]
# participant positive responding? 1=yes, 0=No
data['respPos'] = (data['response.keys']==data['KeyPress_PT'])*1
# select only relevant columns
data = data[['response.keys', 'response.rt', 'prime_cond', 'target_cond', 'TrialType', 'time','participant',
       'KeyPress_PT', 'Leeftijd*','Gender*','Block_EXP2.thisTrialN', 'Block_EXP2.thisN', 'respPos']]
#%% add index value for trials
trial_nb = [range(0,len(values)) for participant,values in data.groupby('participant')]
data['TrialN'] = np.concatenate(trial_nb)

#%% overall RT distributions
sns.distplot(a=data['response.rt'][data['response.rt']>0], hist = True, kde = True,
                     kde_kws = {'shade': True, 'linewidth': 3},label=['d','k'])

#%% check RT distribution and response to fillers of each participant; remove participants that performed at random (mean ACC bellow 0.7)
remove = []
for d,values in data.groupby('participant'):
    print('--------')
    print(d)
    data_filler = values[values['TrialType']=='FILLER'] 
    corr = (data_filler['target_cond']=='POS')==data_filler['respPos']
    print('ACC for fillers: '+str(corr.mean()))
    if corr.mean()<=0.7:
        print('FILLER rand'+str(d))
        remove.append(d)
    sns.lmplot(data=values, x = 'TrialN', y='response.rt')
    plt.figure()
    for response,subdata in values.groupby('respPos'):
        if response == 1:
            sns.distplot(subdata['response.rt'])
        else:
            sns.distplot(-subdata['response.rt'])
## remove participants for which corr mean is lower than threshold
data = data[~data.participant.isin(remove)]
#%% check accuracy per bins; see whether this decreases. 
bins  = 8
for pt, values in data.groupby('participant'):
    chunck      = np.linspace(0,len(values),bins).astype('int')
    corr_perbin = []
    for i in range(bins-1):
        subdata     = values[chunck[i]:chunck[i+1]]
        data_filler = subdata[subdata['TrialType']=='FILLER'] 
        data_filler['corr'] = (subdata['target_cond']=='POS')==subdata['respPos']
        corr_perbin.append(data_filler['corr'].mean())
    plt.figure()
    plt.ylim(0,1)
    plt.scatter(range(bins-1),corr_perbin,color = 'blue')    
    plt.title(pt)
## Note: each participant had to attend to a total of 48 fillers
#%% check RT per bins; see whether participants 'abandonned' the task
bins  = 20
for pt, values in data.groupby('participant'):
    chunck      = np.linspace(0,len(values),bins).astype('int')
    rt_perbin = []
    for i in range(bins-1):
        subdata     = values[chunck[i]:chunck[i+1]]
        rt_perbin.append(subdata['response.rt'].mean())
    plt.figure()
    plt.ylim(0,3)
    plt.scatter(range(bins-1),rt_perbin,color = 'blue')    
    plt.title(pt)
    
#%% mean age and gender of participants
print("total number of pt exp2: " + str(len(np.unique(data['participant']))))
print("total number of trials exp2: " + str(len(data)))
print('mean age: ' + str(data['Leeftijd*'].mean()))
sex = []
for part, s in data.groupby('participant')['Gender*']:
    sex.append(list(s)[0])
print('percentage F: ' + str(sex.count('V')/len(sex)))
#%% 
# remove filler trials
data = data[data['TrialType']!='FILLER']
#%% remove outliers
outliers = []
for d,values in data.groupby('participant'):
    outliers.append(values['response.rt']<4)
#%%
left = sum(np.concatenate(outliers))
trials_kept = (1-left/len(data))*100
print("removed outliers, i.e. {:.2f}% of trials".format(trials_kept))
data  = data[np.concatenate(outliers)]

#%% remove too fast trials
left = len(data[data['response.rt']>0.1])
trials_kept = (1-left/len(data))*100
print("removed outliers, i.e. {:.2f}% of trials".format(trials_kept))
data = data[data['response.rt']>0.1]

#%% 
# =========#
# PLOTTING #
# =========#
plt.figure(figsize=(14,7))
gs = gridspec.GridSpec(1, 2,wspace=0.2)
#1. present the data as it is usually presented in experiments
## A/ Proportion  of positive judgement
plt.subplot(gs[0,0:1])
plt.ylabel('P(negative)')
plt.ylim(0,1.1)
plt.xticks([])
plt.title('A',size=20,position=(-0.1,0))
colors = ['#e41a1c','#4daf4a', '#dede00']
i = 0
for d,values in data.groupby('prime_cond'):
    meanPN = np.array(1-values.groupby('participant')['respPos'].mean()) ## probability negative response
    mean = meanPN.mean() ## overall mean
    sd   = meanPN.std() ##standard deviation
    plt.vlines(d,mean-sd,mean+sd,linestyles = '-',color=colors[i])
    plt.hlines(mean-sd,-0.1+i,0.1+i,linestyles = '-',color=colors[i])
    plt.hlines(mean+sd,-0.1+i,0.1+i,linestyles = '-',color=colors[i])
    plt.scatter(np.random.normal(i,0.04,len(meanPN)),meanPN,color = colors[i],alpha = 0.2,label=d)
    plt.scatter([d],mean,color = colors[i])
    plt.legend()
    i +=1
## B/ RTs
plt.subplot(gs[0,1:2])
plt.ylabel('RT(s)')
plt.ylim(0,1.6)
plt.xticks([])
plt.title('B',size=20,position=(-0.1,0))

i = 0
for d,values in data.groupby('prime_cond'):
    meanPP = np.array(values.groupby('participant')['response.rt'].mean())
    mean = meanPP.mean();print(mean) ## overall mean
    sd   = meanPP.std() ##standard deviation
    plt.vlines(d,mean-sd,mean+sd,linestyles = '-',color=colors[i],alpha = 0.5)
    plt.hlines(mean-sd,-0.1+i,0.1+i,linestyles = '-',color=colors[i])
    plt.hlines(mean+sd,-0.1+i,0.1+i,linestyles = '-',color=colors[i])
    plt.scatter(np.random.normal(i,0.04,len(meanPP)),meanPP,color = colors[i],alpha = 0.2)
    plt.scatter([d],mean,color = colors[i])
    i +=1      

#2. Rt distribution
data['RT'] = data['response.rt']
data.loc[data['respPos']==0, 'RT'] = -data['response.rt']
sns.displot(data,x="RT", hue="prime_cond",kind="kde", fill=True,height=7, aspect=2,palette = colors,hue_order=['NEG','POS','SCR'])


