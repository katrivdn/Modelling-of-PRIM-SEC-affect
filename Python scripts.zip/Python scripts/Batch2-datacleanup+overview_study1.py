# -*- coding: utf-8 -*-
"""
Created on Mon Mar  1 10:13:43 2021

Analysis of second batch, study 1 'modelling of primary and secondary 
effects of affect on decision-making'. Description of the study:
    participants had to judge whether a majority of faces were either neutral,
    happy, or angry in an array of 8 faces. 
Change compared to first batch: a block with both happy and angry faces was shown, 
Even trials were removed.

@author: Katrien Vandenbroeck
"""
# =============================================================================
# Experiment 1 - Batch 2
# short description: looking at the effects of emotional faces on reaction time and accuracy. 
# design: 8 faces, sometimes majority of angry, happy or neutral faces. 
# 2 difficulty conditions: hard/easy. 
# =============================================================================

from collections import Counter
import pandas as pd
from os import listdir
import os
import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns
import numpy as np
pd.set_option('display.max_rows', 1000) ## set limit to print
pd.set_option('display.max_columns', 5) ## set limit to print
mpl.style.use('seaborn')
mpl.style.use('tableau-colorblind10')

#%% import data:
path = os.getcwd()+r'\data\batch2\raw data'
all_files = [f for f in listdir(path) if 'study1' in f and '.csv' in f]
print('number of datafiles for study 1: {0}'.format(len(all_files)))
## note: some participants completed the study more than once due to 
## technical difficulties. 
ppn = [f[0:5] for f in all_files];rep =[item for item, count in Counter(ppn).items() if count > 1]
replicates = [f for f in all_files if any(string in f for string in rep)]
remain = []
minus  = []
for file in replicates:
    if file[0:5] not in [sub[0:5] for sub in remain]:
        remain.append(file)
    else:
        minus.append(file)
## remove replicates:
all_files = [f for f in all_files if f not in minus]
print('number of datafiles minus replicates for study 1: {0}'.format(len(all_files)))

## concatenate the dataset:
li = []
for filename in all_files:
    df = pd.read_csv(path+'\\'+filename)
    df = df
    li.append(df)
d1 = pd.concat(li, axis=0, ignore_index=True)
data = d1.loc[d1['StartExp']==True]
print(data.columns)
data = data[['response.keys', 'response.corr','StartExp', 'aff', 'Cond', 'difficulty','study', 'overbalance','CorResp',
       'Leeftijd*', 'participant', 'Gender*', 'date', 'expName', 'response.rt', 'Experimental_trial.thisTrialN']]
#%% mean age and gender of participants
print('mean age: ' + str(data['Leeftijd*'].mean()))
sex = []
for part, s in data.groupby('participant')['Gender*']:
    sex.append(list(s)[0])
print('percentage F: ' + str(sex.count('V')/len(sex)))
#%% remove trials for which RTs are bellow 100ms 
print("remove trials RTs<100ms, i.e. {0:2f}% of trials".format(len(data.loc[data['response.rt']<=0.100])/len(data)*100))
data = data.loc[data['response.rt']>0.100]
#%% add index value for trials
trial_nb = [range(0,len(values)) for participant,values in data.groupby('participant')]
data['TrialN'] = np.concatenate(trial_nb)
#%% overall RT distributions
sns.distplot(a=data['response.rt'][data['response.rt']>0], hist = True, kde = True,
                     kde_kws = {'shade': True, 'linewidth': 3},label=['d','k'])
#%% view mean rt and response accruacy for each participant
for d,values in data.groupby('participant'):
    print('--------')
    ## look at trends per participant
    p = sns.lmplot(data=values, x = 'TrialN', y='response.rt')
    p.set_axis_labels(d)
    ## look at response distribution
    plt.figure()
    for acc,subdata in values.groupby('response.corr'):
        if acc == 1:
            sns.distplot(subdata['response.rt'])
        else:
            sns.distplot(-subdata['response.rt'])
    print(str(d)+'meanACC: '+str(values['response.corr'].mean()))
    print(str(d)+'meanACC per cond:' + str(values.groupby('difficulty')['response.corr'].mean()))
# NOTES
## (1) some participants showed random answer patterns: 23650 (0.60), 27976 (0.55),
## 29317 (0.58), 29395 (0.56), 29617 (0.64)
## (2) many participants performed poorly on the hard trials --> maybe not gathering all necessary evidence, but focussing only on a small region.
# remove participants performance was random:
delete = [23650,27976,29317,29395,29617]
data = data[~data.participant.isin(delete)]
data.groupby('participant') ['response.corr'].mean()
data.groupby('difficulty')['response.corr'].mean()
print("total number of pt exp1: " + str(len(np.unique(data['participant']))))

#%% remove outliers greater than 3.5 seconds
outliers = []
for d,values in data.groupby('participant'):
    outliers.append(values['response.rt']<3.5)
#%%
left = sum(np.concatenate(outliers))
trials_kept = (1-left/len(data))*100
print("removed outliers, i.e. {:.2f}% of trials".format(trials_kept))
data  = data[np.concatenate(outliers)]
#%% check again for outliers
for d,values in data.groupby('participant'):
    plt.title(d)
    sns.lmplot(data=values, x = 'TrialN', y='response.rt')

#%% 
# =========#
# PLOTTING #
# =========#
c = ['#1b9e77','#d95f02','#7570b3']
#%%
f, ax1 = plt.subplots(nrows=1, ncols=1,figsize=(14,7))
#1. ACC & RT mean
## A/ Accuracy
## aggregate the data
data_agg = data.groupby(['participant','difficulty', 'overbalance'])['response.corr'].mean().reset_index()
# Show each observation with a scatterplot
sns.stripplot(data=data_agg,x="difficulty", y="response.corr", hue="overbalance", dodge=True, alpha=.25, zorder=1,palette=c,ax=ax1)

# Show the conditional means
sns.pointplot(data=data_agg,x="difficulty", y="response.corr", hue="overbalance",join=False, dodge=0.55,alpha=.25, zorder=1,palette=c,ax=ax1)
# change axis name
handles, labels = ax1.get_legend_handles_labels()
labels = ['Angry','Happy','Neutral','Angry','Happy','Neutral']
ax1.legend(handles[0:3], labels[0:3], title="overbalance",
          handletextpad=0, columnspacing=1,
          loc="upper right", ncol=3, frameon=True,facecolor='white')
ax1.set(xlabel='', ylabel='ACC')


f.savefig(r"C:\Users\Katri\Documents\Unief\experimentele psy\INTERNSHIP\2020-21_PRIM_SEC_AFFECT\paper draft\Figures\overviewdata_study1(Batch2)_ACC.pdf")
#%%
## B/ RTs
 ## aggregate the data
data_agg = data[data['response.corr']==1].groupby(['participant','difficulty','overbalance'])['response.rt'].mean().reset_index()
f, ax1 = plt.subplots(nrows=1, ncols=1,figsize=(14,7))

#A1 - condition Positive
# Show each observation with a scatterplot
sns.stripplot(data=data_agg,x="difficulty", y='response.rt', hue="overbalance",dodge=True, alpha=.25, zorder=1,palette=c,ax=ax1)

# Show the conditional means
sns.pointplot(data=data_agg,x="difficulty", y='response.rt', hue="overbalance", 
              join=False, dodge=0.55,alpha=.25, zorder=1,palette=c,ax=ax1)
# change axis name
handles, labels = ax1.get_legend_handles_labels()
labels = ['Angry','Happy','Neutral','Angry','Happy','Neutral']
ax1.legend(handles[0:3], labels[0:3], title="overbalance",
          handletextpad=0, columnspacing=1,
          loc="upper right", ncol=3, frameon=True,facecolor='white')
ax1.set(xlabel='', ylabel='RT',ylim=[0.4,1.5])

f.savefig(r"C:\Users\Katri\Documents\Unief\experimentele psy\INTERNSHIP\2020-21_PRIM_SEC_AFFECT\paper draft\Figures\overviewdata_study1(Batch2)_RT.pdf")

#%%
#2. present the data distribution
data['RT'] = data['response.rt']
data.loc[data['response.corr']==0, 'RT'] = -data['response.rt']
sns.displot(data,x="RT", hue="overbalance",kind="kde", fill=True,height=7, aspect=2,palette = c,hue_order=['Boos','Gelukkig','Neutraal'])

