This study made use of the NimStim dataset.
See https://danlab.psychology.columbia.edu/content/nimstim-set-facial-expressions
for access.