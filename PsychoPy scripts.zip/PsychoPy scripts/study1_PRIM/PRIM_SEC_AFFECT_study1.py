﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v3.1.5),
    on December 04, 2020, at 16:07
If you publish work using this script please cite the PsychoPy publications:
    Peirce, JW (2007) PsychoPy - Psychophysics software in Python.
        Journal of Neuroscience Methods, 162(1-2), 8-13.
    Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy.
        Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008
"""

from __future__ import absolute_import, division
from psychopy import locale_setup, sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '3.1.5'
expName = 'PRIM_SEC_AFFECT_study1'  # from the Builder filename that created this script
expInfo = {'Leeftijd*': '', 'participant': '', 'Gender*': ['V', 'M', 'X']}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s' % (expName, expInfo['participant'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Users\\Katri\\Documents\\Unief\\experimentele psy\\INTERNSHIP\\PsychoPy\\study1\\PRIM_SEC_AFFECT_study1.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=[1366, 768], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[-1,-1,-1], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "Welcome"
WelcomeClock = core.Clock()
welkom = visual.TextStim(win=win, name='welkom',
    text='Welkom bij dit experiment! \n[druk op spatie om verder te gaan]',
    font=None,
    pos=(0, 0), height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "finger_placement"
finger_placementClock = core.Clock()
kort = visual.TextStim(win=win, name='kort',
    text="Houd jouw vingers als volgt op het toetsenbord: de linker index vinger op de 'f' toets en de rechter index vinger op de 'j' toets. De schakering van jouw toetsenbord is niet relevant.\n[Druk op spatie om verder te gaan]",
    font='Arial',
    pos=(0, 0.3), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
keyboard_img = visual.ImageStim(
    win=win,
    name='keyboard_img', units='pix', 
    image='keyboard.jpg', mask=None,
    ori=0, pos=(0, -100), size=(799,258),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)

# Initialize components for Routine "Instructies"
InstructiesClock = core.Clock()
explanation_welkom = visual.TextStim(win=win, name='explanation_welkom',
    text='Dit experiment is opgesplitst in vier delen. \nIn elk deel zal je telkens heel kort acht gezichten te zien krijgen; als volgt: \n[druk op spatie om verder te gaan]',
    font=None,
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "facesample"
facesampleClock = core.Clock()
fixation_2 = visual.TextStim(win=win, name='fixation_2',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
image_13 = visual.ImageStim(
    win=win,
    name='image_13', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
image_14 = visual.ImageStim(
    win=win,
    name='image_14', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
image_15 = visual.ImageStim(
    win=win,
    name='image_15', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-3.0)
image_16 = visual.ImageStim(
    win=win,
    name='image_16', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)
image_17 = visual.ImageStim(
    win=win,
    name='image_17', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-5.0)
image_18 = visual.ImageStim(
    win=win,
    name='image_18', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-6.0)
image_19 = visual.ImageStim(
    win=win,
    name='image_19', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-7.0)
image8_2 = visual.ImageStim(
    win=win,
    name='image8_2', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-8.0)

# Initialize components for Routine "EXP1_inst"
EXP1_instClock = core.Clock()
text = visual.TextStim(win=win, name='text',
    text='Jouw taak ligt erin om uit te maken of een merendeel van de gezichten een bepaalde emotionele expressie hadden. Maak je geen zorgen als je niet alle gezichten kan waarnemen! Concentreer jou gewoon op het kruisje in het midden van het scherm, en reageer op een algemene indruk.\nJe zal ook in het begin van elke beurt de volgende elementen op het scherm zien verschijnen:\n[Druk op spatie om verder te gaan] ',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "cuesample"
cuesampleClock = core.Clock()
cross_fix_3 = visual.TextStim(win=win, name='cross_fix_3',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
right_cue_2 = visual.TextStim(win=win, name='right_cue_2',
    text='default text',
    font='Arial',
    units='norm', pos=(-0.25,0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
left_cue_2 = visual.TextStim(win=win, name='left_cue_2',
    text='default text',
    font='Arial',
    units='norm', pos=[0,0], height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "OR"
ORClock = core.Clock()
or_txt = visual.TextStim(win=win, name='or_txt',
    text="'B' staat hier voor 'Boos' en 'N' voor 'Neutraal'. Je zal soms iets gelijkaardig zien verschijnen:\n[druk op spatie om verder te gaan]",
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "cue_sample2"
cue_sample2Clock = core.Clock()
cross_fix_5 = visual.TextStim(win=win, name='cross_fix_5',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
right_cue_4 = visual.TextStim(win=win, name='right_cue_4',
    text='default text',
    font='Arial',
    units='norm', pos=(-0.25,0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
left_cue_4 = visual.TextStim(win=win, name='left_cue_4',
    text='default text',
    font='Arial',
    units='norm', pos=[0,0], height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "OR_2"
OR_2Clock = core.Clock()
or_txt_2 = visual.TextStim(win=win, name='or_txt_2',
    text="'G' staat hier voor 'Gelukkig' en 'N' voor 'Neutraal'. Deze symbolen zullen jou helpen om jou te laten herinneren aan welke kant je zal moeten antwoorden.\nHierna volgt het eerste deel van het experiment.\n[druk op spatie om verder te gaan]",
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "code_partn"
code_partnClock = core.Clock()
part = 0
part_text = 'Deel {0}/4'.format(part)


# Initialize components for Routine "DEEL"
DEELClock = core.Clock()
Text_ndeel = visual.TextStim(win=win, name='Text_ndeel',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "response_instr_left"
response_instr_leftClock = core.Clock()
keyboard_picture = visual.ImageStim(
    win=win,
    name='keyboard_picture', units='pix', 
    image='F.png', mask=None,
    ori=0, pos=(0, -100), size=(799,258),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
sample_training = visual.ImageStim(
    win=win,
    name='sample_training', units='pix', 
    image='sin', mask=None,
    ori=0, pos=(0,250), size=(125,125),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
links_text = visual.TextStim(win=win, name='links_text',
    text='default text',
    font=None,
    units='norm', pos=(0, 0.35), height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);
text_4 = visual.TextStim(win=win, name='text_4',
    text="[druk op de 'f' toets om verder te gaan]",
    font='Arial',
    units='norm', pos=(0, -0.85), height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-4.0);

# Initialize components for Routine "response_instr_right"
response_instr_rightClock = core.Clock()
IMAGE = visual.ImageStim(
    win=win,
    name='IMAGE', units='pix', 
    image='sin', mask=None,
    ori=0, pos=(0, 250), size=(125,125),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
text_3 = visual.TextStim(win=win, name='text_3',
    text='default text',
    font='Arial',
    units='norm', pos=(0, 0.35), height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
keyboard_2 = visual.ImageStim(
    win=win,
    name='keyboard_2', units='pix', 
    image='J.png', mask=None,
    ori=0, pos=(0, -100), size=(799,258),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-3.0)
text_5 = visual.TextStim(win=win, name='text_5',
    text="[druk op de 'j' toets om verder te gaan]",
    font='Arial',
    units='norm', pos=(0, -0.85), height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-4.0);

# Initialize components for Routine "oefenen"
oefenenClock = core.Clock()
training_txt = visual.TextStim(win=win, name='training_txt',
    text='Hierna begint een korte oefenreeks.\n[druk op spatie om verder te gaan]',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "cue"
cueClock = core.Clock()
cross_fix_2 = visual.TextStim(win=win, name='cross_fix_2',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
right_cue = visual.TextStim(win=win, name='right_cue',
    text='default text',
    font='Arial',
    units='norm', pos=(0.25,0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
left_cue = visual.TextStim(win=win, name='left_cue',
    text='default text',
    font='Arial',
    units='norm', pos=[0,0], height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "EXP1_experiment"
EXP1_experimentClock = core.Clock()
fixation = visual.TextStim(win=win, name='fixation',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
image_1 = visual.ImageStim(
    win=win,
    name='image_1', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
image_2 = visual.ImageStim(
    win=win,
    name='image_2', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
image_3 = visual.ImageStim(
    win=win,
    name='image_3', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-3.0)
image_4 = visual.ImageStim(
    win=win,
    name='image_4', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)
image_5 = visual.ImageStim(
    win=win,
    name='image_5', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-5.0)
image_6 = visual.ImageStim(
    win=win,
    name='image_6', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-6.0)
image_12 = visual.ImageStim(
    win=win,
    name='image_12', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-7.0)
image8 = visual.ImageStim(
    win=win,
    name='image8', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-8.0)

# Initialize components for Routine "Feedback_2"
Feedback_2Clock = core.Clock()
msg = ''
msg_color= 'white'
trial = 0
ACC   = 0

# Initialize components for Routine "FB_text"
FB_textClock = core.Clock()
Feedback = visual.TextStim(win=win, name='Feedback',
    text='default text',
    font='Arial',
    pos=(0, 0.1), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
merendeel = visual.TextStim(win=win, name='merendeel',
    text='Een merendeel van de gezichten waren:',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
text_9 = visual.TextStim(win=win, name='text_9',
    text='default text',
    font='Arial',
    pos=(0, -0.1), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
training_session = visual.TextStim(win=win, name='training_session',
    text='OEFENREEKS',
    font='Arial',
    units='norm', pos=(0, 0.5), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);

# Initialize components for Routine "post_FB"
post_FBClock = core.Clock()

# Initialize components for Routine "Instruc_start"
Instruc_startClock = core.Clock()
text_10 = visual.TextStim(win=win, name='text_10',
    text='Straks volgt het echte experiment! \nMaak je geen zorgen als je niet alle gezichten volledig kan waarnemen. Reageer op een algemene indruk.\nTer herhaling:\n[druk op spatie om verder te gaan]',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "response_instr_left"
response_instr_leftClock = core.Clock()
keyboard_picture = visual.ImageStim(
    win=win,
    name='keyboard_picture', units='pix', 
    image='F.png', mask=None,
    ori=0, pos=(0, -100), size=(799,258),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
sample_training = visual.ImageStim(
    win=win,
    name='sample_training', units='pix', 
    image='sin', mask=None,
    ori=0, pos=(0,250), size=(125,125),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
links_text = visual.TextStim(win=win, name='links_text',
    text='default text',
    font=None,
    units='norm', pos=(0, 0.35), height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);
text_4 = visual.TextStim(win=win, name='text_4',
    text="[druk op de 'f' toets om verder te gaan]",
    font='Arial',
    units='norm', pos=(0, -0.85), height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-4.0);

# Initialize components for Routine "response_instr_right"
response_instr_rightClock = core.Clock()
IMAGE = visual.ImageStim(
    win=win,
    name='IMAGE', units='pix', 
    image='sin', mask=None,
    ori=0, pos=(0, 250), size=(125,125),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
text_3 = visual.TextStim(win=win, name='text_3',
    text='default text',
    font='Arial',
    units='norm', pos=(0, 0.35), height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
keyboard_2 = visual.ImageStim(
    win=win,
    name='keyboard_2', units='pix', 
    image='J.png', mask=None,
    ori=0, pos=(0, -100), size=(799,258),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-3.0)
text_5 = visual.TextStim(win=win, name='text_5',
    text="[druk op de 'j' toets om verder te gaan]",
    font='Arial',
    units='norm', pos=(0, -0.85), height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-4.0);

# Initialize components for Routine "EXP1_START"
EXP1_STARTClock = core.Clock()
text_7 = visual.TextStim(win=win, name='text_7',
    text='Vanaf nu start het echte experiment!\n[Druk op spatie om verder te gaan]',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
text_8 = visual.TextStim(win=win, name='text_8',
    text='START EXPERIMENT',
    font='Arial',
    pos=(0, 0.4), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "cue"
cueClock = core.Clock()
cross_fix_2 = visual.TextStim(win=win, name='cross_fix_2',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
right_cue = visual.TextStim(win=win, name='right_cue',
    text='default text',
    font='Arial',
    units='norm', pos=(0.25,0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
left_cue = visual.TextStim(win=win, name='left_cue',
    text='default text',
    font='Arial',
    units='norm', pos=[0,0], height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "EXP1_experiment"
EXP1_experimentClock = core.Clock()
fixation = visual.TextStim(win=win, name='fixation',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
image_1 = visual.ImageStim(
    win=win,
    name='image_1', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
image_2 = visual.ImageStim(
    win=win,
    name='image_2', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
image_3 = visual.ImageStim(
    win=win,
    name='image_3', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-3.0)
image_4 = visual.ImageStim(
    win=win,
    name='image_4', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)
image_5 = visual.ImageStim(
    win=win,
    name='image_5', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-5.0)
image_6 = visual.ImageStim(
    win=win,
    name='image_6', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-6.0)
image_12 = visual.ImageStim(
    win=win,
    name='image_12', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-7.0)
image8 = visual.ImageStim(
    win=win,
    name='image8', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-8.0)

# Initialize components for Routine "Pauzeren_even"
Pauzeren_evenClock = core.Clock()
pauze_for_a_moment_mate = visual.TextStim(win=win, name='pauze_for_a_moment_mate',
    text='Eventjes pauzeren...\n[druk op spatie om verder te gaan]',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "End"
EndClock = core.Clock()
End_txt = visual.TextStim(win=win, name='End_txt',
    text='Hartelijk dank voor jouw deelname!\n[druk op spatie om het experiment te beëindigen]',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "Welcome"-------
t = 0
WelcomeClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
space = keyboard.Keyboard()
# keep track of which components have finished
WelcomeComponents = [welkom, space]
for thisComponent in WelcomeComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "Welcome"-------
while continueRoutine:
    # get current time
    t = WelcomeClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *welkom* updates
    if t >= 0.0 and welkom.status == NOT_STARTED:
        # keep track of start time/frame for later
        welkom.tStart = t  # not accounting for scr refresh
        welkom.frameNStart = frameN  # exact frame index
        win.timeOnFlip(welkom, 'tStartRefresh')  # time at next scr refresh
        welkom.setAutoDraw(True)
    
    # *space* updates
    if t >= 0.0 and space.status == NOT_STARTED:
        # keep track of start time/frame for later
        space.tStart = t  # not accounting for scr refresh
        space.frameNStart = frameN  # exact frame index
        win.timeOnFlip(space, 'tStartRefresh')  # time at next scr refresh
        space.status = STARTED
        # keyboard checking is just starting
        space.clearEvents(eventType='keyboard')
    if space.status == STARTED:
        theseKeys = space.getKeys(keyList=['space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in WelcomeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Welcome"-------
for thisComponent in WelcomeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "Welcome" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "finger_placement"-------
t = 0
finger_placementClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
space_3 = keyboard.Keyboard()
# keep track of which components have finished
finger_placementComponents = [kort, space_3, keyboard_img]
for thisComponent in finger_placementComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "finger_placement"-------
while continueRoutine:
    # get current time
    t = finger_placementClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *kort* updates
    if t >= 0.0 and kort.status == NOT_STARTED:
        # keep track of start time/frame for later
        kort.tStart = t  # not accounting for scr refresh
        kort.frameNStart = frameN  # exact frame index
        win.timeOnFlip(kort, 'tStartRefresh')  # time at next scr refresh
        kort.setAutoDraw(True)
    
    # *space_3* updates
    if t >= 0.0 and space_3.status == NOT_STARTED:
        # keep track of start time/frame for later
        space_3.tStart = t  # not accounting for scr refresh
        space_3.frameNStart = frameN  # exact frame index
        win.timeOnFlip(space_3, 'tStartRefresh')  # time at next scr refresh
        space_3.status = STARTED
        # keyboard checking is just starting
        space_3.clearEvents(eventType='keyboard')
    if space_3.status == STARTED:
        theseKeys = space_3.getKeys(keyList=['space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            # a response ends the routine
            continueRoutine = False
    
    # *keyboard_img* updates
    if t >= 0.0 and keyboard_img.status == NOT_STARTED:
        # keep track of start time/frame for later
        keyboard_img.tStart = t  # not accounting for scr refresh
        keyboard_img.frameNStart = frameN  # exact frame index
        win.timeOnFlip(keyboard_img, 'tStartRefresh')  # time at next scr refresh
        keyboard_img.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in finger_placementComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "finger_placement"-------
for thisComponent in finger_placementComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "finger_placement" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Instructies"-------
t = 0
InstructiesClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
space_2 = keyboard.Keyboard()
# keep track of which components have finished
InstructiesComponents = [explanation_welkom, space_2]
for thisComponent in InstructiesComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "Instructies"-------
while continueRoutine:
    # get current time
    t = InstructiesClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *explanation_welkom* updates
    if t >= 0.0 and explanation_welkom.status == NOT_STARTED:
        # keep track of start time/frame for later
        explanation_welkom.tStart = t  # not accounting for scr refresh
        explanation_welkom.frameNStart = frameN  # exact frame index
        win.timeOnFlip(explanation_welkom, 'tStartRefresh')  # time at next scr refresh
        explanation_welkom.setAutoDraw(True)
    
    # *space_2* updates
    if t >= 0.0 and space_2.status == NOT_STARTED:
        # keep track of start time/frame for later
        space_2.tStart = t  # not accounting for scr refresh
        space_2.frameNStart = frameN  # exact frame index
        win.timeOnFlip(space_2, 'tStartRefresh')  # time at next scr refresh
        space_2.status = STARTED
        # keyboard checking is just starting
        space_2.clearEvents(eventType='keyboard')
    if space_2.status == STARTED:
        theseKeys = space_2.getKeys(keyList=['space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in InstructiesComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Instructies"-------
for thisComponent in InstructiesComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "Instructies" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "facesample"-------
t = 0
facesampleClock.reset()  # clock
frameN = -1
continueRoutine = True
routineTimer.add(2.000000)
# update component parameters for each repeat
image_13.setPos((56.56,-56.56))
image_13.setImage('face_expressions_TRAIN/01F_AN_c.png')
image_14.setPos((-1.46,-80))
image_14.setImage('face_expressions_TRAIN/03F_AN_C.png')
image_15.setPos((56.56,56.56))
image_15.setImage('face_expressions_TRAIN/03F_NE_C.png')
image_16.setPos((4.90,80))
image_16.setImage('face_expressions_TRAIN/21M_AN_C.png')
image_17.setPos((-56.56,-56.56))
image_17.setImage('face_expressions_TRAIN/20M_AN_C.png')
image_18.setPos((-56.56,56.56))
image_18.setImage('face_expressions_TRAIN/20M_AN_O.png')
image_19.setPos((80,0))
image_19.setImage('face_expressions_TRAIN/02F_NE_O.png')
image8_2.setPos((-80,4.80))
image8_2.setImage('face_expressions_TRAIN/01F_NE_C.png')
# keep track of which components have finished
facesampleComponents = [fixation_2, image_13, image_14, image_15, image_16, image_17, image_18, image_19, image8_2]
for thisComponent in facesampleComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "facesample"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = facesampleClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *fixation_2* updates
    if t >= 0 and fixation_2.status == NOT_STARTED:
        # keep track of start time/frame for later
        fixation_2.tStart = t  # not accounting for scr refresh
        fixation_2.frameNStart = frameN  # exact frame index
        win.timeOnFlip(fixation_2, 'tStartRefresh')  # time at next scr refresh
        fixation_2.setAutoDraw(True)
    frameRemains = 0 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
    if fixation_2.status == STARTED and t >= frameRemains:
        # keep track of stop time/frame for later
        fixation_2.tStop = t  # not accounting for scr refresh
        fixation_2.frameNStop = frameN  # exact frame index
        win.timeOnFlip(fixation_2, 'tStopRefresh')  # time at next scr refresh
        fixation_2.setAutoDraw(False)
    
    # *image_13* updates
    if t >= 0.5 and image_13.status == NOT_STARTED:
        # keep track of start time/frame for later
        image_13.tStart = t  # not accounting for scr refresh
        image_13.frameNStart = frameN  # exact frame index
        win.timeOnFlip(image_13, 'tStartRefresh')  # time at next scr refresh
        image_13.setAutoDraw(True)
    frameRemains = 0.5 + 0.75- win.monitorFramePeriod * 0.75  # most of one frame period left
    if image_13.status == STARTED and t >= frameRemains:
        # keep track of stop time/frame for later
        image_13.tStop = t  # not accounting for scr refresh
        image_13.frameNStop = frameN  # exact frame index
        win.timeOnFlip(image_13, 'tStopRefresh')  # time at next scr refresh
        image_13.setAutoDraw(False)
    
    # *image_14* updates
    if t >= 0.5 and image_14.status == NOT_STARTED:
        # keep track of start time/frame for later
        image_14.tStart = t  # not accounting for scr refresh
        image_14.frameNStart = frameN  # exact frame index
        win.timeOnFlip(image_14, 'tStartRefresh')  # time at next scr refresh
        image_14.setAutoDraw(True)
    frameRemains = 0.5 + 0.75- win.monitorFramePeriod * 0.75  # most of one frame period left
    if image_14.status == STARTED and t >= frameRemains:
        # keep track of stop time/frame for later
        image_14.tStop = t  # not accounting for scr refresh
        image_14.frameNStop = frameN  # exact frame index
        win.timeOnFlip(image_14, 'tStopRefresh')  # time at next scr refresh
        image_14.setAutoDraw(False)
    
    # *image_15* updates
    if t >= 0.5 and image_15.status == NOT_STARTED:
        # keep track of start time/frame for later
        image_15.tStart = t  # not accounting for scr refresh
        image_15.frameNStart = frameN  # exact frame index
        win.timeOnFlip(image_15, 'tStartRefresh')  # time at next scr refresh
        image_15.setAutoDraw(True)
    frameRemains = 0.5 + 0.75- win.monitorFramePeriod * 0.75  # most of one frame period left
    if image_15.status == STARTED and t >= frameRemains:
        # keep track of stop time/frame for later
        image_15.tStop = t  # not accounting for scr refresh
        image_15.frameNStop = frameN  # exact frame index
        win.timeOnFlip(image_15, 'tStopRefresh')  # time at next scr refresh
        image_15.setAutoDraw(False)
    
    # *image_16* updates
    if t >= 0.5 and image_16.status == NOT_STARTED:
        # keep track of start time/frame for later
        image_16.tStart = t  # not accounting for scr refresh
        image_16.frameNStart = frameN  # exact frame index
        win.timeOnFlip(image_16, 'tStartRefresh')  # time at next scr refresh
        image_16.setAutoDraw(True)
    frameRemains = 0.5 + 0.75- win.monitorFramePeriod * 0.75  # most of one frame period left
    if image_16.status == STARTED and t >= frameRemains:
        # keep track of stop time/frame for later
        image_16.tStop = t  # not accounting for scr refresh
        image_16.frameNStop = frameN  # exact frame index
        win.timeOnFlip(image_16, 'tStopRefresh')  # time at next scr refresh
        image_16.setAutoDraw(False)
    
    # *image_17* updates
    if t >= 0.5 and image_17.status == NOT_STARTED:
        # keep track of start time/frame for later
        image_17.tStart = t  # not accounting for scr refresh
        image_17.frameNStart = frameN  # exact frame index
        win.timeOnFlip(image_17, 'tStartRefresh')  # time at next scr refresh
        image_17.setAutoDraw(True)
    frameRemains = 0.5 + 0.75- win.monitorFramePeriod * 0.75  # most of one frame period left
    if image_17.status == STARTED and t >= frameRemains:
        # keep track of stop time/frame for later
        image_17.tStop = t  # not accounting for scr refresh
        image_17.frameNStop = frameN  # exact frame index
        win.timeOnFlip(image_17, 'tStopRefresh')  # time at next scr refresh
        image_17.setAutoDraw(False)
    
    # *image_18* updates
    if t >= 0.5 and image_18.status == NOT_STARTED:
        # keep track of start time/frame for later
        image_18.tStart = t  # not accounting for scr refresh
        image_18.frameNStart = frameN  # exact frame index
        win.timeOnFlip(image_18, 'tStartRefresh')  # time at next scr refresh
        image_18.setAutoDraw(True)
    frameRemains = 0.5 + 0.75- win.monitorFramePeriod * 0.75  # most of one frame period left
    if image_18.status == STARTED and t >= frameRemains:
        # keep track of stop time/frame for later
        image_18.tStop = t  # not accounting for scr refresh
        image_18.frameNStop = frameN  # exact frame index
        win.timeOnFlip(image_18, 'tStopRefresh')  # time at next scr refresh
        image_18.setAutoDraw(False)
    
    # *image_19* updates
    if t >= 0.5 and image_19.status == NOT_STARTED:
        # keep track of start time/frame for later
        image_19.tStart = t  # not accounting for scr refresh
        image_19.frameNStart = frameN  # exact frame index
        win.timeOnFlip(image_19, 'tStartRefresh')  # time at next scr refresh
        image_19.setAutoDraw(True)
    frameRemains = 0.5 + 0.75- win.monitorFramePeriod * 0.75  # most of one frame period left
    if image_19.status == STARTED and t >= frameRemains:
        # keep track of stop time/frame for later
        image_19.tStop = t  # not accounting for scr refresh
        image_19.frameNStop = frameN  # exact frame index
        win.timeOnFlip(image_19, 'tStopRefresh')  # time at next scr refresh
        image_19.setAutoDraw(False)
    
    # *image8_2* updates
    if t >= 0.5 and image8_2.status == NOT_STARTED:
        # keep track of start time/frame for later
        image8_2.tStart = t  # not accounting for scr refresh
        image8_2.frameNStart = frameN  # exact frame index
        win.timeOnFlip(image8_2, 'tStartRefresh')  # time at next scr refresh
        image8_2.setAutoDraw(True)
    frameRemains = 0.5 + 0.75- win.monitorFramePeriod * 0.75  # most of one frame period left
    if image8_2.status == STARTED and t >= frameRemains:
        # keep track of stop time/frame for later
        image8_2.tStop = t  # not accounting for scr refresh
        image8_2.frameNStop = frameN  # exact frame index
        win.timeOnFlip(image8_2, 'tStopRefresh')  # time at next scr refresh
        image8_2.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in facesampleComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "facesample"-------
for thisComponent in facesampleComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)

# ------Prepare to start Routine "EXP1_inst"-------
t = 0
EXP1_instClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_resp_5 = keyboard.Keyboard()
# keep track of which components have finished
EXP1_instComponents = [text, key_resp_5]
for thisComponent in EXP1_instComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "EXP1_inst"-------
while continueRoutine:
    # get current time
    t = EXP1_instClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text* updates
    if t >= 0.0 and text.status == NOT_STARTED:
        # keep track of start time/frame for later
        text.tStart = t  # not accounting for scr refresh
        text.frameNStart = frameN  # exact frame index
        win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
        text.setAutoDraw(True)
    
    # *key_resp_5* updates
    if t >= 0.0 and key_resp_5.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_5.tStart = t  # not accounting for scr refresh
        key_resp_5.frameNStart = frameN  # exact frame index
        win.timeOnFlip(key_resp_5, 'tStartRefresh')  # time at next scr refresh
        key_resp_5.status = STARTED
        # keyboard checking is just starting
        key_resp_5.clearEvents(eventType='keyboard')
    if key_resp_5.status == STARTED:
        theseKeys = key_resp_5.getKeys(keyList=['space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in EXP1_instComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "EXP1_inst"-------
for thisComponent in EXP1_instComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "EXP1_inst" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "cuesample"-------
t = 0
cuesampleClock.reset()  # clock
frameN = -1
continueRoutine = True
routineTimer.add(1.500000)
# update component parameters for each repeat
right_cue_2.setText('B')
left_cue_2.setPos((0.25,0))
left_cue_2.setText('N')
# keep track of which components have finished
cuesampleComponents = [cross_fix_3, right_cue_2, left_cue_2]
for thisComponent in cuesampleComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "cuesample"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = cuesampleClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *cross_fix_3* updates
    if t >= 0 and cross_fix_3.status == NOT_STARTED:
        # keep track of start time/frame for later
        cross_fix_3.tStart = t  # not accounting for scr refresh
        cross_fix_3.frameNStart = frameN  # exact frame index
        win.timeOnFlip(cross_fix_3, 'tStartRefresh')  # time at next scr refresh
        cross_fix_3.setAutoDraw(True)
    frameRemains = 0 + 1.5- win.monitorFramePeriod * 0.75  # most of one frame period left
    if cross_fix_3.status == STARTED and t >= frameRemains:
        # keep track of stop time/frame for later
        cross_fix_3.tStop = t  # not accounting for scr refresh
        cross_fix_3.frameNStop = frameN  # exact frame index
        win.timeOnFlip(cross_fix_3, 'tStopRefresh')  # time at next scr refresh
        cross_fix_3.setAutoDraw(False)
    
    # *right_cue_2* updates
    if t >= 0.5 and right_cue_2.status == NOT_STARTED:
        # keep track of start time/frame for later
        right_cue_2.tStart = t  # not accounting for scr refresh
        right_cue_2.frameNStart = frameN  # exact frame index
        win.timeOnFlip(right_cue_2, 'tStartRefresh')  # time at next scr refresh
        right_cue_2.setAutoDraw(True)
    frameRemains = 0.5 + 1- win.monitorFramePeriod * 0.75  # most of one frame period left
    if right_cue_2.status == STARTED and t >= frameRemains:
        # keep track of stop time/frame for later
        right_cue_2.tStop = t  # not accounting for scr refresh
        right_cue_2.frameNStop = frameN  # exact frame index
        win.timeOnFlip(right_cue_2, 'tStopRefresh')  # time at next scr refresh
        right_cue_2.setAutoDraw(False)
    
    # *left_cue_2* updates
    if t >= 0.5 and left_cue_2.status == NOT_STARTED:
        # keep track of start time/frame for later
        left_cue_2.tStart = t  # not accounting for scr refresh
        left_cue_2.frameNStart = frameN  # exact frame index
        win.timeOnFlip(left_cue_2, 'tStartRefresh')  # time at next scr refresh
        left_cue_2.setAutoDraw(True)
    frameRemains = 0.5 + 1- win.monitorFramePeriod * 0.75  # most of one frame period left
    if left_cue_2.status == STARTED and t >= frameRemains:
        # keep track of stop time/frame for later
        left_cue_2.tStop = t  # not accounting for scr refresh
        left_cue_2.frameNStop = frameN  # exact frame index
        win.timeOnFlip(left_cue_2, 'tStopRefresh')  # time at next scr refresh
        left_cue_2.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in cuesampleComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "cuesample"-------
for thisComponent in cuesampleComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)

# ------Prepare to start Routine "OR"-------
t = 0
ORClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_resp_2 = keyboard.Keyboard()
# keep track of which components have finished
ORComponents = [or_txt, key_resp_2]
for thisComponent in ORComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "OR"-------
while continueRoutine:
    # get current time
    t = ORClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *or_txt* updates
    if t >= 0.0 and or_txt.status == NOT_STARTED:
        # keep track of start time/frame for later
        or_txt.tStart = t  # not accounting for scr refresh
        or_txt.frameNStart = frameN  # exact frame index
        win.timeOnFlip(or_txt, 'tStartRefresh')  # time at next scr refresh
        or_txt.setAutoDraw(True)
    
    # *key_resp_2* updates
    if t >= 0.0 and key_resp_2.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_2.tStart = t  # not accounting for scr refresh
        key_resp_2.frameNStart = frameN  # exact frame index
        win.timeOnFlip(key_resp_2, 'tStartRefresh')  # time at next scr refresh
        key_resp_2.status = STARTED
        # keyboard checking is just starting
        key_resp_2.clearEvents(eventType='keyboard')
    if key_resp_2.status == STARTED:
        theseKeys = key_resp_2.getKeys(keyList=['space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in ORComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "OR"-------
for thisComponent in ORComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "OR" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "cue_sample2"-------
t = 0
cue_sample2Clock.reset()  # clock
frameN = -1
continueRoutine = True
routineTimer.add(1.500000)
# update component parameters for each repeat
right_cue_4.setText('N')
left_cue_4.setPos((0.25,0))
left_cue_4.setText('G')
# keep track of which components have finished
cue_sample2Components = [cross_fix_5, right_cue_4, left_cue_4]
for thisComponent in cue_sample2Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "cue_sample2"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = cue_sample2Clock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *cross_fix_5* updates
    if t >= 0 and cross_fix_5.status == NOT_STARTED:
        # keep track of start time/frame for later
        cross_fix_5.tStart = t  # not accounting for scr refresh
        cross_fix_5.frameNStart = frameN  # exact frame index
        win.timeOnFlip(cross_fix_5, 'tStartRefresh')  # time at next scr refresh
        cross_fix_5.setAutoDraw(True)
    frameRemains = 0 + 1.5- win.monitorFramePeriod * 0.75  # most of one frame period left
    if cross_fix_5.status == STARTED and t >= frameRemains:
        # keep track of stop time/frame for later
        cross_fix_5.tStop = t  # not accounting for scr refresh
        cross_fix_5.frameNStop = frameN  # exact frame index
        win.timeOnFlip(cross_fix_5, 'tStopRefresh')  # time at next scr refresh
        cross_fix_5.setAutoDraw(False)
    
    # *right_cue_4* updates
    if t >= 0.5 and right_cue_4.status == NOT_STARTED:
        # keep track of start time/frame for later
        right_cue_4.tStart = t  # not accounting for scr refresh
        right_cue_4.frameNStart = frameN  # exact frame index
        win.timeOnFlip(right_cue_4, 'tStartRefresh')  # time at next scr refresh
        right_cue_4.setAutoDraw(True)
    frameRemains = 0.5 + 1- win.monitorFramePeriod * 0.75  # most of one frame period left
    if right_cue_4.status == STARTED and t >= frameRemains:
        # keep track of stop time/frame for later
        right_cue_4.tStop = t  # not accounting for scr refresh
        right_cue_4.frameNStop = frameN  # exact frame index
        win.timeOnFlip(right_cue_4, 'tStopRefresh')  # time at next scr refresh
        right_cue_4.setAutoDraw(False)
    
    # *left_cue_4* updates
    if t >= 0.5 and left_cue_4.status == NOT_STARTED:
        # keep track of start time/frame for later
        left_cue_4.tStart = t  # not accounting for scr refresh
        left_cue_4.frameNStart = frameN  # exact frame index
        win.timeOnFlip(left_cue_4, 'tStartRefresh')  # time at next scr refresh
        left_cue_4.setAutoDraw(True)
    frameRemains = 0.5 + 1- win.monitorFramePeriod * 0.75  # most of one frame period left
    if left_cue_4.status == STARTED and t >= frameRemains:
        # keep track of stop time/frame for later
        left_cue_4.tStop = t  # not accounting for scr refresh
        left_cue_4.frameNStop = frameN  # exact frame index
        win.timeOnFlip(left_cue_4, 'tStopRefresh')  # time at next scr refresh
        left_cue_4.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in cue_sample2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "cue_sample2"-------
for thisComponent in cue_sample2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)

# ------Prepare to start Routine "OR_2"-------
t = 0
OR_2Clock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_resp_3 = keyboard.Keyboard()
# keep track of which components have finished
OR_2Components = [or_txt_2, key_resp_3]
for thisComponent in OR_2Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "OR_2"-------
while continueRoutine:
    # get current time
    t = OR_2Clock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *or_txt_2* updates
    if t >= 0.0 and or_txt_2.status == NOT_STARTED:
        # keep track of start time/frame for later
        or_txt_2.tStart = t  # not accounting for scr refresh
        or_txt_2.frameNStart = frameN  # exact frame index
        win.timeOnFlip(or_txt_2, 'tStartRefresh')  # time at next scr refresh
        or_txt_2.setAutoDraw(True)
    
    # *key_resp_3* updates
    if t >= 0.0 and key_resp_3.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_3.tStart = t  # not accounting for scr refresh
        key_resp_3.frameNStart = frameN  # exact frame index
        win.timeOnFlip(key_resp_3, 'tStartRefresh')  # time at next scr refresh
        key_resp_3.status = STARTED
        # keyboard checking is just starting
        key_resp_3.clearEvents(eventType='keyboard')
    if key_resp_3.status == STARTED:
        theseKeys = key_resp_3.getKeys(keyList=['space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in OR_2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "OR_2"-------
for thisComponent in OR_2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "OR_2" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
Block_EXP1 = data.TrialHandler(nReps=1, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('ConditionFile.csv'),
    seed=None, name='Block_EXP1')
thisExp.addLoop(Block_EXP1)  # add the loop to the experiment
thisBlock_EXP1 = Block_EXP1.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisBlock_EXP1.rgb)
if thisBlock_EXP1 != None:
    for paramName in thisBlock_EXP1:
        exec('{} = thisBlock_EXP1[paramName]'.format(paramName))

for thisBlock_EXP1 in Block_EXP1:
    currentLoop = Block_EXP1
    # abbreviate parameter names if possible (e.g. rgb = thisBlock_EXP1.rgb)
    if thisBlock_EXP1 != None:
        for paramName in thisBlock_EXP1:
            exec('{} = thisBlock_EXP1[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "code_partn"-------
    t = 0
    code_partnClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    part = part+1
    part_text = 'Deel {0}/4'.format(part)
    
    # keep track of which components have finished
    code_partnComponents = []
    for thisComponent in code_partnComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "code_partn"-------
    while continueRoutine:
        # get current time
        t = code_partnClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in code_partnComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "code_partn"-------
    for thisComponent in code_partnComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "code_partn" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "DEEL"-------
    t = 0
    DEELClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    routineTimer.add(1.000000)
    # update component parameters for each repeat
    Text_ndeel.setText(part_text)
    # keep track of which components have finished
    DEELComponents = [Text_ndeel]
    for thisComponent in DEELComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "DEEL"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = DEELClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Text_ndeel* updates
        if t >= 0.0 and Text_ndeel.status == NOT_STARTED:
            # keep track of start time/frame for later
            Text_ndeel.tStart = t  # not accounting for scr refresh
            Text_ndeel.frameNStart = frameN  # exact frame index
            win.timeOnFlip(Text_ndeel, 'tStartRefresh')  # time at next scr refresh
            Text_ndeel.setAutoDraw(True)
        frameRemains = 0.0 + 1- win.monitorFramePeriod * 0.75  # most of one frame period left
        if Text_ndeel.status == STARTED and t >= frameRemains:
            # keep track of stop time/frame for later
            Text_ndeel.tStop = t  # not accounting for scr refresh
            Text_ndeel.frameNStop = frameN  # exact frame index
            win.timeOnFlip(Text_ndeel, 'tStopRefresh')  # time at next scr refresh
            Text_ndeel.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in DEELComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "DEEL"-------
    for thisComponent in DEELComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    
    # ------Prepare to start Routine "response_instr_left"-------
    t = 0
    response_instr_leftClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    sample_training.setImage(links_COR)
    key_resp_7 = keyboard.Keyboard()
    links_text.setText(links)
    # keep track of which components have finished
    response_instr_leftComponents = [keyboard_picture, sample_training, key_resp_7, links_text, text_4]
    for thisComponent in response_instr_leftComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "response_instr_left"-------
    while continueRoutine:
        # get current time
        t = response_instr_leftClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *keyboard_picture* updates
        if t >= 0.0 and keyboard_picture.status == NOT_STARTED:
            # keep track of start time/frame for later
            keyboard_picture.tStart = t  # not accounting for scr refresh
            keyboard_picture.frameNStart = frameN  # exact frame index
            win.timeOnFlip(keyboard_picture, 'tStartRefresh')  # time at next scr refresh
            keyboard_picture.setAutoDraw(True)
        
        # *sample_training* updates
        if t >= 0.0 and sample_training.status == NOT_STARTED:
            # keep track of start time/frame for later
            sample_training.tStart = t  # not accounting for scr refresh
            sample_training.frameNStart = frameN  # exact frame index
            win.timeOnFlip(sample_training, 'tStartRefresh')  # time at next scr refresh
            sample_training.setAutoDraw(True)
        
        # *key_resp_7* updates
        if t >= 0.0 and key_resp_7.status == NOT_STARTED:
            # keep track of start time/frame for later
            key_resp_7.tStart = t  # not accounting for scr refresh
            key_resp_7.frameNStart = frameN  # exact frame index
            win.timeOnFlip(key_resp_7, 'tStartRefresh')  # time at next scr refresh
            key_resp_7.status = STARTED
            # keyboard checking is just starting
            key_resp_7.clearEvents(eventType='keyboard')
        if key_resp_7.status == STARTED:
            theseKeys = key_resp_7.getKeys(keyList=['f'], waitRelease=False)
            if len(theseKeys):
                theseKeys = theseKeys[0]  # at least one key was pressed
                
                # check for quit:
                if "escape" == theseKeys:
                    endExpNow = True
                # a response ends the routine
                continueRoutine = False
        
        # *links_text* updates
        if t >= 0.0 and links_text.status == NOT_STARTED:
            # keep track of start time/frame for later
            links_text.tStart = t  # not accounting for scr refresh
            links_text.frameNStart = frameN  # exact frame index
            win.timeOnFlip(links_text, 'tStartRefresh')  # time at next scr refresh
            links_text.setAutoDraw(True)
        
        # *text_4* updates
        if t >= 0.0 and text_4.status == NOT_STARTED:
            # keep track of start time/frame for later
            text_4.tStart = t  # not accounting for scr refresh
            text_4.frameNStart = frameN  # exact frame index
            win.timeOnFlip(text_4, 'tStartRefresh')  # time at next scr refresh
            text_4.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in response_instr_leftComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "response_instr_left"-------
    for thisComponent in response_instr_leftComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "response_instr_left" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "response_instr_right"-------
    t = 0
    response_instr_rightClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    key_resp_9 = keyboard.Keyboard()
    IMAGE.setImage(rechts_COR)
    text_3.setText(rechts)
    # keep track of which components have finished
    response_instr_rightComponents = [key_resp_9, IMAGE, text_3, keyboard_2, text_5]
    for thisComponent in response_instr_rightComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "response_instr_right"-------
    while continueRoutine:
        # get current time
        t = response_instr_rightClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *key_resp_9* updates
        if t >= 0.0 and key_resp_9.status == NOT_STARTED:
            # keep track of start time/frame for later
            key_resp_9.tStart = t  # not accounting for scr refresh
            key_resp_9.frameNStart = frameN  # exact frame index
            win.timeOnFlip(key_resp_9, 'tStartRefresh')  # time at next scr refresh
            key_resp_9.status = STARTED
            # keyboard checking is just starting
            key_resp_9.clearEvents(eventType='keyboard')
        if key_resp_9.status == STARTED:
            theseKeys = key_resp_9.getKeys(keyList=['j'], waitRelease=False)
            if len(theseKeys):
                theseKeys = theseKeys[0]  # at least one key was pressed
                
                # check for quit:
                if "escape" == theseKeys:
                    endExpNow = True
                # a response ends the routine
                continueRoutine = False
        
        # *IMAGE* updates
        if t >= 0.0 and IMAGE.status == NOT_STARTED:
            # keep track of start time/frame for later
            IMAGE.tStart = t  # not accounting for scr refresh
            IMAGE.frameNStart = frameN  # exact frame index
            win.timeOnFlip(IMAGE, 'tStartRefresh')  # time at next scr refresh
            IMAGE.setAutoDraw(True)
        
        # *text_3* updates
        if t >= 0.0 and text_3.status == NOT_STARTED:
            # keep track of start time/frame for later
            text_3.tStart = t  # not accounting for scr refresh
            text_3.frameNStart = frameN  # exact frame index
            win.timeOnFlip(text_3, 'tStartRefresh')  # time at next scr refresh
            text_3.setAutoDraw(True)
        
        # *keyboard_2* updates
        if t >= 0.0 and keyboard_2.status == NOT_STARTED:
            # keep track of start time/frame for later
            keyboard_2.tStart = t  # not accounting for scr refresh
            keyboard_2.frameNStart = frameN  # exact frame index
            win.timeOnFlip(keyboard_2, 'tStartRefresh')  # time at next scr refresh
            keyboard_2.setAutoDraw(True)
        
        # *text_5* updates
        if t >= 0.0 and text_5.status == NOT_STARTED:
            # keep track of start time/frame for later
            text_5.tStart = t  # not accounting for scr refresh
            text_5.frameNStart = frameN  # exact frame index
            win.timeOnFlip(text_5, 'tStartRefresh')  # time at next scr refresh
            text_5.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in response_instr_rightComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "response_instr_right"-------
    for thisComponent in response_instr_rightComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "response_instr_right" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "oefenen"-------
    t = 0
    oefenenClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    space_continue = keyboard.Keyboard()
    # keep track of which components have finished
    oefenenComponents = [training_txt, space_continue]
    for thisComponent in oefenenComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "oefenen"-------
    while continueRoutine:
        # get current time
        t = oefenenClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *training_txt* updates
        if t >= 0.0 and training_txt.status == NOT_STARTED:
            # keep track of start time/frame for later
            training_txt.tStart = t  # not accounting for scr refresh
            training_txt.frameNStart = frameN  # exact frame index
            win.timeOnFlip(training_txt, 'tStartRefresh')  # time at next scr refresh
            training_txt.setAutoDraw(True)
        
        # *space_continue* updates
        if t >= 0.0 and space_continue.status == NOT_STARTED:
            # keep track of start time/frame for later
            space_continue.tStart = t  # not accounting for scr refresh
            space_continue.frameNStart = frameN  # exact frame index
            win.timeOnFlip(space_continue, 'tStartRefresh')  # time at next scr refresh
            space_continue.status = STARTED
            # keyboard checking is just starting
            space_continue.clearEvents(eventType='keyboard')
        if space_continue.status == STARTED:
            theseKeys = space_continue.getKeys(keyList=['space'], waitRelease=False)
            if len(theseKeys):
                theseKeys = theseKeys[0]  # at least one key was pressed
                
                # check for quit:
                if "escape" == theseKeys:
                    endExpNow = True
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in oefenenComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "oefenen"-------
    for thisComponent in oefenenComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "oefenen" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    practice_trial = data.TrialHandler(nReps=1, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions(CondFiles_TRAINING),
        seed=None, name='practice_trial')
    thisExp.addLoop(practice_trial)  # add the loop to the experiment
    thisPractice_trial = practice_trial.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisPractice_trial.rgb)
    if thisPractice_trial != None:
        for paramName in thisPractice_trial:
            exec('{} = thisPractice_trial[paramName]'.format(paramName))
    
    for thisPractice_trial in practice_trial:
        currentLoop = practice_trial
        # abbreviate parameter names if possible (e.g. rgb = thisPractice_trial.rgb)
        if thisPractice_trial != None:
            for paramName in thisPractice_trial:
                exec('{} = thisPractice_trial[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "cue"-------
        t = 0
        cueClock.reset()  # clock
        frameN = -1
        continueRoutine = True
        routineTimer.add(2.500000)
        # update component parameters for each repeat
        right_cue.setText(cue_right)
        left_cue.setPos((-0.25,0))
        left_cue.setText(cue_left)
        # keep track of which components have finished
        cueComponents = [cross_fix_2, right_cue, left_cue]
        for thisComponent in cueComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        # -------Start Routine "cue"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = cueClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *cross_fix_2* updates
            if t >= 0.5 and cross_fix_2.status == NOT_STARTED:
                # keep track of start time/frame for later
                cross_fix_2.tStart = t  # not accounting for scr refresh
                cross_fix_2.frameNStart = frameN  # exact frame index
                win.timeOnFlip(cross_fix_2, 'tStartRefresh')  # time at next scr refresh
                cross_fix_2.setAutoDraw(True)
            frameRemains = 0.5 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
            if cross_fix_2.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                cross_fix_2.tStop = t  # not accounting for scr refresh
                cross_fix_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(cross_fix_2, 'tStopRefresh')  # time at next scr refresh
                cross_fix_2.setAutoDraw(False)
            
            # *right_cue* updates
            if t >= 1.5 and right_cue.status == NOT_STARTED:
                # keep track of start time/frame for later
                right_cue.tStart = t  # not accounting for scr refresh
                right_cue.frameNStart = frameN  # exact frame index
                win.timeOnFlip(right_cue, 'tStartRefresh')  # time at next scr refresh
                right_cue.setAutoDraw(True)
            frameRemains = 1.5 + 1- win.monitorFramePeriod * 0.75  # most of one frame period left
            if right_cue.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                right_cue.tStop = t  # not accounting for scr refresh
                right_cue.frameNStop = frameN  # exact frame index
                win.timeOnFlip(right_cue, 'tStopRefresh')  # time at next scr refresh
                right_cue.setAutoDraw(False)
            
            # *left_cue* updates
            if t >= 1.5 and left_cue.status == NOT_STARTED:
                # keep track of start time/frame for later
                left_cue.tStart = t  # not accounting for scr refresh
                left_cue.frameNStart = frameN  # exact frame index
                win.timeOnFlip(left_cue, 'tStartRefresh')  # time at next scr refresh
                left_cue.setAutoDraw(True)
            frameRemains = 1.5 + 1- win.monitorFramePeriod * 0.75  # most of one frame period left
            if left_cue.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                left_cue.tStop = t  # not accounting for scr refresh
                left_cue.frameNStop = frameN  # exact frame index
                win.timeOnFlip(left_cue, 'tStopRefresh')  # time at next scr refresh
                left_cue.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in cueComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "cue"-------
        for thisComponent in cueComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        
        # ------Prepare to start Routine "EXP1_experiment"-------
        t = 0
        EXP1_experimentClock.reset()  # clock
        frameN = -1
        continueRoutine = True
        # update component parameters for each repeat
        image_1.setPos((X1,Y1))
        image_1.setImage(IMG1)
        image_2.setPos((X2,Y2))
        image_2.setImage(IMG2)
        image_3.setPos((X3,Y3))
        image_3.setImage(IMG3)
        image_4.setPos((X4,Y4))
        image_4.setImage(IMG4)
        image_5.setPos((X5,Y5))
        image_5.setImage(IMG5)
        image_6.setPos((X6,Y6))
        image_6.setImage(IMG6)
        image_12.setPos((X7,Y7))
        image_12.setImage(IMG7)
        image8.setPos((X8,Y8))
        image8.setImage(IMG8)
        response = keyboard.Keyboard()
        # keep track of which components have finished
        EXP1_experimentComponents = [fixation, image_1, image_2, image_3, image_4, image_5, image_6, image_12, image8, response]
        for thisComponent in EXP1_experimentComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        # -------Start Routine "EXP1_experiment"-------
        while continueRoutine:
            # get current time
            t = EXP1_experimentClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *fixation* updates
            if t >= 0 and fixation.status == NOT_STARTED:
                # keep track of start time/frame for later
                fixation.tStart = t  # not accounting for scr refresh
                fixation.frameNStart = frameN  # exact frame index
                win.timeOnFlip(fixation, 'tStartRefresh')  # time at next scr refresh
                fixation.setAutoDraw(True)
            frameRemains = 0 + 5- win.monitorFramePeriod * 0.75  # most of one frame period left
            if fixation.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                fixation.tStop = t  # not accounting for scr refresh
                fixation.frameNStop = frameN  # exact frame index
                win.timeOnFlip(fixation, 'tStopRefresh')  # time at next scr refresh
                fixation.setAutoDraw(False)
            
            # *image_1* updates
            if t >= 0 and image_1.status == NOT_STARTED:
                # keep track of start time/frame for later
                image_1.tStart = t  # not accounting for scr refresh
                image_1.frameNStart = frameN  # exact frame index
                win.timeOnFlip(image_1, 'tStartRefresh')  # time at next scr refresh
                image_1.setAutoDraw(True)
            frameRemains = 0 + time- win.monitorFramePeriod * 0.75  # most of one frame period left
            if image_1.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                image_1.tStop = t  # not accounting for scr refresh
                image_1.frameNStop = frameN  # exact frame index
                win.timeOnFlip(image_1, 'tStopRefresh')  # time at next scr refresh
                image_1.setAutoDraw(False)
            
            # *image_2* updates
            if t >= 0 and image_2.status == NOT_STARTED:
                # keep track of start time/frame for later
                image_2.tStart = t  # not accounting for scr refresh
                image_2.frameNStart = frameN  # exact frame index
                win.timeOnFlip(image_2, 'tStartRefresh')  # time at next scr refresh
                image_2.setAutoDraw(True)
            frameRemains = 0 + time- win.monitorFramePeriod * 0.75  # most of one frame period left
            if image_2.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                image_2.tStop = t  # not accounting for scr refresh
                image_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(image_2, 'tStopRefresh')  # time at next scr refresh
                image_2.setAutoDraw(False)
            
            # *image_3* updates
            if t >= 0 and image_3.status == NOT_STARTED:
                # keep track of start time/frame for later
                image_3.tStart = t  # not accounting for scr refresh
                image_3.frameNStart = frameN  # exact frame index
                win.timeOnFlip(image_3, 'tStartRefresh')  # time at next scr refresh
                image_3.setAutoDraw(True)
            frameRemains = 0 + time- win.monitorFramePeriod * 0.75  # most of one frame period left
            if image_3.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                image_3.tStop = t  # not accounting for scr refresh
                image_3.frameNStop = frameN  # exact frame index
                win.timeOnFlip(image_3, 'tStopRefresh')  # time at next scr refresh
                image_3.setAutoDraw(False)
            
            # *image_4* updates
            if t >= 0 and image_4.status == NOT_STARTED:
                # keep track of start time/frame for later
                image_4.tStart = t  # not accounting for scr refresh
                image_4.frameNStart = frameN  # exact frame index
                win.timeOnFlip(image_4, 'tStartRefresh')  # time at next scr refresh
                image_4.setAutoDraw(True)
            frameRemains = 0 + time- win.monitorFramePeriod * 0.75  # most of one frame period left
            if image_4.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                image_4.tStop = t  # not accounting for scr refresh
                image_4.frameNStop = frameN  # exact frame index
                win.timeOnFlip(image_4, 'tStopRefresh')  # time at next scr refresh
                image_4.setAutoDraw(False)
            
            # *image_5* updates
            if t >= 0 and image_5.status == NOT_STARTED:
                # keep track of start time/frame for later
                image_5.tStart = t  # not accounting for scr refresh
                image_5.frameNStart = frameN  # exact frame index
                win.timeOnFlip(image_5, 'tStartRefresh')  # time at next scr refresh
                image_5.setAutoDraw(True)
            frameRemains = 0 + time- win.monitorFramePeriod * 0.75  # most of one frame period left
            if image_5.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                image_5.tStop = t  # not accounting for scr refresh
                image_5.frameNStop = frameN  # exact frame index
                win.timeOnFlip(image_5, 'tStopRefresh')  # time at next scr refresh
                image_5.setAutoDraw(False)
            
            # *image_6* updates
            if t >= 0 and image_6.status == NOT_STARTED:
                # keep track of start time/frame for later
                image_6.tStart = t  # not accounting for scr refresh
                image_6.frameNStart = frameN  # exact frame index
                win.timeOnFlip(image_6, 'tStartRefresh')  # time at next scr refresh
                image_6.setAutoDraw(True)
            frameRemains = 0 + time- win.monitorFramePeriod * 0.75  # most of one frame period left
            if image_6.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                image_6.tStop = t  # not accounting for scr refresh
                image_6.frameNStop = frameN  # exact frame index
                win.timeOnFlip(image_6, 'tStopRefresh')  # time at next scr refresh
                image_6.setAutoDraw(False)
            
            # *image_12* updates
            if t >= 0 and image_12.status == NOT_STARTED:
                # keep track of start time/frame for later
                image_12.tStart = t  # not accounting for scr refresh
                image_12.frameNStart = frameN  # exact frame index
                win.timeOnFlip(image_12, 'tStartRefresh')  # time at next scr refresh
                image_12.setAutoDraw(True)
            frameRemains = 0 + time- win.monitorFramePeriod * 0.75  # most of one frame period left
            if image_12.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                image_12.tStop = t  # not accounting for scr refresh
                image_12.frameNStop = frameN  # exact frame index
                win.timeOnFlip(image_12, 'tStopRefresh')  # time at next scr refresh
                image_12.setAutoDraw(False)
            
            # *image8* updates
            if t >= 0 and image8.status == NOT_STARTED:
                # keep track of start time/frame for later
                image8.tStart = t  # not accounting for scr refresh
                image8.frameNStart = frameN  # exact frame index
                win.timeOnFlip(image8, 'tStartRefresh')  # time at next scr refresh
                image8.setAutoDraw(True)
            frameRemains = 0 + time- win.monitorFramePeriod * 0.75  # most of one frame period left
            if image8.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                image8.tStop = t  # not accounting for scr refresh
                image8.frameNStop = frameN  # exact frame index
                win.timeOnFlip(image8, 'tStopRefresh')  # time at next scr refresh
                image8.setAutoDraw(False)
            
            # *response* updates
            if t >= 0.0 and response.status == NOT_STARTED:
                # keep track of start time/frame for later
                response.tStart = t  # not accounting for scr refresh
                response.frameNStart = frameN  # exact frame index
                win.timeOnFlip(response, 'tStartRefresh')  # time at next scr refresh
                response.status = STARTED
                # keyboard checking is just starting
                win.callOnFlip(response.clock.reset)  # t=0 on next screen flip
                response.clearEvents(eventType='keyboard')
            frameRemains = 0.0 + 5- win.monitorFramePeriod * 0.75  # most of one frame period left
            if response.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                response.tStop = t  # not accounting for scr refresh
                response.frameNStop = frameN  # exact frame index
                win.timeOnFlip(response, 'tStopRefresh')  # time at next scr refresh
                response.status = FINISHED
            if response.status == STARTED:
                theseKeys = response.getKeys(keyList=['f', 'j'], waitRelease=False)
                if len(theseKeys):
                    theseKeys = theseKeys[0]  # at least one key was pressed
                    
                    # check for quit:
                    if "escape" == theseKeys:
                        endExpNow = True
                    response.keys = theseKeys.name  # just the last key pressed
                    response.rt = theseKeys.rt
                    # was this 'correct'?
                    if (response.keys == str(CorResp)) or (response.keys == CorResp):
                        response.corr = 1
                    else:
                        response.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in EXP1_experimentComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "EXP1_experiment"-------
        for thisComponent in EXP1_experimentComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # check responses
        if response.keys in ['', [], None]:  # No response was made
            response.keys = None
            # was no response the correct answer?!
            if str(CorResp).lower() == 'none':
               response.corr = 1;  # correct non-response
            else:
               response.corr = 0;  # failed to respond (incorrectly)
        # store data for practice_trial (TrialHandler)
        practice_trial.addData('response.keys',response.keys)
        practice_trial.addData('response.corr', response.corr)
        if response.keys != None:  # we had a response
            practice_trial.addData('response.rt', response.rt)
        # the Routine "EXP1_experiment" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # ------Prepare to start Routine "Feedback_2"-------
        t = 0
        Feedback_2Clock.reset()  # clock
        frameN = -1
        continueRoutine = True
        # update component parameters for each repeat
        if not response.keys :
            msg="Te laat!"
            msg_color = "white"
        elif response.corr:#stored on last run routine
            msg="Correct!"
            msg_color = "green"
            ACC = ACC+1
        else:
            msg="Incorrect!"
            msg_color = "red"
        trial = trial+1 ## end routine if min 32 and ACC of 75%
        if trial>1 and ACC/trial>0.70:
            practice_trial.finished = True 
        # keep track of which components have finished
        Feedback_2Components = []
        for thisComponent in Feedback_2Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        # -------Start Routine "Feedback_2"-------
        while continueRoutine:
            # get current time
            t = Feedback_2Clock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Feedback_2Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "Feedback_2"-------
        for thisComponent in Feedback_2Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # the Routine "Feedback_2" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # ------Prepare to start Routine "FB_text"-------
        t = 0
        FB_textClock.reset()  # clock
        frameN = -1
        continueRoutine = True
        routineTimer.add(2.000000)
        # update component parameters for each repeat
        Feedback.setColor(msg_color, colorSpace='rgb')
        Feedback.setText(msg)
        text_9.setText(overbalance)
        # keep track of which components have finished
        FB_textComponents = [Feedback, merendeel, text_9, training_session]
        for thisComponent in FB_textComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        # -------Start Routine "FB_text"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = FB_textClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *Feedback* updates
            if t >= 0.0 and Feedback.status == NOT_STARTED:
                # keep track of start time/frame for later
                Feedback.tStart = t  # not accounting for scr refresh
                Feedback.frameNStart = frameN  # exact frame index
                win.timeOnFlip(Feedback, 'tStartRefresh')  # time at next scr refresh
                Feedback.setAutoDraw(True)
            frameRemains = 0.0 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
            if Feedback.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                Feedback.tStop = t  # not accounting for scr refresh
                Feedback.frameNStop = frameN  # exact frame index
                win.timeOnFlip(Feedback, 'tStopRefresh')  # time at next scr refresh
                Feedback.setAutoDraw(False)
            
            # *merendeel* updates
            if t >= 0.0 and merendeel.status == NOT_STARTED:
                # keep track of start time/frame for later
                merendeel.tStart = t  # not accounting for scr refresh
                merendeel.frameNStart = frameN  # exact frame index
                win.timeOnFlip(merendeel, 'tStartRefresh')  # time at next scr refresh
                merendeel.setAutoDraw(True)
            frameRemains = 0.0 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
            if merendeel.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                merendeel.tStop = t  # not accounting for scr refresh
                merendeel.frameNStop = frameN  # exact frame index
                win.timeOnFlip(merendeel, 'tStopRefresh')  # time at next scr refresh
                merendeel.setAutoDraw(False)
            
            # *text_9* updates
            if t >= 0.0 and text_9.status == NOT_STARTED:
                # keep track of start time/frame for later
                text_9.tStart = t  # not accounting for scr refresh
                text_9.frameNStart = frameN  # exact frame index
                win.timeOnFlip(text_9, 'tStartRefresh')  # time at next scr refresh
                text_9.setAutoDraw(True)
            frameRemains = 0.0 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
            if text_9.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                text_9.tStop = t  # not accounting for scr refresh
                text_9.frameNStop = frameN  # exact frame index
                win.timeOnFlip(text_9, 'tStopRefresh')  # time at next scr refresh
                text_9.setAutoDraw(False)
            
            # *training_session* updates
            if t >= 0.0 and training_session.status == NOT_STARTED:
                # keep track of start time/frame for later
                training_session.tStart = t  # not accounting for scr refresh
                training_session.frameNStart = frameN  # exact frame index
                win.timeOnFlip(training_session, 'tStartRefresh')  # time at next scr refresh
                training_session.setAutoDraw(True)
            frameRemains = 0.0 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
            if training_session.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                training_session.tStop = t  # not accounting for scr refresh
                training_session.frameNStop = frameN  # exact frame index
                win.timeOnFlip(training_session, 'tStopRefresh')  # time at next scr refresh
                training_session.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in FB_textComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "FB_text"-------
        for thisComponent in FB_textComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.nextEntry()
        
    # completed 1 repeats of 'practice_trial'
    
    # get names of stimulus parameters
    if practice_trial.trialList in ([], [None], None):
        params = []
    else:
        params = practice_trial.trialList[0].keys()
    # save data for this loop
    practice_trial.saveAsExcel(filename + '.xlsx', sheetName='practice_trial',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    practice_trial.saveAsText(filename + 'practice_trial.csv', delim=',',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    
    # ------Prepare to start Routine "post_FB"-------
    t = 0
    post_FBClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    trial = 15
    ACC   = 0
    # keep track of which components have finished
    post_FBComponents = []
    for thisComponent in post_FBComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "post_FB"-------
    while continueRoutine:
        # get current time
        t = post_FBClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in post_FBComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "post_FB"-------
    for thisComponent in post_FBComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "post_FB" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "Instruc_start"-------
    t = 0
    Instruc_startClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    key_resp_12 = keyboard.Keyboard()
    # keep track of which components have finished
    Instruc_startComponents = [text_10, key_resp_12]
    for thisComponent in Instruc_startComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "Instruc_start"-------
    while continueRoutine:
        # get current time
        t = Instruc_startClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_10* updates
        if t >= 0.0 and text_10.status == NOT_STARTED:
            # keep track of start time/frame for later
            text_10.tStart = t  # not accounting for scr refresh
            text_10.frameNStart = frameN  # exact frame index
            win.timeOnFlip(text_10, 'tStartRefresh')  # time at next scr refresh
            text_10.setAutoDraw(True)
        
        # *key_resp_12* updates
        if t >= 0.0 and key_resp_12.status == NOT_STARTED:
            # keep track of start time/frame for later
            key_resp_12.tStart = t  # not accounting for scr refresh
            key_resp_12.frameNStart = frameN  # exact frame index
            win.timeOnFlip(key_resp_12, 'tStartRefresh')  # time at next scr refresh
            key_resp_12.status = STARTED
            # keyboard checking is just starting
            key_resp_12.clearEvents(eventType='keyboard')
        if key_resp_12.status == STARTED:
            theseKeys = key_resp_12.getKeys(keyList=['space'], waitRelease=False)
            if len(theseKeys):
                theseKeys = theseKeys[0]  # at least one key was pressed
                
                # check for quit:
                if "escape" == theseKeys:
                    endExpNow = True
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Instruc_startComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Instruc_start"-------
    for thisComponent in Instruc_startComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "Instruc_start" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "response_instr_left"-------
    t = 0
    response_instr_leftClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    sample_training.setImage(links_COR)
    key_resp_7 = keyboard.Keyboard()
    links_text.setText(links)
    # keep track of which components have finished
    response_instr_leftComponents = [keyboard_picture, sample_training, key_resp_7, links_text, text_4]
    for thisComponent in response_instr_leftComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "response_instr_left"-------
    while continueRoutine:
        # get current time
        t = response_instr_leftClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *keyboard_picture* updates
        if t >= 0.0 and keyboard_picture.status == NOT_STARTED:
            # keep track of start time/frame for later
            keyboard_picture.tStart = t  # not accounting for scr refresh
            keyboard_picture.frameNStart = frameN  # exact frame index
            win.timeOnFlip(keyboard_picture, 'tStartRefresh')  # time at next scr refresh
            keyboard_picture.setAutoDraw(True)
        
        # *sample_training* updates
        if t >= 0.0 and sample_training.status == NOT_STARTED:
            # keep track of start time/frame for later
            sample_training.tStart = t  # not accounting for scr refresh
            sample_training.frameNStart = frameN  # exact frame index
            win.timeOnFlip(sample_training, 'tStartRefresh')  # time at next scr refresh
            sample_training.setAutoDraw(True)
        
        # *key_resp_7* updates
        if t >= 0.0 and key_resp_7.status == NOT_STARTED:
            # keep track of start time/frame for later
            key_resp_7.tStart = t  # not accounting for scr refresh
            key_resp_7.frameNStart = frameN  # exact frame index
            win.timeOnFlip(key_resp_7, 'tStartRefresh')  # time at next scr refresh
            key_resp_7.status = STARTED
            # keyboard checking is just starting
            key_resp_7.clearEvents(eventType='keyboard')
        if key_resp_7.status == STARTED:
            theseKeys = key_resp_7.getKeys(keyList=['f'], waitRelease=False)
            if len(theseKeys):
                theseKeys = theseKeys[0]  # at least one key was pressed
                
                # check for quit:
                if "escape" == theseKeys:
                    endExpNow = True
                # a response ends the routine
                continueRoutine = False
        
        # *links_text* updates
        if t >= 0.0 and links_text.status == NOT_STARTED:
            # keep track of start time/frame for later
            links_text.tStart = t  # not accounting for scr refresh
            links_text.frameNStart = frameN  # exact frame index
            win.timeOnFlip(links_text, 'tStartRefresh')  # time at next scr refresh
            links_text.setAutoDraw(True)
        
        # *text_4* updates
        if t >= 0.0 and text_4.status == NOT_STARTED:
            # keep track of start time/frame for later
            text_4.tStart = t  # not accounting for scr refresh
            text_4.frameNStart = frameN  # exact frame index
            win.timeOnFlip(text_4, 'tStartRefresh')  # time at next scr refresh
            text_4.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in response_instr_leftComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "response_instr_left"-------
    for thisComponent in response_instr_leftComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "response_instr_left" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "response_instr_right"-------
    t = 0
    response_instr_rightClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    key_resp_9 = keyboard.Keyboard()
    IMAGE.setImage(rechts_COR)
    text_3.setText(rechts)
    # keep track of which components have finished
    response_instr_rightComponents = [key_resp_9, IMAGE, text_3, keyboard_2, text_5]
    for thisComponent in response_instr_rightComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "response_instr_right"-------
    while continueRoutine:
        # get current time
        t = response_instr_rightClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *key_resp_9* updates
        if t >= 0.0 and key_resp_9.status == NOT_STARTED:
            # keep track of start time/frame for later
            key_resp_9.tStart = t  # not accounting for scr refresh
            key_resp_9.frameNStart = frameN  # exact frame index
            win.timeOnFlip(key_resp_9, 'tStartRefresh')  # time at next scr refresh
            key_resp_9.status = STARTED
            # keyboard checking is just starting
            key_resp_9.clearEvents(eventType='keyboard')
        if key_resp_9.status == STARTED:
            theseKeys = key_resp_9.getKeys(keyList=['j'], waitRelease=False)
            if len(theseKeys):
                theseKeys = theseKeys[0]  # at least one key was pressed
                
                # check for quit:
                if "escape" == theseKeys:
                    endExpNow = True
                # a response ends the routine
                continueRoutine = False
        
        # *IMAGE* updates
        if t >= 0.0 and IMAGE.status == NOT_STARTED:
            # keep track of start time/frame for later
            IMAGE.tStart = t  # not accounting for scr refresh
            IMAGE.frameNStart = frameN  # exact frame index
            win.timeOnFlip(IMAGE, 'tStartRefresh')  # time at next scr refresh
            IMAGE.setAutoDraw(True)
        
        # *text_3* updates
        if t >= 0.0 and text_3.status == NOT_STARTED:
            # keep track of start time/frame for later
            text_3.tStart = t  # not accounting for scr refresh
            text_3.frameNStart = frameN  # exact frame index
            win.timeOnFlip(text_3, 'tStartRefresh')  # time at next scr refresh
            text_3.setAutoDraw(True)
        
        # *keyboard_2* updates
        if t >= 0.0 and keyboard_2.status == NOT_STARTED:
            # keep track of start time/frame for later
            keyboard_2.tStart = t  # not accounting for scr refresh
            keyboard_2.frameNStart = frameN  # exact frame index
            win.timeOnFlip(keyboard_2, 'tStartRefresh')  # time at next scr refresh
            keyboard_2.setAutoDraw(True)
        
        # *text_5* updates
        if t >= 0.0 and text_5.status == NOT_STARTED:
            # keep track of start time/frame for later
            text_5.tStart = t  # not accounting for scr refresh
            text_5.frameNStart = frameN  # exact frame index
            win.timeOnFlip(text_5, 'tStartRefresh')  # time at next scr refresh
            text_5.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in response_instr_rightComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "response_instr_right"-------
    for thisComponent in response_instr_rightComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "response_instr_right" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "EXP1_START"-------
    t = 0
    EXP1_STARTClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    key_resp_10 = keyboard.Keyboard()
    # keep track of which components have finished
    EXP1_STARTComponents = [text_7, key_resp_10, text_8]
    for thisComponent in EXP1_STARTComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "EXP1_START"-------
    while continueRoutine:
        # get current time
        t = EXP1_STARTClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_7* updates
        if t >= 0.0 and text_7.status == NOT_STARTED:
            # keep track of start time/frame for later
            text_7.tStart = t  # not accounting for scr refresh
            text_7.frameNStart = frameN  # exact frame index
            win.timeOnFlip(text_7, 'tStartRefresh')  # time at next scr refresh
            text_7.setAutoDraw(True)
        
        # *key_resp_10* updates
        if t >= 0.0 and key_resp_10.status == NOT_STARTED:
            # keep track of start time/frame for later
            key_resp_10.tStart = t  # not accounting for scr refresh
            key_resp_10.frameNStart = frameN  # exact frame index
            win.timeOnFlip(key_resp_10, 'tStartRefresh')  # time at next scr refresh
            key_resp_10.status = STARTED
            # keyboard checking is just starting
            key_resp_10.clearEvents(eventType='keyboard')
        if key_resp_10.status == STARTED:
            theseKeys = key_resp_10.getKeys(keyList=['space'], waitRelease=False)
            if len(theseKeys):
                theseKeys = theseKeys[0]  # at least one key was pressed
                
                # check for quit:
                if "escape" == theseKeys:
                    endExpNow = True
                # a response ends the routine
                continueRoutine = False
        
        # *text_8* updates
        if t >= 0.0 and text_8.status == NOT_STARTED:
            # keep track of start time/frame for later
            text_8.tStart = t  # not accounting for scr refresh
            text_8.frameNStart = frameN  # exact frame index
            win.timeOnFlip(text_8, 'tStartRefresh')  # time at next scr refresh
            text_8.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in EXP1_STARTComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "EXP1_START"-------
    for thisComponent in EXP1_STARTComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "EXP1_START" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    Experimental_trial = data.TrialHandler(nReps=1, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions(CondFiles_EXP),
        seed=None, name='Experimental_trial')
    thisExp.addLoop(Experimental_trial)  # add the loop to the experiment
    thisExperimental_trial = Experimental_trial.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisExperimental_trial.rgb)
    if thisExperimental_trial != None:
        for paramName in thisExperimental_trial:
            exec('{} = thisExperimental_trial[paramName]'.format(paramName))
    
    for thisExperimental_trial in Experimental_trial:
        currentLoop = Experimental_trial
        # abbreviate parameter names if possible (e.g. rgb = thisExperimental_trial.rgb)
        if thisExperimental_trial != None:
            for paramName in thisExperimental_trial:
                exec('{} = thisExperimental_trial[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "cue"-------
        t = 0
        cueClock.reset()  # clock
        frameN = -1
        continueRoutine = True
        routineTimer.add(2.500000)
        # update component parameters for each repeat
        right_cue.setText(cue_right)
        left_cue.setPos((-0.25,0))
        left_cue.setText(cue_left)
        # keep track of which components have finished
        cueComponents = [cross_fix_2, right_cue, left_cue]
        for thisComponent in cueComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        # -------Start Routine "cue"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = cueClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *cross_fix_2* updates
            if t >= 0.5 and cross_fix_2.status == NOT_STARTED:
                # keep track of start time/frame for later
                cross_fix_2.tStart = t  # not accounting for scr refresh
                cross_fix_2.frameNStart = frameN  # exact frame index
                win.timeOnFlip(cross_fix_2, 'tStartRefresh')  # time at next scr refresh
                cross_fix_2.setAutoDraw(True)
            frameRemains = 0.5 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
            if cross_fix_2.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                cross_fix_2.tStop = t  # not accounting for scr refresh
                cross_fix_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(cross_fix_2, 'tStopRefresh')  # time at next scr refresh
                cross_fix_2.setAutoDraw(False)
            
            # *right_cue* updates
            if t >= 1.5 and right_cue.status == NOT_STARTED:
                # keep track of start time/frame for later
                right_cue.tStart = t  # not accounting for scr refresh
                right_cue.frameNStart = frameN  # exact frame index
                win.timeOnFlip(right_cue, 'tStartRefresh')  # time at next scr refresh
                right_cue.setAutoDraw(True)
            frameRemains = 1.5 + 1- win.monitorFramePeriod * 0.75  # most of one frame period left
            if right_cue.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                right_cue.tStop = t  # not accounting for scr refresh
                right_cue.frameNStop = frameN  # exact frame index
                win.timeOnFlip(right_cue, 'tStopRefresh')  # time at next scr refresh
                right_cue.setAutoDraw(False)
            
            # *left_cue* updates
            if t >= 1.5 and left_cue.status == NOT_STARTED:
                # keep track of start time/frame for later
                left_cue.tStart = t  # not accounting for scr refresh
                left_cue.frameNStart = frameN  # exact frame index
                win.timeOnFlip(left_cue, 'tStartRefresh')  # time at next scr refresh
                left_cue.setAutoDraw(True)
            frameRemains = 1.5 + 1- win.monitorFramePeriod * 0.75  # most of one frame period left
            if left_cue.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                left_cue.tStop = t  # not accounting for scr refresh
                left_cue.frameNStop = frameN  # exact frame index
                win.timeOnFlip(left_cue, 'tStopRefresh')  # time at next scr refresh
                left_cue.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in cueComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "cue"-------
        for thisComponent in cueComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        
        # ------Prepare to start Routine "EXP1_experiment"-------
        t = 0
        EXP1_experimentClock.reset()  # clock
        frameN = -1
        continueRoutine = True
        # update component parameters for each repeat
        image_1.setPos((X1,Y1))
        image_1.setImage(IMG1)
        image_2.setPos((X2,Y2))
        image_2.setImage(IMG2)
        image_3.setPos((X3,Y3))
        image_3.setImage(IMG3)
        image_4.setPos((X4,Y4))
        image_4.setImage(IMG4)
        image_5.setPos((X5,Y5))
        image_5.setImage(IMG5)
        image_6.setPos((X6,Y6))
        image_6.setImage(IMG6)
        image_12.setPos((X7,Y7))
        image_12.setImage(IMG7)
        image8.setPos((X8,Y8))
        image8.setImage(IMG8)
        response = keyboard.Keyboard()
        # keep track of which components have finished
        EXP1_experimentComponents = [fixation, image_1, image_2, image_3, image_4, image_5, image_6, image_12, image8, response]
        for thisComponent in EXP1_experimentComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        # -------Start Routine "EXP1_experiment"-------
        while continueRoutine:
            # get current time
            t = EXP1_experimentClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *fixation* updates
            if t >= 0 and fixation.status == NOT_STARTED:
                # keep track of start time/frame for later
                fixation.tStart = t  # not accounting for scr refresh
                fixation.frameNStart = frameN  # exact frame index
                win.timeOnFlip(fixation, 'tStartRefresh')  # time at next scr refresh
                fixation.setAutoDraw(True)
            frameRemains = 0 + 5- win.monitorFramePeriod * 0.75  # most of one frame period left
            if fixation.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                fixation.tStop = t  # not accounting for scr refresh
                fixation.frameNStop = frameN  # exact frame index
                win.timeOnFlip(fixation, 'tStopRefresh')  # time at next scr refresh
                fixation.setAutoDraw(False)
            
            # *image_1* updates
            if t >= 0 and image_1.status == NOT_STARTED:
                # keep track of start time/frame for later
                image_1.tStart = t  # not accounting for scr refresh
                image_1.frameNStart = frameN  # exact frame index
                win.timeOnFlip(image_1, 'tStartRefresh')  # time at next scr refresh
                image_1.setAutoDraw(True)
            frameRemains = 0 + time- win.monitorFramePeriod * 0.75  # most of one frame period left
            if image_1.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                image_1.tStop = t  # not accounting for scr refresh
                image_1.frameNStop = frameN  # exact frame index
                win.timeOnFlip(image_1, 'tStopRefresh')  # time at next scr refresh
                image_1.setAutoDraw(False)
            
            # *image_2* updates
            if t >= 0 and image_2.status == NOT_STARTED:
                # keep track of start time/frame for later
                image_2.tStart = t  # not accounting for scr refresh
                image_2.frameNStart = frameN  # exact frame index
                win.timeOnFlip(image_2, 'tStartRefresh')  # time at next scr refresh
                image_2.setAutoDraw(True)
            frameRemains = 0 + time- win.monitorFramePeriod * 0.75  # most of one frame period left
            if image_2.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                image_2.tStop = t  # not accounting for scr refresh
                image_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(image_2, 'tStopRefresh')  # time at next scr refresh
                image_2.setAutoDraw(False)
            
            # *image_3* updates
            if t >= 0 and image_3.status == NOT_STARTED:
                # keep track of start time/frame for later
                image_3.tStart = t  # not accounting for scr refresh
                image_3.frameNStart = frameN  # exact frame index
                win.timeOnFlip(image_3, 'tStartRefresh')  # time at next scr refresh
                image_3.setAutoDraw(True)
            frameRemains = 0 + time- win.monitorFramePeriod * 0.75  # most of one frame period left
            if image_3.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                image_3.tStop = t  # not accounting for scr refresh
                image_3.frameNStop = frameN  # exact frame index
                win.timeOnFlip(image_3, 'tStopRefresh')  # time at next scr refresh
                image_3.setAutoDraw(False)
            
            # *image_4* updates
            if t >= 0 and image_4.status == NOT_STARTED:
                # keep track of start time/frame for later
                image_4.tStart = t  # not accounting for scr refresh
                image_4.frameNStart = frameN  # exact frame index
                win.timeOnFlip(image_4, 'tStartRefresh')  # time at next scr refresh
                image_4.setAutoDraw(True)
            frameRemains = 0 + time- win.monitorFramePeriod * 0.75  # most of one frame period left
            if image_4.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                image_4.tStop = t  # not accounting for scr refresh
                image_4.frameNStop = frameN  # exact frame index
                win.timeOnFlip(image_4, 'tStopRefresh')  # time at next scr refresh
                image_4.setAutoDraw(False)
            
            # *image_5* updates
            if t >= 0 and image_5.status == NOT_STARTED:
                # keep track of start time/frame for later
                image_5.tStart = t  # not accounting for scr refresh
                image_5.frameNStart = frameN  # exact frame index
                win.timeOnFlip(image_5, 'tStartRefresh')  # time at next scr refresh
                image_5.setAutoDraw(True)
            frameRemains = 0 + time- win.monitorFramePeriod * 0.75  # most of one frame period left
            if image_5.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                image_5.tStop = t  # not accounting for scr refresh
                image_5.frameNStop = frameN  # exact frame index
                win.timeOnFlip(image_5, 'tStopRefresh')  # time at next scr refresh
                image_5.setAutoDraw(False)
            
            # *image_6* updates
            if t >= 0 and image_6.status == NOT_STARTED:
                # keep track of start time/frame for later
                image_6.tStart = t  # not accounting for scr refresh
                image_6.frameNStart = frameN  # exact frame index
                win.timeOnFlip(image_6, 'tStartRefresh')  # time at next scr refresh
                image_6.setAutoDraw(True)
            frameRemains = 0 + time- win.monitorFramePeriod * 0.75  # most of one frame period left
            if image_6.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                image_6.tStop = t  # not accounting for scr refresh
                image_6.frameNStop = frameN  # exact frame index
                win.timeOnFlip(image_6, 'tStopRefresh')  # time at next scr refresh
                image_6.setAutoDraw(False)
            
            # *image_12* updates
            if t >= 0 and image_12.status == NOT_STARTED:
                # keep track of start time/frame for later
                image_12.tStart = t  # not accounting for scr refresh
                image_12.frameNStart = frameN  # exact frame index
                win.timeOnFlip(image_12, 'tStartRefresh')  # time at next scr refresh
                image_12.setAutoDraw(True)
            frameRemains = 0 + time- win.monitorFramePeriod * 0.75  # most of one frame period left
            if image_12.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                image_12.tStop = t  # not accounting for scr refresh
                image_12.frameNStop = frameN  # exact frame index
                win.timeOnFlip(image_12, 'tStopRefresh')  # time at next scr refresh
                image_12.setAutoDraw(False)
            
            # *image8* updates
            if t >= 0 and image8.status == NOT_STARTED:
                # keep track of start time/frame for later
                image8.tStart = t  # not accounting for scr refresh
                image8.frameNStart = frameN  # exact frame index
                win.timeOnFlip(image8, 'tStartRefresh')  # time at next scr refresh
                image8.setAutoDraw(True)
            frameRemains = 0 + time- win.monitorFramePeriod * 0.75  # most of one frame period left
            if image8.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                image8.tStop = t  # not accounting for scr refresh
                image8.frameNStop = frameN  # exact frame index
                win.timeOnFlip(image8, 'tStopRefresh')  # time at next scr refresh
                image8.setAutoDraw(False)
            
            # *response* updates
            if t >= 0.0 and response.status == NOT_STARTED:
                # keep track of start time/frame for later
                response.tStart = t  # not accounting for scr refresh
                response.frameNStart = frameN  # exact frame index
                win.timeOnFlip(response, 'tStartRefresh')  # time at next scr refresh
                response.status = STARTED
                # keyboard checking is just starting
                win.callOnFlip(response.clock.reset)  # t=0 on next screen flip
                response.clearEvents(eventType='keyboard')
            frameRemains = 0.0 + 5- win.monitorFramePeriod * 0.75  # most of one frame period left
            if response.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                response.tStop = t  # not accounting for scr refresh
                response.frameNStop = frameN  # exact frame index
                win.timeOnFlip(response, 'tStopRefresh')  # time at next scr refresh
                response.status = FINISHED
            if response.status == STARTED:
                theseKeys = response.getKeys(keyList=['f', 'j'], waitRelease=False)
                if len(theseKeys):
                    theseKeys = theseKeys[0]  # at least one key was pressed
                    
                    # check for quit:
                    if "escape" == theseKeys:
                        endExpNow = True
                    response.keys = theseKeys.name  # just the last key pressed
                    response.rt = theseKeys.rt
                    # was this 'correct'?
                    if (response.keys == str(CorResp)) or (response.keys == CorResp):
                        response.corr = 1
                    else:
                        response.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in EXP1_experimentComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "EXP1_experiment"-------
        for thisComponent in EXP1_experimentComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # check responses
        if response.keys in ['', [], None]:  # No response was made
            response.keys = None
            # was no response the correct answer?!
            if str(CorResp).lower() == 'none':
               response.corr = 1;  # correct non-response
            else:
               response.corr = 0;  # failed to respond (incorrectly)
        # store data for Experimental_trial (TrialHandler)
        Experimental_trial.addData('response.keys',response.keys)
        Experimental_trial.addData('response.corr', response.corr)
        if response.keys != None:  # we had a response
            Experimental_trial.addData('response.rt', response.rt)
        # the Routine "EXP1_experiment" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # ------Prepare to start Routine "Pauzeren_even"-------
        t = 0
        Pauzeren_evenClock.reset()  # clock
        frameN = -1
        continueRoutine = True
        # update component parameters for each repeat
        if response.keys:
            continueRoutine = False 
        press_space_mate = keyboard.Keyboard()
        # keep track of which components have finished
        Pauzeren_evenComponents = [pauze_for_a_moment_mate, press_space_mate]
        for thisComponent in Pauzeren_evenComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        # -------Start Routine "Pauzeren_even"-------
        while continueRoutine:
            # get current time
            t = Pauzeren_evenClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *pauze_for_a_moment_mate* updates
            if t >= 0.0 and pauze_for_a_moment_mate.status == NOT_STARTED:
                # keep track of start time/frame for later
                pauze_for_a_moment_mate.tStart = t  # not accounting for scr refresh
                pauze_for_a_moment_mate.frameNStart = frameN  # exact frame index
                win.timeOnFlip(pauze_for_a_moment_mate, 'tStartRefresh')  # time at next scr refresh
                pauze_for_a_moment_mate.setAutoDraw(True)
            
            # *press_space_mate* updates
            if t >= 0.0 and press_space_mate.status == NOT_STARTED:
                # keep track of start time/frame for later
                press_space_mate.tStart = t  # not accounting for scr refresh
                press_space_mate.frameNStart = frameN  # exact frame index
                win.timeOnFlip(press_space_mate, 'tStartRefresh')  # time at next scr refresh
                press_space_mate.status = STARTED
                # keyboard checking is just starting
                press_space_mate.clearEvents(eventType='keyboard')
            if press_space_mate.status == STARTED:
                theseKeys = press_space_mate.getKeys(keyList=['space'], waitRelease=False)
                if len(theseKeys):
                    theseKeys = theseKeys[0]  # at least one key was pressed
                    
                    # check for quit:
                    if "escape" == theseKeys:
                        endExpNow = True
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Pauzeren_evenComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "Pauzeren_even"-------
        for thisComponent in Pauzeren_evenComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # the Routine "Pauzeren_even" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 1 repeats of 'Experimental_trial'
    
    # get names of stimulus parameters
    if Experimental_trial.trialList in ([], [None], None):
        params = []
    else:
        params = Experimental_trial.trialList[0].keys()
    # save data for this loop
    Experimental_trial.saveAsExcel(filename + '.xlsx', sheetName='Experimental_trial',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    Experimental_trial.saveAsText(filename + 'Experimental_trial.csv', delim=',',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    thisExp.nextEntry()
    
# completed 1 repeats of 'Block_EXP1'

# get names of stimulus parameters
if Block_EXP1.trialList in ([], [None], None):
    params = []
else:
    params = Block_EXP1.trialList[0].keys()
# save data for this loop
Block_EXP1.saveAsExcel(filename + '.xlsx', sheetName='Block_EXP1',
    stimOut=params,
    dataOut=['n','all_mean','all_std', 'all_raw'])
Block_EXP1.saveAsText(filename + 'Block_EXP1.csv', delim=',',
    stimOut=params,
    dataOut=['n','all_mean','all_std', 'all_raw'])

# ------Prepare to start Routine "End"-------
t = 0
EndClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
space_4 = keyboard.Keyboard()
# keep track of which components have finished
EndComponents = [End_txt, space_4]
for thisComponent in EndComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "End"-------
while continueRoutine:
    # get current time
    t = EndClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *End_txt* updates
    if t >= 0.0 and End_txt.status == NOT_STARTED:
        # keep track of start time/frame for later
        End_txt.tStart = t  # not accounting for scr refresh
        End_txt.frameNStart = frameN  # exact frame index
        win.timeOnFlip(End_txt, 'tStartRefresh')  # time at next scr refresh
        End_txt.setAutoDraw(True)
    
    # *space_4* updates
    if t >= 0.0 and space_4.status == NOT_STARTED:
        # keep track of start time/frame for later
        space_4.tStart = t  # not accounting for scr refresh
        space_4.frameNStart = frameN  # exact frame index
        win.timeOnFlip(space_4, 'tStartRefresh')  # time at next scr refresh
        space_4.status = STARTED
        # keyboard checking is just starting
        space_4.clearEvents(eventType='keyboard')
    if space_4.status == STARTED:
        theseKeys = space_4.getKeys(keyList=['space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in EndComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "End"-------
for thisComponent in EndComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "End" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
