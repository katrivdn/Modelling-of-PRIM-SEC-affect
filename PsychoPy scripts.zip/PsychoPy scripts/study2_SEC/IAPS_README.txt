This research made use of the Internaltional Affective Picture System (IAPS).
For use, please consult: 
https://www.umass.edu/research/guidance/international-affective-picture-system-iaps.