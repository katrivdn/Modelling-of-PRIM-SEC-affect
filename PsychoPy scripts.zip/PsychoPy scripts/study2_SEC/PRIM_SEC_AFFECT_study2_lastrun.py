﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v3.2.4),
    on December 10, 2020, at 21:40
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

import psychopy
psychopy.useVersion('latest')


from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '3.2.4'
expName = 'PRIM_SEC_AFFECT_study2'  # from the Builder filename that created this script
expInfo = {'Leeftijd*': '', 'participant': '', 'Gender*': ['V', 'M', 'X']}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + expInfo['participant']+expName

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Users\\Katri\\Documents\\Unief\\experimentele psy\\INTERNSHIP\\code_PsychoPy\\study2\\PRIM_SEC_AFFECT_study2_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=[1366, 768], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[-1,-1,-1], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "Welcome"
WelcomeClock = core.Clock()
welkom = visual.TextStim(win=win, name='welkom',
    text='Welkom bij dit experiment! \nZorg ervoor dat je deze taak in een stille ruimte kan uitvoeren.\n\n[druk op spatie om verder te gaan]',
    font=None,
    units='norm', pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
space = keyboard.Keyboard()

# Initialize components for Routine "Instructies"
InstructiesClock = core.Clock()
explanation_welkom = visual.TextStim(win=win, name='explanation_welkom',
    text='Houd jouw vingers als volgt op het toetsenbord:\n[Druk op spatie om verder te gaan]',
    font=None,
    units='norm', pos=(0, 0.6), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
space_2 = keyboard.Keyboard()
keyboard_img = visual.ImageStim(
    win=win,
    name='keyboard_img', units='pix', 
    image='keyboard.jpg', mask=None,
    ori=0, pos=(0, -100), size=(700,401),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)

# Initialize components for Routine "Taak"
TaakClock = core.Clock()
text = visual.TextStim(win=win, name='text',
    text='[druk op spatie om verder te gaan]',
    font='Arial',
    pos=(0, -0.3), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
key_resp_5 = keyboard.Keyboard()
task_info = visual.TextStim(win=win, name='task_info',
    text='default text',
    font='Arial',
    units='norm', pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "PRIME_sample"
PRIME_sampleClock = core.Clock()
Prime_picture_2 = visual.ImageStim(
    win=win,
    name='Prime_picture_2', units='pix', 
    image='IAPS_TRAIN/training_1050.jpg', mask=None,
    ori=0, pos=(0, 0), size=(819, 614),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)

# Initialize components for Routine "facesample"
facesampleClock = core.Clock()
fixation_3 = visual.TextStim(win=win, name='fixation_3',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
image_20 = visual.ImageStim(
    win=win,
    name='image_20', units='pix', 
    image='sin', mask=None,
    ori=0, pos=(56.56,-56.56), size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
image_21 = visual.ImageStim(
    win=win,
    name='image_21', units='pix', 
    image='sin', mask=None,
    ori=0, pos=(-1.47,-80), size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
image_22 = visual.ImageStim(
    win=win,
    name='image_22', units='pix', 
    image='sin', mask=None,
    ori=0, pos=(56.56,56.56), size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-3.0)
image_23 = visual.ImageStim(
    win=win,
    name='image_23', units='pix', 
    image='sin', mask=None,
    ori=0, pos=(4.90,80), size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)
image_24 = visual.ImageStim(
    win=win,
    name='image_24', units='pix', 
    image='sin', mask=None,
    ori=0, pos=(-56.56,-56.56), size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-5.0)
image_25 = visual.ImageStim(
    win=win,
    name='image_25', units='pix', 
    image='sin', mask=None,
    ori=0, pos=(-56.56,56.56), size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-6.0)
image_26 = visual.ImageStim(
    win=win,
    name='image_26', units='pix', 
    image='sin', mask=None,
    ori=0, pos=(80,0), size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-7.0)
image8_3 = visual.ImageStim(
    win=win,
    name='image8_3', units='pix', 
    image='sin', mask=None,
    ori=0, pos=(-80,9.80), size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-8.0)

# Initialize components for Routine "instructions_TASK"
instructions_TASKClock = core.Clock()
kort = visual.TextStim(win=win, name='kort',
    text='Je zal telkens jou moeten concentreren op het midden van het scherm en moeten oordelen of je de gezichten eerder positief dan wel negatief vond. \nProbeer geen aandacht te besteden aan het plaatje dat eraan vooraf kwam. \nJe zal ook de volgende aanwijzigen op het scherm zien verschijnen:\n[Druk op spatie om verder te gaan]',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
space_3 = keyboard.Keyboard()

# Initialize components for Routine "break_sample"
break_sampleClock = core.Clock()
cross_fix_2 = visual.TextStim(win=win, name='cross_fix_2',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
minus_2 = visual.TextStim(win=win, name='minus_2',
    text='-',
    font='Arial',
    units='norm', pos=(-0.25, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
plus_2 = visual.TextStim(win=win, name='plus_2',
    text='+',
    font='Arial',
    units='norm', pos=(0.25, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
point = visual.TextStim(win=win, name='point',
    text='.',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);

# Initialize components for Routine "break_INSTR"
break_INSTRClock = core.Clock()
instructions_break = visual.TextStim(win=win, name='instructions_break',
    text="Het plus teken staat aan de kant van een het antwoord 'eerder positief'; het min teken aan de kant van 'eerder negatief'. Deze aanwijzigingen zullen jou helpen om jou te herinneren aan welke kant je zal moeten antwoorden.\n[druk op spatie om verder te gaan]",
    font='Arial',
    units='norm', pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
key_resp_3 = keyboard.Keyboard()

# Initialize components for Routine "OPLETTEN"
OPLETTENClock = core.Clock()
let_op = visual.TextStim(win=win, name='let_op',
    text='!LET OP!',
    font=None,
    pos=(0, 0.3), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
gevoelig_txt = visual.TextStim(win=win, name='gevoelig_txt',
    text='Sommige beelden kunnen als schokkend worden ervaren. \nIndien u niet meer aan het experiment wenst deel te nemen, druk dan op de `ESCAPE` toets en stuur een mail naar de proefleider.',
    font=None,
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
key_resp_2 = keyboard.Keyboard()
press_space = visual.TextStim(win=win, name='press_space',
    text='[druk op spatie om verder te gaan]',
    font=None,
    pos=(0, -0.3), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);

# Initialize components for Routine "code_deel"
code_deelClock = core.Clock()
part = 0
part_text = 'Dit is deel {0}/4'.format(part)

# Initialize components for Routine "DEEL"
DEELClock = core.Clock()
Text_ndeel = visual.TextStim(win=win, name='Text_ndeel',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "response_instr_left"
response_instr_leftClock = core.Clock()
keyboard_picture_2 = visual.ImageStim(
    win=win,
    name='keyboard_picture_2', units='pix', 
    image='F.png', mask=None,
    ori=0, pos=(0, -100), size=(799, 258),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
key_resp_16 = keyboard.Keyboard()
links_text = visual.TextStim(win=win, name='links_text',
    text='default text',
    font=None,
    units='norm', pos=(0, 0.4), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
text_9 = visual.TextStim(win=win, name='text_9',
    text="[druk op de 'f' toets om verder te gaan]",
    font='Arial',
    units='norm', pos=(0, -0.85), height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);
oefen_3 = visual.TextStim(win=win, name='oefen_3',
    text='OEFENBEURT',
    font='Arial',
    pos=(0, 0.7), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-4.0);

# Initialize components for Routine "response_instr_right"
response_instr_rightClock = core.Clock()
key_resp_17 = keyboard.Keyboard()
text_15 = visual.TextStim(win=win, name='text_15',
    text='default text',
    font='Arial',
    units='norm', pos=(0, 0.4), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
keyboard_3 = visual.ImageStim(
    win=win,
    name='keyboard_3', units='pix', 
    image='J.png', mask=None,
    ori=0, pos=(0, -100), size=(799, 258),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
text_16 = visual.TextStim(win=win, name='text_16',
    text="[druk op de 'j' toets om verder te gaan]",
    font='Arial',
    units='norm', pos=(0, -0.85), height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);
oefen_4 = visual.TextStim(win=win, name='oefen_4',
    text='OEFENBEURT',
    font='Arial',
    pos=(0, 0.7), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-4.0);

# Initialize components for Routine "oefenen"
oefenenClock = core.Clock()
training_txt = visual.TextStim(win=win, name='training_txt',
    text='Hierna begint een korte oefenreeks.\n[druk op spatie om verder te gaan]',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
space_continue = keyboard.Keyboard()

# Initialize components for Routine "break_2"
break_2Clock = core.Clock()
cross_fix = visual.TextStim(win=win, name='cross_fix',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
minus = visual.TextStim(win=win, name='minus',
    text='-',
    font='Arial',
    units='norm', pos=[0,0], height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
plus = visual.TextStim(win=win, name='plus',
    text='+',
    font='Arial',
    units='norm', pos=[0,0], height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
point_2 = visual.TextStim(win=win, name='point_2',
    text='.',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);

# Initialize components for Routine "PRIME"
PRIMEClock = core.Clock()
Prime_picture = visual.ImageStim(
    win=win,
    name='Prime_picture', units='pix', 
    image='sin', mask=None,
    ori=0, pos=(0, 0), size=(819, 614),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)

# Initialize components for Routine "EXP2_experiment"
EXP2_experimentClock = core.Clock()
fixation = visual.TextStim(win=win, name='fixation',
    text='+',
    font='Arial',
    units='norm', pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
image_1 = visual.ImageStim(
    win=win,
    name='image_1', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
image_2 = visual.ImageStim(
    win=win,
    name='image_2', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
image_3 = visual.ImageStim(
    win=win,
    name='image_3', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-3.0)
image_4 = visual.ImageStim(
    win=win,
    name='image_4', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)
image_5 = visual.ImageStim(
    win=win,
    name='image_5', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-5.0)
image_6 = visual.ImageStim(
    win=win,
    name='image_6', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-6.0)
image_12 = visual.ImageStim(
    win=win,
    name='image_12', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-7.0)
image8 = visual.ImageStim(
    win=win,
    name='image8', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-8.0)
response = keyboard.Keyboard()

# Initialize components for Routine "EXP2_START_2"
EXP2_START_2Clock = core.Clock()
text_7 = visual.TextStim(win=win, name='text_7',
    text='Vanaf nu start het echte experiment!\n[Druk op spatie om verder te gaan]',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
key_resp_10 = keyboard.Keyboard()
text_8 = visual.TextStim(win=win, name='text_8',
    text='START EXPERIMENT',
    font='Arial',
    pos=(0, 0.4), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "break_2"
break_2Clock = core.Clock()
cross_fix = visual.TextStim(win=win, name='cross_fix',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
minus = visual.TextStim(win=win, name='minus',
    text='-',
    font='Arial',
    units='norm', pos=[0,0], height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
plus = visual.TextStim(win=win, name='plus',
    text='+',
    font='Arial',
    units='norm', pos=[0,0], height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
point_2 = visual.TextStim(win=win, name='point_2',
    text='.',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);

# Initialize components for Routine "PRIME"
PRIMEClock = core.Clock()
Prime_picture = visual.ImageStim(
    win=win,
    name='Prime_picture', units='pix', 
    image='sin', mask=None,
    ori=0, pos=(0, 0), size=(819, 614),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)

# Initialize components for Routine "EXP2_experiment"
EXP2_experimentClock = core.Clock()
fixation = visual.TextStim(win=win, name='fixation',
    text='+',
    font='Arial',
    units='norm', pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
image_1 = visual.ImageStim(
    win=win,
    name='image_1', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
image_2 = visual.ImageStim(
    win=win,
    name='image_2', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
image_3 = visual.ImageStim(
    win=win,
    name='image_3', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-3.0)
image_4 = visual.ImageStim(
    win=win,
    name='image_4', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)
image_5 = visual.ImageStim(
    win=win,
    name='image_5', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-5.0)
image_6 = visual.ImageStim(
    win=win,
    name='image_6', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-6.0)
image_12 = visual.ImageStim(
    win=win,
    name='image_12', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-7.0)
image8 = visual.ImageStim(
    win=win,
    name='image8', units='pix', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(50,50),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-8.0)
response = keyboard.Keyboard()

# Initialize components for Routine "Pauzeren_even"
Pauzeren_evenClock = core.Clock()
pauze_for_a_moment_mate = visual.TextStim(win=win, name='pauze_for_a_moment_mate',
    text='Eventjes pauzeren...\n[druk op spatie om verder te gaan]',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
press_space_mate = keyboard.Keyboard()

# Initialize components for Routine "End"
EndClock = core.Clock()
End_txt = visual.TextStim(win=win, name='End_txt',
    text='Hartelijk dank voor jouw deelname!\n[druk op spatie om het experiment te beëindigen]',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
space_4 = keyboard.Keyboard()

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "Welcome"-------
# update component parameters for each repeat
space.keys = []
space.rt = []
# keep track of which components have finished
WelcomeComponents = [welkom, space]
for thisComponent in WelcomeComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
WelcomeClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1
continueRoutine = True

# -------Run Routine "Welcome"-------
while continueRoutine:
    # get current time
    t = WelcomeClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=WelcomeClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *welkom* updates
    if welkom.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        welkom.frameNStart = frameN  # exact frame index
        welkom.tStart = t  # local t and not account for scr refresh
        welkom.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(welkom, 'tStartRefresh')  # time at next scr refresh
        welkom.setAutoDraw(True)
    
    # *space* updates
    waitOnFlip = False
    if space.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        space.frameNStart = frameN  # exact frame index
        space.tStart = t  # local t and not account for scr refresh
        space.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(space, 'tStartRefresh')  # time at next scr refresh
        space.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(space.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if space.status == STARTED and not waitOnFlip:
        theseKeys = space.getKeys(keyList=['space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in WelcomeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Welcome"-------
for thisComponent in WelcomeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "Welcome" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Instructies"-------
# update component parameters for each repeat
space_2.keys = []
space_2.rt = []
# keep track of which components have finished
InstructiesComponents = [explanation_welkom, space_2, keyboard_img]
for thisComponent in InstructiesComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
InstructiesClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1
continueRoutine = True

# -------Run Routine "Instructies"-------
while continueRoutine:
    # get current time
    t = InstructiesClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=InstructiesClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *explanation_welkom* updates
    if explanation_welkom.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        explanation_welkom.frameNStart = frameN  # exact frame index
        explanation_welkom.tStart = t  # local t and not account for scr refresh
        explanation_welkom.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(explanation_welkom, 'tStartRefresh')  # time at next scr refresh
        explanation_welkom.setAutoDraw(True)
    
    # *space_2* updates
    waitOnFlip = False
    if space_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        space_2.frameNStart = frameN  # exact frame index
        space_2.tStart = t  # local t and not account for scr refresh
        space_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(space_2, 'tStartRefresh')  # time at next scr refresh
        space_2.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(space_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if space_2.status == STARTED and not waitOnFlip:
        theseKeys = space_2.getKeys(keyList=['space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            # a response ends the routine
            continueRoutine = False
    
    # *keyboard_img* updates
    if keyboard_img.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        keyboard_img.frameNStart = frameN  # exact frame index
        keyboard_img.tStart = t  # local t and not account for scr refresh
        keyboard_img.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(keyboard_img, 'tStartRefresh')  # time at next scr refresh
        keyboard_img.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in InstructiesComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Instructies"-------
for thisComponent in InstructiesComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "Instructies" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Taak"-------
# update component parameters for each repeat
key_resp_5.keys = []
key_resp_5.rt = []
task_info.setText('In dit experiment zal je een plaatje gevolgd door een reeks gezichten te zien krijgen, als volgt:')
# keep track of which components have finished
TaakComponents = [text, key_resp_5, task_info]
for thisComponent in TaakComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
TaakClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1
continueRoutine = True

# -------Run Routine "Taak"-------
while continueRoutine:
    # get current time
    t = TaakClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=TaakClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text* updates
    if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text.frameNStart = frameN  # exact frame index
        text.tStart = t  # local t and not account for scr refresh
        text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
        text.setAutoDraw(True)
    
    # *key_resp_5* updates
    waitOnFlip = False
    if key_resp_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_5.frameNStart = frameN  # exact frame index
        key_resp_5.tStart = t  # local t and not account for scr refresh
        key_resp_5.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_5, 'tStartRefresh')  # time at next scr refresh
        key_resp_5.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(key_resp_5.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_5.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_5.getKeys(keyList=['space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            # a response ends the routine
            continueRoutine = False
    
    # *task_info* updates
    if task_info.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        task_info.frameNStart = frameN  # exact frame index
        task_info.tStart = t  # local t and not account for scr refresh
        task_info.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(task_info, 'tStartRefresh')  # time at next scr refresh
        task_info.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in TaakComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Taak"-------
for thisComponent in TaakComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "Taak" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "PRIME_sample"-------
routineTimer.add(0.400000)
# update component parameters for each repeat
# keep track of which components have finished
PRIME_sampleComponents = [Prime_picture_2]
for thisComponent in PRIME_sampleComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
PRIME_sampleClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1
continueRoutine = True

# -------Run Routine "PRIME_sample"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = PRIME_sampleClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=PRIME_sampleClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *Prime_picture_2* updates
    if Prime_picture_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        Prime_picture_2.frameNStart = frameN  # exact frame index
        Prime_picture_2.tStart = t  # local t and not account for scr refresh
        Prime_picture_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(Prime_picture_2, 'tStartRefresh')  # time at next scr refresh
        Prime_picture_2.setAutoDraw(True)
    if Prime_picture_2.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > Prime_picture_2.tStartRefresh + 0.4-frameTolerance:
            # keep track of stop time/frame for later
            Prime_picture_2.tStop = t  # not accounting for scr refresh
            Prime_picture_2.frameNStop = frameN  # exact frame index
            win.timeOnFlip(Prime_picture_2, 'tStopRefresh')  # time at next scr refresh
            Prime_picture_2.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in PRIME_sampleComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "PRIME_sample"-------
for thisComponent in PRIME_sampleComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)

# ------Prepare to start Routine "facesample"-------
routineTimer.add(2.000000)
# update component parameters for each repeat
image_20.setImage('face_expressions/training/01F_SP_O.png')
image_21.setImage('face_expressions/training/10F_SP_O.png')
image_22.setImage('face_expressions/training/17F_SP_O.png')
image_23.setImage('face_expressions/training/10F_SP_O.png')
image_24.setImage('face_expressions/training/30M_SP_O.png')
image_25.setImage('face_expressions/training/21M_SP_O.png')
image_26.setImage('face_expressions/training/30M_SP_O.png')
image8_3.setImage('face_expressions/training/42M_SP_O.png')
# keep track of which components have finished
facesampleComponents = [fixation_3, image_20, image_21, image_22, image_23, image_24, image_25, image_26, image8_3]
for thisComponent in facesampleComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
facesampleClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1
continueRoutine = True

# -------Run Routine "facesample"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = facesampleClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=facesampleClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *fixation_3* updates
    if fixation_3.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
        # keep track of start time/frame for later
        fixation_3.frameNStart = frameN  # exact frame index
        fixation_3.tStart = t  # local t and not account for scr refresh
        fixation_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(fixation_3, 'tStartRefresh')  # time at next scr refresh
        fixation_3.setAutoDraw(True)
    if fixation_3.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > fixation_3.tStartRefresh + 2-frameTolerance:
            # keep track of stop time/frame for later
            fixation_3.tStop = t  # not accounting for scr refresh
            fixation_3.frameNStop = frameN  # exact frame index
            win.timeOnFlip(fixation_3, 'tStopRefresh')  # time at next scr refresh
            fixation_3.setAutoDraw(False)
    
    # *image_20* updates
    if image_20.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        image_20.frameNStart = frameN  # exact frame index
        image_20.tStart = t  # local t and not account for scr refresh
        image_20.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_20, 'tStartRefresh')  # time at next scr refresh
        image_20.setAutoDraw(True)
    if image_20.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_20.tStartRefresh + 0.5-frameTolerance:
            # keep track of stop time/frame for later
            image_20.tStop = t  # not accounting for scr refresh
            image_20.frameNStop = frameN  # exact frame index
            win.timeOnFlip(image_20, 'tStopRefresh')  # time at next scr refresh
            image_20.setAutoDraw(False)
    
    # *image_21* updates
    if image_21.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        image_21.frameNStart = frameN  # exact frame index
        image_21.tStart = t  # local t and not account for scr refresh
        image_21.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_21, 'tStartRefresh')  # time at next scr refresh
        image_21.setAutoDraw(True)
    if image_21.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_21.tStartRefresh + 0.5-frameTolerance:
            # keep track of stop time/frame for later
            image_21.tStop = t  # not accounting for scr refresh
            image_21.frameNStop = frameN  # exact frame index
            win.timeOnFlip(image_21, 'tStopRefresh')  # time at next scr refresh
            image_21.setAutoDraw(False)
    
    # *image_22* updates
    if image_22.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        image_22.frameNStart = frameN  # exact frame index
        image_22.tStart = t  # local t and not account for scr refresh
        image_22.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_22, 'tStartRefresh')  # time at next scr refresh
        image_22.setAutoDraw(True)
    if image_22.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_22.tStartRefresh + 0.5-frameTolerance:
            # keep track of stop time/frame for later
            image_22.tStop = t  # not accounting for scr refresh
            image_22.frameNStop = frameN  # exact frame index
            win.timeOnFlip(image_22, 'tStopRefresh')  # time at next scr refresh
            image_22.setAutoDraw(False)
    
    # *image_23* updates
    if image_23.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        image_23.frameNStart = frameN  # exact frame index
        image_23.tStart = t  # local t and not account for scr refresh
        image_23.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_23, 'tStartRefresh')  # time at next scr refresh
        image_23.setAutoDraw(True)
    if image_23.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_23.tStartRefresh + 0.5-frameTolerance:
            # keep track of stop time/frame for later
            image_23.tStop = t  # not accounting for scr refresh
            image_23.frameNStop = frameN  # exact frame index
            win.timeOnFlip(image_23, 'tStopRefresh')  # time at next scr refresh
            image_23.setAutoDraw(False)
    
    # *image_24* updates
    if image_24.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        image_24.frameNStart = frameN  # exact frame index
        image_24.tStart = t  # local t and not account for scr refresh
        image_24.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_24, 'tStartRefresh')  # time at next scr refresh
        image_24.setAutoDraw(True)
    if image_24.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_24.tStartRefresh + 0.5-frameTolerance:
            # keep track of stop time/frame for later
            image_24.tStop = t  # not accounting for scr refresh
            image_24.frameNStop = frameN  # exact frame index
            win.timeOnFlip(image_24, 'tStopRefresh')  # time at next scr refresh
            image_24.setAutoDraw(False)
    
    # *image_25* updates
    if image_25.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        image_25.frameNStart = frameN  # exact frame index
        image_25.tStart = t  # local t and not account for scr refresh
        image_25.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_25, 'tStartRefresh')  # time at next scr refresh
        image_25.setAutoDraw(True)
    if image_25.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_25.tStartRefresh + 0.5-frameTolerance:
            # keep track of stop time/frame for later
            image_25.tStop = t  # not accounting for scr refresh
            image_25.frameNStop = frameN  # exact frame index
            win.timeOnFlip(image_25, 'tStopRefresh')  # time at next scr refresh
            image_25.setAutoDraw(False)
    
    # *image_26* updates
    if image_26.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        image_26.frameNStart = frameN  # exact frame index
        image_26.tStart = t  # local t and not account for scr refresh
        image_26.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_26, 'tStartRefresh')  # time at next scr refresh
        image_26.setAutoDraw(True)
    if image_26.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_26.tStartRefresh + 0.5-frameTolerance:
            # keep track of stop time/frame for later
            image_26.tStop = t  # not accounting for scr refresh
            image_26.frameNStop = frameN  # exact frame index
            win.timeOnFlip(image_26, 'tStopRefresh')  # time at next scr refresh
            image_26.setAutoDraw(False)
    
    # *image8_3* updates
    if image8_3.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        image8_3.frameNStart = frameN  # exact frame index
        image8_3.tStart = t  # local t and not account for scr refresh
        image8_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image8_3, 'tStartRefresh')  # time at next scr refresh
        image8_3.setAutoDraw(True)
    if image8_3.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image8_3.tStartRefresh + 0.5-frameTolerance:
            # keep track of stop time/frame for later
            image8_3.tStop = t  # not accounting for scr refresh
            image8_3.frameNStop = frameN  # exact frame index
            win.timeOnFlip(image8_3, 'tStopRefresh')  # time at next scr refresh
            image8_3.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in facesampleComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "facesample"-------
for thisComponent in facesampleComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)

# ------Prepare to start Routine "instructions_TASK"-------
# update component parameters for each repeat
space_3.keys = []
space_3.rt = []
# keep track of which components have finished
instructions_TASKComponents = [kort, space_3]
for thisComponent in instructions_TASKComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
instructions_TASKClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1
continueRoutine = True

# -------Run Routine "instructions_TASK"-------
while continueRoutine:
    # get current time
    t = instructions_TASKClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=instructions_TASKClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *kort* updates
    if kort.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        kort.frameNStart = frameN  # exact frame index
        kort.tStart = t  # local t and not account for scr refresh
        kort.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(kort, 'tStartRefresh')  # time at next scr refresh
        kort.setAutoDraw(True)
    
    # *space_3* updates
    waitOnFlip = False
    if space_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        space_3.frameNStart = frameN  # exact frame index
        space_3.tStart = t  # local t and not account for scr refresh
        space_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(space_3, 'tStartRefresh')  # time at next scr refresh
        space_3.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(space_3.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if space_3.status == STARTED and not waitOnFlip:
        theseKeys = space_3.getKeys(keyList=['space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instructions_TASKComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instructions_TASK"-------
for thisComponent in instructions_TASKComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instructions_TASK" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "break_sample"-------
routineTimer.add(1.500000)
# update component parameters for each repeat
# keep track of which components have finished
break_sampleComponents = [cross_fix_2, minus_2, plus_2, point]
for thisComponent in break_sampleComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
break_sampleClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1
continueRoutine = True

# -------Run Routine "break_sample"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = break_sampleClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=break_sampleClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *cross_fix_2* updates
    if cross_fix_2.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
        # keep track of start time/frame for later
        cross_fix_2.frameNStart = frameN  # exact frame index
        cross_fix_2.tStart = t  # local t and not account for scr refresh
        cross_fix_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(cross_fix_2, 'tStartRefresh')  # time at next scr refresh
        cross_fix_2.setAutoDraw(True)
    if cross_fix_2.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > cross_fix_2.tStartRefresh + 0.5-frameTolerance:
            # keep track of stop time/frame for later
            cross_fix_2.tStop = t  # not accounting for scr refresh
            cross_fix_2.frameNStop = frameN  # exact frame index
            win.timeOnFlip(cross_fix_2, 'tStopRefresh')  # time at next scr refresh
            cross_fix_2.setAutoDraw(False)
    
    # *minus_2* updates
    if minus_2.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        minus_2.frameNStart = frameN  # exact frame index
        minus_2.tStart = t  # local t and not account for scr refresh
        minus_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(minus_2, 'tStartRefresh')  # time at next scr refresh
        minus_2.setAutoDraw(True)
    if minus_2.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > minus_2.tStartRefresh + 1-frameTolerance:
            # keep track of stop time/frame for later
            minus_2.tStop = t  # not accounting for scr refresh
            minus_2.frameNStop = frameN  # exact frame index
            win.timeOnFlip(minus_2, 'tStopRefresh')  # time at next scr refresh
            minus_2.setAutoDraw(False)
    
    # *plus_2* updates
    if plus_2.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        plus_2.frameNStart = frameN  # exact frame index
        plus_2.tStart = t  # local t and not account for scr refresh
        plus_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(plus_2, 'tStartRefresh')  # time at next scr refresh
        plus_2.setAutoDraw(True)
    if plus_2.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > plus_2.tStartRefresh + 1-frameTolerance:
            # keep track of stop time/frame for later
            plus_2.tStop = t  # not accounting for scr refresh
            plus_2.frameNStop = frameN  # exact frame index
            win.timeOnFlip(plus_2, 'tStopRefresh')  # time at next scr refresh
            plus_2.setAutoDraw(False)
    
    # *point* updates
    if point.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        point.frameNStart = frameN  # exact frame index
        point.tStart = t  # local t and not account for scr refresh
        point.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(point, 'tStartRefresh')  # time at next scr refresh
        point.setAutoDraw(True)
    if point.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > point.tStartRefresh + 1.0-frameTolerance:
            # keep track of stop time/frame for later
            point.tStop = t  # not accounting for scr refresh
            point.frameNStop = frameN  # exact frame index
            win.timeOnFlip(point, 'tStopRefresh')  # time at next scr refresh
            point.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in break_sampleComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "break_sample"-------
for thisComponent in break_sampleComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)

# ------Prepare to start Routine "break_INSTR"-------
# update component parameters for each repeat
key_resp_3.keys = []
key_resp_3.rt = []
# keep track of which components have finished
break_INSTRComponents = [instructions_break, key_resp_3]
for thisComponent in break_INSTRComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
break_INSTRClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1
continueRoutine = True

# -------Run Routine "break_INSTR"-------
while continueRoutine:
    # get current time
    t = break_INSTRClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=break_INSTRClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructions_break* updates
    if instructions_break.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructions_break.frameNStart = frameN  # exact frame index
        instructions_break.tStart = t  # local t and not account for scr refresh
        instructions_break.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructions_break, 'tStartRefresh')  # time at next scr refresh
        instructions_break.setAutoDraw(True)
    
    # *key_resp_3* updates
    waitOnFlip = False
    if key_resp_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_3.frameNStart = frameN  # exact frame index
        key_resp_3.tStart = t  # local t and not account for scr refresh
        key_resp_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_3, 'tStartRefresh')  # time at next scr refresh
        key_resp_3.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(key_resp_3.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_3.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_3.getKeys(keyList=['space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in break_INSTRComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "break_INSTR"-------
for thisComponent in break_INSTRComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "break_INSTR" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "OPLETTEN"-------
# update component parameters for each repeat
key_resp_2.keys = []
key_resp_2.rt = []
# keep track of which components have finished
OPLETTENComponents = [let_op, gevoelig_txt, key_resp_2, press_space]
for thisComponent in OPLETTENComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
OPLETTENClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1
continueRoutine = True

# -------Run Routine "OPLETTEN"-------
while continueRoutine:
    # get current time
    t = OPLETTENClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=OPLETTENClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *let_op* updates
    if let_op.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        let_op.frameNStart = frameN  # exact frame index
        let_op.tStart = t  # local t and not account for scr refresh
        let_op.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(let_op, 'tStartRefresh')  # time at next scr refresh
        let_op.setAutoDraw(True)
    
    # *gevoelig_txt* updates
    if gevoelig_txt.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        gevoelig_txt.frameNStart = frameN  # exact frame index
        gevoelig_txt.tStart = t  # local t and not account for scr refresh
        gevoelig_txt.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(gevoelig_txt, 'tStartRefresh')  # time at next scr refresh
        gevoelig_txt.setAutoDraw(True)
    
    # *key_resp_2* updates
    waitOnFlip = False
    if key_resp_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_2.frameNStart = frameN  # exact frame index
        key_resp_2.tStart = t  # local t and not account for scr refresh
        key_resp_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_2, 'tStartRefresh')  # time at next scr refresh
        key_resp_2.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(key_resp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_2.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_2.getKeys(keyList=['space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            # a response ends the routine
            continueRoutine = False
    
    # *press_space* updates
    if press_space.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        press_space.frameNStart = frameN  # exact frame index
        press_space.tStart = t  # local t and not account for scr refresh
        press_space.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(press_space, 'tStartRefresh')  # time at next scr refresh
        press_space.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in OPLETTENComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "OPLETTEN"-------
for thisComponent in OPLETTENComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "OPLETTEN" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
Block_EXP2 = data.TrialHandler(nReps=1, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('ConditionFile_exp2.csv', selection='0'),
    seed=None, name='Block_EXP2')
thisExp.addLoop(Block_EXP2)  # add the loop to the experiment
thisBlock_EXP2 = Block_EXP2.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisBlock_EXP2.rgb)
if thisBlock_EXP2 != None:
    for paramName in thisBlock_EXP2:
        exec('{} = thisBlock_EXP2[paramName]'.format(paramName))

for thisBlock_EXP2 in Block_EXP2:
    currentLoop = Block_EXP2
    # abbreviate parameter names if possible (e.g. rgb = thisBlock_EXP2.rgb)
    if thisBlock_EXP2 != None:
        for paramName in thisBlock_EXP2:
            exec('{} = thisBlock_EXP2[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "code_deel"-------
    # update component parameters for each repeat
    part = part+1
    part_text = 'Dit is deel {0}/4'.format(part)
    # keep track of which components have finished
    code_deelComponents = []
    for thisComponent in code_deelComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    code_deelClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    continueRoutine = True
    
    # -------Run Routine "code_deel"-------
    while continueRoutine:
        # get current time
        t = code_deelClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=code_deelClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in code_deelComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "code_deel"-------
    for thisComponent in code_deelComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "code_deel" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "DEEL"-------
    routineTimer.add(1.000000)
    # update component parameters for each repeat
    Text_ndeel.setText(part_text)
    # keep track of which components have finished
    DEELComponents = [Text_ndeel]
    for thisComponent in DEELComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    DEELClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    continueRoutine = True
    
    # -------Run Routine "DEEL"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = DEELClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=DEELClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Text_ndeel* updates
        if Text_ndeel.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Text_ndeel.frameNStart = frameN  # exact frame index
            Text_ndeel.tStart = t  # local t and not account for scr refresh
            Text_ndeel.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Text_ndeel, 'tStartRefresh')  # time at next scr refresh
            Text_ndeel.setAutoDraw(True)
        if Text_ndeel.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > Text_ndeel.tStartRefresh + 1-frameTolerance:
                # keep track of stop time/frame for later
                Text_ndeel.tStop = t  # not accounting for scr refresh
                Text_ndeel.frameNStop = frameN  # exact frame index
                win.timeOnFlip(Text_ndeel, 'tStopRefresh')  # time at next scr refresh
                Text_ndeel.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in DEELComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "DEEL"-------
    for thisComponent in DEELComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    
    # set up handler to look after randomisation of conditions etc
    TRAINING_loop = data.TrialHandler(nReps=1, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions(CondFiles_TRAIN),
        seed=None, name='TRAINING_loop')
    thisExp.addLoop(TRAINING_loop)  # add the loop to the experiment
    thisTRAINING_loop = TRAINING_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTRAINING_loop.rgb)
    if thisTRAINING_loop != None:
        for paramName in thisTRAINING_loop:
            exec('{} = thisTRAINING_loop[paramName]'.format(paramName))
    
    for thisTRAINING_loop in TRAINING_loop:
        currentLoop = TRAINING_loop
        # abbreviate parameter names if possible (e.g. rgb = thisTRAINING_loop.rgb)
        if thisTRAINING_loop != None:
            for paramName in thisTRAINING_loop:
                exec('{} = thisTRAINING_loop[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "response_instr_left"-------
        # update component parameters for each repeat
        key_resp_16.keys = []
        key_resp_16.rt = []
        links_text.setText(links)
        # keep track of which components have finished
        response_instr_leftComponents = [keyboard_picture_2, key_resp_16, links_text, text_9, oefen_3]
        for thisComponent in response_instr_leftComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        response_instr_leftClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        continueRoutine = True
        
        # -------Run Routine "response_instr_left"-------
        while continueRoutine:
            # get current time
            t = response_instr_leftClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=response_instr_leftClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *keyboard_picture_2* updates
            if keyboard_picture_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                keyboard_picture_2.frameNStart = frameN  # exact frame index
                keyboard_picture_2.tStart = t  # local t and not account for scr refresh
                keyboard_picture_2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(keyboard_picture_2, 'tStartRefresh')  # time at next scr refresh
                keyboard_picture_2.setAutoDraw(True)
            
            # *key_resp_16* updates
            waitOnFlip = False
            if key_resp_16.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_16.frameNStart = frameN  # exact frame index
                key_resp_16.tStart = t  # local t and not account for scr refresh
                key_resp_16.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_16, 'tStartRefresh')  # time at next scr refresh
                key_resp_16.status = STARTED
                # keyboard checking is just starting
                win.callOnFlip(key_resp_16.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_16.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_16.getKeys(keyList=['f'], waitRelease=False)
                if len(theseKeys):
                    theseKeys = theseKeys[0]  # at least one key was pressed
                    
                    # check for quit:
                    if "escape" == theseKeys:
                        endExpNow = True
                    # a response ends the routine
                    continueRoutine = False
            
            # *links_text* updates
            if links_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                links_text.frameNStart = frameN  # exact frame index
                links_text.tStart = t  # local t and not account for scr refresh
                links_text.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(links_text, 'tStartRefresh')  # time at next scr refresh
                links_text.setAutoDraw(True)
            
            # *text_9* updates
            if text_9.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_9.frameNStart = frameN  # exact frame index
                text_9.tStart = t  # local t and not account for scr refresh
                text_9.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_9, 'tStartRefresh')  # time at next scr refresh
                text_9.setAutoDraw(True)
            
            # *oefen_3* updates
            if oefen_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                oefen_3.frameNStart = frameN  # exact frame index
                oefen_3.tStart = t  # local t and not account for scr refresh
                oefen_3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(oefen_3, 'tStartRefresh')  # time at next scr refresh
                oefen_3.setAutoDraw(True)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in response_instr_leftComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "response_instr_left"-------
        for thisComponent in response_instr_leftComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # the Routine "response_instr_left" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # ------Prepare to start Routine "response_instr_right"-------
        # update component parameters for each repeat
        key_resp_17.keys = []
        key_resp_17.rt = []
        text_15.setText(rechts)
        # keep track of which components have finished
        response_instr_rightComponents = [key_resp_17, text_15, keyboard_3, text_16, oefen_4]
        for thisComponent in response_instr_rightComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        response_instr_rightClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        continueRoutine = True
        
        # -------Run Routine "response_instr_right"-------
        while continueRoutine:
            # get current time
            t = response_instr_rightClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=response_instr_rightClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *key_resp_17* updates
            waitOnFlip = False
            if key_resp_17.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_17.frameNStart = frameN  # exact frame index
                key_resp_17.tStart = t  # local t and not account for scr refresh
                key_resp_17.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_17, 'tStartRefresh')  # time at next scr refresh
                key_resp_17.status = STARTED
                # keyboard checking is just starting
                win.callOnFlip(key_resp_17.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_17.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_17.getKeys(keyList=['j'], waitRelease=False)
                if len(theseKeys):
                    theseKeys = theseKeys[0]  # at least one key was pressed
                    
                    # check for quit:
                    if "escape" == theseKeys:
                        endExpNow = True
                    # a response ends the routine
                    continueRoutine = False
            
            # *text_15* updates
            if text_15.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_15.frameNStart = frameN  # exact frame index
                text_15.tStart = t  # local t and not account for scr refresh
                text_15.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_15, 'tStartRefresh')  # time at next scr refresh
                text_15.setAutoDraw(True)
            
            # *keyboard_3* updates
            if keyboard_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                keyboard_3.frameNStart = frameN  # exact frame index
                keyboard_3.tStart = t  # local t and not account for scr refresh
                keyboard_3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(keyboard_3, 'tStartRefresh')  # time at next scr refresh
                keyboard_3.setAutoDraw(True)
            
            # *text_16* updates
            if text_16.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_16.frameNStart = frameN  # exact frame index
                text_16.tStart = t  # local t and not account for scr refresh
                text_16.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_16, 'tStartRefresh')  # time at next scr refresh
                text_16.setAutoDraw(True)
            
            # *oefen_4* updates
            if oefen_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                oefen_4.frameNStart = frameN  # exact frame index
                oefen_4.tStart = t  # local t and not account for scr refresh
                oefen_4.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(oefen_4, 'tStartRefresh')  # time at next scr refresh
                oefen_4.setAutoDraw(True)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in response_instr_rightComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "response_instr_right"-------
        for thisComponent in response_instr_rightComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # the Routine "response_instr_right" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # ------Prepare to start Routine "oefenen"-------
        # update component parameters for each repeat
        space_continue.keys = []
        space_continue.rt = []
        # keep track of which components have finished
        oefenenComponents = [training_txt, space_continue]
        for thisComponent in oefenenComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        oefenenClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        continueRoutine = True
        
        # -------Run Routine "oefenen"-------
        while continueRoutine:
            # get current time
            t = oefenenClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=oefenenClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *training_txt* updates
            if training_txt.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                training_txt.frameNStart = frameN  # exact frame index
                training_txt.tStart = t  # local t and not account for scr refresh
                training_txt.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(training_txt, 'tStartRefresh')  # time at next scr refresh
                training_txt.setAutoDraw(True)
            
            # *space_continue* updates
            waitOnFlip = False
            if space_continue.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                space_continue.frameNStart = frameN  # exact frame index
                space_continue.tStart = t  # local t and not account for scr refresh
                space_continue.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(space_continue, 'tStartRefresh')  # time at next scr refresh
                space_continue.status = STARTED
                # keyboard checking is just starting
                win.callOnFlip(space_continue.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if space_continue.status == STARTED and not waitOnFlip:
                theseKeys = space_continue.getKeys(keyList=['space'], waitRelease=False)
                if len(theseKeys):
                    theseKeys = theseKeys[0]  # at least one key was pressed
                    
                    # check for quit:
                    if "escape" == theseKeys:
                        endExpNow = True
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in oefenenComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "oefenen"-------
        for thisComponent in oefenenComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # the Routine "oefenen" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # set up handler to look after randomisation of conditions etc
        practice_trial = data.TrialHandler(nReps=1, method='random', 
            extraInfo=expInfo, originPath=-1,
            trialList=data.importConditions(Cond_TRAINING),
            seed=None, name='practice_trial')
        thisExp.addLoop(practice_trial)  # add the loop to the experiment
        thisPractice_trial = practice_trial.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisPractice_trial.rgb)
        if thisPractice_trial != None:
            for paramName in thisPractice_trial:
                exec('{} = thisPractice_trial[paramName]'.format(paramName))
        
        for thisPractice_trial in practice_trial:
            currentLoop = practice_trial
            # abbreviate parameter names if possible (e.g. rgb = thisPractice_trial.rgb)
            if thisPractice_trial != None:
                for paramName in thisPractice_trial:
                    exec('{} = thisPractice_trial[paramName]'.format(paramName))
            
            # ------Prepare to start Routine "break_2"-------
            routineTimer.add(2.500000)
            # update component parameters for each repeat
            minus.setPos((-Plus_x, -Plus_y))
            plus.setPos((Plus_x, Plus_y))
            # keep track of which components have finished
            break_2Components = [cross_fix, minus, plus, point_2]
            for thisComponent in break_2Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            break_2Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
            frameN = -1
            continueRoutine = True
            
            # -------Run Routine "break_2"-------
            while continueRoutine and routineTimer.getTime() > 0:
                # get current time
                t = break_2Clock.getTime()
                tThisFlip = win.getFutureFlipTime(clock=break_2Clock)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *cross_fix* updates
                if cross_fix.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                    # keep track of start time/frame for later
                    cross_fix.frameNStart = frameN  # exact frame index
                    cross_fix.tStart = t  # local t and not account for scr refresh
                    cross_fix.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(cross_fix, 'tStartRefresh')  # time at next scr refresh
                    cross_fix.setAutoDraw(True)
                if cross_fix.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > cross_fix.tStartRefresh + 1-frameTolerance:
                        # keep track of stop time/frame for later
                        cross_fix.tStop = t  # not accounting for scr refresh
                        cross_fix.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(cross_fix, 'tStopRefresh')  # time at next scr refresh
                        cross_fix.setAutoDraw(False)
                
                # *minus* updates
                if minus.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                    # keep track of start time/frame for later
                    minus.frameNStart = frameN  # exact frame index
                    minus.tStart = t  # local t and not account for scr refresh
                    minus.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(minus, 'tStartRefresh')  # time at next scr refresh
                    minus.setAutoDraw(True)
                if minus.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > minus.tStartRefresh + 1-frameTolerance:
                        # keep track of stop time/frame for later
                        minus.tStop = t  # not accounting for scr refresh
                        minus.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(minus, 'tStopRefresh')  # time at next scr refresh
                        minus.setAutoDraw(False)
                
                # *plus* updates
                if plus.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                    # keep track of start time/frame for later
                    plus.frameNStart = frameN  # exact frame index
                    plus.tStart = t  # local t and not account for scr refresh
                    plus.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(plus, 'tStartRefresh')  # time at next scr refresh
                    plus.setAutoDraw(True)
                if plus.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > plus.tStartRefresh + 1-frameTolerance:
                        # keep track of stop time/frame for later
                        plus.tStop = t  # not accounting for scr refresh
                        plus.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(plus, 'tStopRefresh')  # time at next scr refresh
                        plus.setAutoDraw(False)
                
                # *point_2* updates
                if point_2.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                    # keep track of start time/frame for later
                    point_2.frameNStart = frameN  # exact frame index
                    point_2.tStart = t  # local t and not account for scr refresh
                    point_2.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(point_2, 'tStartRefresh')  # time at next scr refresh
                    point_2.setAutoDraw(True)
                if point_2.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > point_2.tStartRefresh + 1.0-frameTolerance:
                        # keep track of stop time/frame for later
                        point_2.tStop = t  # not accounting for scr refresh
                        point_2.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(point_2, 'tStopRefresh')  # time at next scr refresh
                        point_2.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in break_2Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "break_2"-------
            for thisComponent in break_2Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            
            # ------Prepare to start Routine "PRIME"-------
            routineTimer.add(0.400000)
            # update component parameters for each repeat
            Prime_picture.setImage(priming)
            # keep track of which components have finished
            PRIMEComponents = [Prime_picture]
            for thisComponent in PRIMEComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            PRIMEClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
            frameN = -1
            continueRoutine = True
            
            # -------Run Routine "PRIME"-------
            while continueRoutine and routineTimer.getTime() > 0:
                # get current time
                t = PRIMEClock.getTime()
                tThisFlip = win.getFutureFlipTime(clock=PRIMEClock)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *Prime_picture* updates
                if Prime_picture.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    Prime_picture.frameNStart = frameN  # exact frame index
                    Prime_picture.tStart = t  # local t and not account for scr refresh
                    Prime_picture.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(Prime_picture, 'tStartRefresh')  # time at next scr refresh
                    Prime_picture.setAutoDraw(True)
                if Prime_picture.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > Prime_picture.tStartRefresh + 0.4-frameTolerance:
                        # keep track of stop time/frame for later
                        Prime_picture.tStop = t  # not accounting for scr refresh
                        Prime_picture.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(Prime_picture, 'tStopRefresh')  # time at next scr refresh
                        Prime_picture.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in PRIMEComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "PRIME"-------
            for thisComponent in PRIMEComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            
            # ------Prepare to start Routine "EXP2_experiment"-------
            # update component parameters for each repeat
            image_1.setPos((X1,Y1))
            image_1.setImage(IMG1)
            image_2.setPos((X2,Y2))
            image_2.setImage(IMG2)
            image_3.setPos((X3,Y3))
            image_3.setImage(IMG3)
            image_4.setPos((X4,Y4))
            image_4.setImage(IMG4)
            image_5.setPos((X5,Y5))
            image_5.setImage(IMG5)
            image_6.setPos((X6,Y6))
            image_6.setImage(IMG6)
            image_12.setPos((X7,Y7))
            image_12.setImage(IMG7)
            image8.setPos((X8,Y8))
            image8.setImage(IMG8)
            response.keys = []
            response.rt = []
            # keep track of which components have finished
            EXP2_experimentComponents = [fixation, image_1, image_2, image_3, image_4, image_5, image_6, image_12, image8, response]
            for thisComponent in EXP2_experimentComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            EXP2_experimentClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
            frameN = -1
            continueRoutine = True
            
            # -------Run Routine "EXP2_experiment"-------
            while continueRoutine:
                # get current time
                t = EXP2_experimentClock.getTime()
                tThisFlip = win.getFutureFlipTime(clock=EXP2_experimentClock)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *fixation* updates
                if fixation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    fixation.frameNStart = frameN  # exact frame index
                    fixation.tStart = t  # local t and not account for scr refresh
                    fixation.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(fixation, 'tStartRefresh')  # time at next scr refresh
                    fixation.setAutoDraw(True)
                if fixation.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > fixation.tStartRefresh + 6-frameTolerance:
                        # keep track of stop time/frame for later
                        fixation.tStop = t  # not accounting for scr refresh
                        fixation.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(fixation, 'tStopRefresh')  # time at next scr refresh
                        fixation.setAutoDraw(False)
                
                # *image_1* updates
                if image_1.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                    # keep track of start time/frame for later
                    image_1.frameNStart = frameN  # exact frame index
                    image_1.tStart = t  # local t and not account for scr refresh
                    image_1.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image_1, 'tStartRefresh')  # time at next scr refresh
                    image_1.setAutoDraw(True)
                if image_1.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image_1.tStartRefresh + time-frameTolerance:
                        # keep track of stop time/frame for later
                        image_1.tStop = t  # not accounting for scr refresh
                        image_1.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(image_1, 'tStopRefresh')  # time at next scr refresh
                        image_1.setAutoDraw(False)
                
                # *image_2* updates
                if image_2.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                    # keep track of start time/frame for later
                    image_2.frameNStart = frameN  # exact frame index
                    image_2.tStart = t  # local t and not account for scr refresh
                    image_2.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image_2, 'tStartRefresh')  # time at next scr refresh
                    image_2.setAutoDraw(True)
                if image_2.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image_2.tStartRefresh + time-frameTolerance:
                        # keep track of stop time/frame for later
                        image_2.tStop = t  # not accounting for scr refresh
                        image_2.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(image_2, 'tStopRefresh')  # time at next scr refresh
                        image_2.setAutoDraw(False)
                
                # *image_3* updates
                if image_3.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                    # keep track of start time/frame for later
                    image_3.frameNStart = frameN  # exact frame index
                    image_3.tStart = t  # local t and not account for scr refresh
                    image_3.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image_3, 'tStartRefresh')  # time at next scr refresh
                    image_3.setAutoDraw(True)
                if image_3.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image_3.tStartRefresh + time-frameTolerance:
                        # keep track of stop time/frame for later
                        image_3.tStop = t  # not accounting for scr refresh
                        image_3.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(image_3, 'tStopRefresh')  # time at next scr refresh
                        image_3.setAutoDraw(False)
                
                # *image_4* updates
                if image_4.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                    # keep track of start time/frame for later
                    image_4.frameNStart = frameN  # exact frame index
                    image_4.tStart = t  # local t and not account for scr refresh
                    image_4.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image_4, 'tStartRefresh')  # time at next scr refresh
                    image_4.setAutoDraw(True)
                if image_4.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image_4.tStartRefresh + time-frameTolerance:
                        # keep track of stop time/frame for later
                        image_4.tStop = t  # not accounting for scr refresh
                        image_4.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(image_4, 'tStopRefresh')  # time at next scr refresh
                        image_4.setAutoDraw(False)
                
                # *image_5* updates
                if image_5.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                    # keep track of start time/frame for later
                    image_5.frameNStart = frameN  # exact frame index
                    image_5.tStart = t  # local t and not account for scr refresh
                    image_5.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image_5, 'tStartRefresh')  # time at next scr refresh
                    image_5.setAutoDraw(True)
                if image_5.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image_5.tStartRefresh + time-frameTolerance:
                        # keep track of stop time/frame for later
                        image_5.tStop = t  # not accounting for scr refresh
                        image_5.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(image_5, 'tStopRefresh')  # time at next scr refresh
                        image_5.setAutoDraw(False)
                
                # *image_6* updates
                if image_6.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                    # keep track of start time/frame for later
                    image_6.frameNStart = frameN  # exact frame index
                    image_6.tStart = t  # local t and not account for scr refresh
                    image_6.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image_6, 'tStartRefresh')  # time at next scr refresh
                    image_6.setAutoDraw(True)
                if image_6.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image_6.tStartRefresh + time-frameTolerance:
                        # keep track of stop time/frame for later
                        image_6.tStop = t  # not accounting for scr refresh
                        image_6.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(image_6, 'tStopRefresh')  # time at next scr refresh
                        image_6.setAutoDraw(False)
                
                # *image_12* updates
                if image_12.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                    # keep track of start time/frame for later
                    image_12.frameNStart = frameN  # exact frame index
                    image_12.tStart = t  # local t and not account for scr refresh
                    image_12.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image_12, 'tStartRefresh')  # time at next scr refresh
                    image_12.setAutoDraw(True)
                if image_12.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image_12.tStartRefresh + time-frameTolerance:
                        # keep track of stop time/frame for later
                        image_12.tStop = t  # not accounting for scr refresh
                        image_12.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(image_12, 'tStopRefresh')  # time at next scr refresh
                        image_12.setAutoDraw(False)
                
                # *image8* updates
                if image8.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                    # keep track of start time/frame for later
                    image8.frameNStart = frameN  # exact frame index
                    image8.tStart = t  # local t and not account for scr refresh
                    image8.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image8, 'tStartRefresh')  # time at next scr refresh
                    image8.setAutoDraw(True)
                if image8.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image8.tStartRefresh + time-frameTolerance:
                        # keep track of stop time/frame for later
                        image8.tStop = t  # not accounting for scr refresh
                        image8.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(image8, 'tStopRefresh')  # time at next scr refresh
                        image8.setAutoDraw(False)
                
                # *response* updates
                waitOnFlip = False
                if response.status == NOT_STARTED and tThisFlip >= 1-frameTolerance:
                    # keep track of start time/frame for later
                    response.frameNStart = frameN  # exact frame index
                    response.tStart = t  # local t and not account for scr refresh
                    response.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(response, 'tStartRefresh')  # time at next scr refresh
                    response.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(response.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(response.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if response.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > response.tStartRefresh + 5-frameTolerance:
                        # keep track of stop time/frame for later
                        response.tStop = t  # not accounting for scr refresh
                        response.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(response, 'tStopRefresh')  # time at next scr refresh
                        response.status = FINISHED
                if response.status == STARTED and not waitOnFlip:
                    theseKeys = response.getKeys(keyList=['f', 'j'], waitRelease=False)
                    if len(theseKeys):
                        theseKeys = theseKeys[0]  # at least one key was pressed
                        
                        # check for quit:
                        if "escape" == theseKeys:
                            endExpNow = True
                        response.keys = theseKeys.name  # just the last key pressed
                        response.rt = theseKeys.rt
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in EXP2_experimentComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "EXP2_experiment"-------
            for thisComponent in EXP2_experimentComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # check responses
            if response.keys in ['', [], None]:  # No response was made
                response.keys = None
            practice_trial.addData('response.keys',response.keys)
            if response.keys != None:  # we had a response
                practice_trial.addData('response.rt', response.rt)
            # the Routine "EXP2_experiment" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
        # completed 1 repeats of 'practice_trial'
        
        # get names of stimulus parameters
        if practice_trial.trialList in ([], [None], None):
            params = []
        else:
            params = practice_trial.trialList[0].keys()
        # save data for this loop
        practice_trial.saveAsExcel(filename + '.xlsx', sheetName='practice_trial',
            stimOut=params,
            dataOut=['n','all_mean','all_std', 'all_raw'])
        thisExp.nextEntry()
        
    # completed 1 repeats of 'TRAINING_loop'
    
    # get names of stimulus parameters
    if TRAINING_loop.trialList in ([], [None], None):
        params = []
    else:
        params = TRAINING_loop.trialList[0].keys()
    # save data for this loop
    TRAINING_loop.saveAsExcel(filename + '.xlsx', sheetName='TRAINING_loop',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    
    # ------Prepare to start Routine "EXP2_START_2"-------
    # update component parameters for each repeat
    key_resp_10.keys = []
    key_resp_10.rt = []
    # keep track of which components have finished
    EXP2_START_2Components = [text_7, key_resp_10, text_8]
    for thisComponent in EXP2_START_2Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    EXP2_START_2Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    continueRoutine = True
    
    # -------Run Routine "EXP2_START_2"-------
    while continueRoutine:
        # get current time
        t = EXP2_START_2Clock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=EXP2_START_2Clock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_7* updates
        if text_7.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_7.frameNStart = frameN  # exact frame index
            text_7.tStart = t  # local t and not account for scr refresh
            text_7.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_7, 'tStartRefresh')  # time at next scr refresh
            text_7.setAutoDraw(True)
        
        # *key_resp_10* updates
        waitOnFlip = False
        if key_resp_10.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_10.frameNStart = frameN  # exact frame index
            key_resp_10.tStart = t  # local t and not account for scr refresh
            key_resp_10.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_10, 'tStartRefresh')  # time at next scr refresh
            key_resp_10.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(key_resp_10.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_10.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_10.getKeys(keyList=['space'], waitRelease=False)
            if len(theseKeys):
                theseKeys = theseKeys[0]  # at least one key was pressed
                
                # check for quit:
                if "escape" == theseKeys:
                    endExpNow = True
                # a response ends the routine
                continueRoutine = False
        
        # *text_8* updates
        if text_8.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_8.frameNStart = frameN  # exact frame index
            text_8.tStart = t  # local t and not account for scr refresh
            text_8.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_8, 'tStartRefresh')  # time at next scr refresh
            text_8.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in EXP2_START_2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "EXP2_START_2"-------
    for thisComponent in EXP2_START_2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "EXP2_START_2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    Experimental_trial = data.TrialHandler(nReps=1, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions(CondFiles_EXP),
        seed=None, name='Experimental_trial')
    thisExp.addLoop(Experimental_trial)  # add the loop to the experiment
    thisExperimental_trial = Experimental_trial.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisExperimental_trial.rgb)
    if thisExperimental_trial != None:
        for paramName in thisExperimental_trial:
            exec('{} = thisExperimental_trial[paramName]'.format(paramName))
    
    for thisExperimental_trial in Experimental_trial:
        currentLoop = Experimental_trial
        # abbreviate parameter names if possible (e.g. rgb = thisExperimental_trial.rgb)
        if thisExperimental_trial != None:
            for paramName in thisExperimental_trial:
                exec('{} = thisExperimental_trial[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "break_2"-------
        routineTimer.add(2.500000)
        # update component parameters for each repeat
        minus.setPos((-Plus_x, -Plus_y))
        plus.setPos((Plus_x, Plus_y))
        # keep track of which components have finished
        break_2Components = [cross_fix, minus, plus, point_2]
        for thisComponent in break_2Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        break_2Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        continueRoutine = True
        
        # -------Run Routine "break_2"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = break_2Clock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=break_2Clock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *cross_fix* updates
            if cross_fix.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                cross_fix.frameNStart = frameN  # exact frame index
                cross_fix.tStart = t  # local t and not account for scr refresh
                cross_fix.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(cross_fix, 'tStartRefresh')  # time at next scr refresh
                cross_fix.setAutoDraw(True)
            if cross_fix.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > cross_fix.tStartRefresh + 1-frameTolerance:
                    # keep track of stop time/frame for later
                    cross_fix.tStop = t  # not accounting for scr refresh
                    cross_fix.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(cross_fix, 'tStopRefresh')  # time at next scr refresh
                    cross_fix.setAutoDraw(False)
            
            # *minus* updates
            if minus.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                minus.frameNStart = frameN  # exact frame index
                minus.tStart = t  # local t and not account for scr refresh
                minus.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(minus, 'tStartRefresh')  # time at next scr refresh
                minus.setAutoDraw(True)
            if minus.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > minus.tStartRefresh + 1-frameTolerance:
                    # keep track of stop time/frame for later
                    minus.tStop = t  # not accounting for scr refresh
                    minus.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(minus, 'tStopRefresh')  # time at next scr refresh
                    minus.setAutoDraw(False)
            
            # *plus* updates
            if plus.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                plus.frameNStart = frameN  # exact frame index
                plus.tStart = t  # local t and not account for scr refresh
                plus.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(plus, 'tStartRefresh')  # time at next scr refresh
                plus.setAutoDraw(True)
            if plus.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > plus.tStartRefresh + 1-frameTolerance:
                    # keep track of stop time/frame for later
                    plus.tStop = t  # not accounting for scr refresh
                    plus.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(plus, 'tStopRefresh')  # time at next scr refresh
                    plus.setAutoDraw(False)
            
            # *point_2* updates
            if point_2.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                point_2.frameNStart = frameN  # exact frame index
                point_2.tStart = t  # local t and not account for scr refresh
                point_2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(point_2, 'tStartRefresh')  # time at next scr refresh
                point_2.setAutoDraw(True)
            if point_2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > point_2.tStartRefresh + 1.0-frameTolerance:
                    # keep track of stop time/frame for later
                    point_2.tStop = t  # not accounting for scr refresh
                    point_2.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(point_2, 'tStopRefresh')  # time at next scr refresh
                    point_2.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in break_2Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "break_2"-------
        for thisComponent in break_2Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        
        # ------Prepare to start Routine "PRIME"-------
        routineTimer.add(0.400000)
        # update component parameters for each repeat
        Prime_picture.setImage(priming)
        # keep track of which components have finished
        PRIMEComponents = [Prime_picture]
        for thisComponent in PRIMEComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        PRIMEClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        continueRoutine = True
        
        # -------Run Routine "PRIME"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = PRIMEClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=PRIMEClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *Prime_picture* updates
            if Prime_picture.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Prime_picture.frameNStart = frameN  # exact frame index
                Prime_picture.tStart = t  # local t and not account for scr refresh
                Prime_picture.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Prime_picture, 'tStartRefresh')  # time at next scr refresh
                Prime_picture.setAutoDraw(True)
            if Prime_picture.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > Prime_picture.tStartRefresh + 0.4-frameTolerance:
                    # keep track of stop time/frame for later
                    Prime_picture.tStop = t  # not accounting for scr refresh
                    Prime_picture.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(Prime_picture, 'tStopRefresh')  # time at next scr refresh
                    Prime_picture.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in PRIMEComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "PRIME"-------
        for thisComponent in PRIMEComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        
        # ------Prepare to start Routine "EXP2_experiment"-------
        # update component parameters for each repeat
        image_1.setPos((X1,Y1))
        image_1.setImage(IMG1)
        image_2.setPos((X2,Y2))
        image_2.setImage(IMG2)
        image_3.setPos((X3,Y3))
        image_3.setImage(IMG3)
        image_4.setPos((X4,Y4))
        image_4.setImage(IMG4)
        image_5.setPos((X5,Y5))
        image_5.setImage(IMG5)
        image_6.setPos((X6,Y6))
        image_6.setImage(IMG6)
        image_12.setPos((X7,Y7))
        image_12.setImage(IMG7)
        image8.setPos((X8,Y8))
        image8.setImage(IMG8)
        response.keys = []
        response.rt = []
        # keep track of which components have finished
        EXP2_experimentComponents = [fixation, image_1, image_2, image_3, image_4, image_5, image_6, image_12, image8, response]
        for thisComponent in EXP2_experimentComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        EXP2_experimentClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        continueRoutine = True
        
        # -------Run Routine "EXP2_experiment"-------
        while continueRoutine:
            # get current time
            t = EXP2_experimentClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=EXP2_experimentClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *fixation* updates
            if fixation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                fixation.frameNStart = frameN  # exact frame index
                fixation.tStart = t  # local t and not account for scr refresh
                fixation.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(fixation, 'tStartRefresh')  # time at next scr refresh
                fixation.setAutoDraw(True)
            if fixation.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > fixation.tStartRefresh + 6-frameTolerance:
                    # keep track of stop time/frame for later
                    fixation.tStop = t  # not accounting for scr refresh
                    fixation.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(fixation, 'tStopRefresh')  # time at next scr refresh
                    fixation.setAutoDraw(False)
            
            # *image_1* updates
            if image_1.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                image_1.frameNStart = frameN  # exact frame index
                image_1.tStart = t  # local t and not account for scr refresh
                image_1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_1, 'tStartRefresh')  # time at next scr refresh
                image_1.setAutoDraw(True)
            if image_1.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_1.tStartRefresh + time-frameTolerance:
                    # keep track of stop time/frame for later
                    image_1.tStop = t  # not accounting for scr refresh
                    image_1.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(image_1, 'tStopRefresh')  # time at next scr refresh
                    image_1.setAutoDraw(False)
            
            # *image_2* updates
            if image_2.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                image_2.frameNStart = frameN  # exact frame index
                image_2.tStart = t  # local t and not account for scr refresh
                image_2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_2, 'tStartRefresh')  # time at next scr refresh
                image_2.setAutoDraw(True)
            if image_2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_2.tStartRefresh + time-frameTolerance:
                    # keep track of stop time/frame for later
                    image_2.tStop = t  # not accounting for scr refresh
                    image_2.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(image_2, 'tStopRefresh')  # time at next scr refresh
                    image_2.setAutoDraw(False)
            
            # *image_3* updates
            if image_3.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                image_3.frameNStart = frameN  # exact frame index
                image_3.tStart = t  # local t and not account for scr refresh
                image_3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_3, 'tStartRefresh')  # time at next scr refresh
                image_3.setAutoDraw(True)
            if image_3.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_3.tStartRefresh + time-frameTolerance:
                    # keep track of stop time/frame for later
                    image_3.tStop = t  # not accounting for scr refresh
                    image_3.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(image_3, 'tStopRefresh')  # time at next scr refresh
                    image_3.setAutoDraw(False)
            
            # *image_4* updates
            if image_4.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                image_4.frameNStart = frameN  # exact frame index
                image_4.tStart = t  # local t and not account for scr refresh
                image_4.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_4, 'tStartRefresh')  # time at next scr refresh
                image_4.setAutoDraw(True)
            if image_4.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_4.tStartRefresh + time-frameTolerance:
                    # keep track of stop time/frame for later
                    image_4.tStop = t  # not accounting for scr refresh
                    image_4.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(image_4, 'tStopRefresh')  # time at next scr refresh
                    image_4.setAutoDraw(False)
            
            # *image_5* updates
            if image_5.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                image_5.frameNStart = frameN  # exact frame index
                image_5.tStart = t  # local t and not account for scr refresh
                image_5.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_5, 'tStartRefresh')  # time at next scr refresh
                image_5.setAutoDraw(True)
            if image_5.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_5.tStartRefresh + time-frameTolerance:
                    # keep track of stop time/frame for later
                    image_5.tStop = t  # not accounting for scr refresh
                    image_5.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(image_5, 'tStopRefresh')  # time at next scr refresh
                    image_5.setAutoDraw(False)
            
            # *image_6* updates
            if image_6.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                image_6.frameNStart = frameN  # exact frame index
                image_6.tStart = t  # local t and not account for scr refresh
                image_6.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_6, 'tStartRefresh')  # time at next scr refresh
                image_6.setAutoDraw(True)
            if image_6.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_6.tStartRefresh + time-frameTolerance:
                    # keep track of stop time/frame for later
                    image_6.tStop = t  # not accounting for scr refresh
                    image_6.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(image_6, 'tStopRefresh')  # time at next scr refresh
                    image_6.setAutoDraw(False)
            
            # *image_12* updates
            if image_12.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                image_12.frameNStart = frameN  # exact frame index
                image_12.tStart = t  # local t and not account for scr refresh
                image_12.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_12, 'tStartRefresh')  # time at next scr refresh
                image_12.setAutoDraw(True)
            if image_12.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_12.tStartRefresh + time-frameTolerance:
                    # keep track of stop time/frame for later
                    image_12.tStop = t  # not accounting for scr refresh
                    image_12.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(image_12, 'tStopRefresh')  # time at next scr refresh
                    image_12.setAutoDraw(False)
            
            # *image8* updates
            if image8.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                image8.frameNStart = frameN  # exact frame index
                image8.tStart = t  # local t and not account for scr refresh
                image8.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image8, 'tStartRefresh')  # time at next scr refresh
                image8.setAutoDraw(True)
            if image8.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image8.tStartRefresh + time-frameTolerance:
                    # keep track of stop time/frame for later
                    image8.tStop = t  # not accounting for scr refresh
                    image8.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(image8, 'tStopRefresh')  # time at next scr refresh
                    image8.setAutoDraw(False)
            
            # *response* updates
            waitOnFlip = False
            if response.status == NOT_STARTED and tThisFlip >= 1-frameTolerance:
                # keep track of start time/frame for later
                response.frameNStart = frameN  # exact frame index
                response.tStart = t  # local t and not account for scr refresh
                response.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(response, 'tStartRefresh')  # time at next scr refresh
                response.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(response.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(response.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if response.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > response.tStartRefresh + 5-frameTolerance:
                    # keep track of stop time/frame for later
                    response.tStop = t  # not accounting for scr refresh
                    response.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(response, 'tStopRefresh')  # time at next scr refresh
                    response.status = FINISHED
            if response.status == STARTED and not waitOnFlip:
                theseKeys = response.getKeys(keyList=['f', 'j'], waitRelease=False)
                if len(theseKeys):
                    theseKeys = theseKeys[0]  # at least one key was pressed
                    
                    # check for quit:
                    if "escape" == theseKeys:
                        endExpNow = True
                    response.keys = theseKeys.name  # just the last key pressed
                    response.rt = theseKeys.rt
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in EXP2_experimentComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "EXP2_experiment"-------
        for thisComponent in EXP2_experimentComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # check responses
        if response.keys in ['', [], None]:  # No response was made
            response.keys = None
        Experimental_trial.addData('response.keys',response.keys)
        if response.keys != None:  # we had a response
            Experimental_trial.addData('response.rt', response.rt)
        # the Routine "EXP2_experiment" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # ------Prepare to start Routine "Pauzeren_even"-------
        # update component parameters for each repeat
        if response.keys:
            continueRoutine = False 
        press_space_mate.keys = []
        press_space_mate.rt = []
        # keep track of which components have finished
        Pauzeren_evenComponents = [pauze_for_a_moment_mate, press_space_mate]
        for thisComponent in Pauzeren_evenComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        Pauzeren_evenClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        continueRoutine = True
        
        # -------Run Routine "Pauzeren_even"-------
        while continueRoutine:
            # get current time
            t = Pauzeren_evenClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=Pauzeren_evenClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *pauze_for_a_moment_mate* updates
            if pauze_for_a_moment_mate.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                pauze_for_a_moment_mate.frameNStart = frameN  # exact frame index
                pauze_for_a_moment_mate.tStart = t  # local t and not account for scr refresh
                pauze_for_a_moment_mate.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(pauze_for_a_moment_mate, 'tStartRefresh')  # time at next scr refresh
                pauze_for_a_moment_mate.setAutoDraw(True)
            
            # *press_space_mate* updates
            waitOnFlip = False
            if press_space_mate.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                press_space_mate.frameNStart = frameN  # exact frame index
                press_space_mate.tStart = t  # local t and not account for scr refresh
                press_space_mate.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(press_space_mate, 'tStartRefresh')  # time at next scr refresh
                press_space_mate.status = STARTED
                # keyboard checking is just starting
                win.callOnFlip(press_space_mate.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if press_space_mate.status == STARTED and not waitOnFlip:
                theseKeys = press_space_mate.getKeys(keyList=['space'], waitRelease=False)
                if len(theseKeys):
                    theseKeys = theseKeys[0]  # at least one key was pressed
                    
                    # check for quit:
                    if "escape" == theseKeys:
                        endExpNow = True
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Pauzeren_evenComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "Pauzeren_even"-------
        for thisComponent in Pauzeren_evenComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # the Routine "Pauzeren_even" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 1 repeats of 'Experimental_trial'
    
    # get names of stimulus parameters
    if Experimental_trial.trialList in ([], [None], None):
        params = []
    else:
        params = Experimental_trial.trialList[0].keys()
    # save data for this loop
    Experimental_trial.saveAsExcel(filename + '.xlsx', sheetName='Experimental_trial',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
# completed 1 repeats of 'Block_EXP2'


# ------Prepare to start Routine "End"-------
# update component parameters for each repeat
space_4.keys = []
space_4.rt = []
# keep track of which components have finished
EndComponents = [End_txt, space_4]
for thisComponent in EndComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
EndClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1
continueRoutine = True

# -------Run Routine "End"-------
while continueRoutine:
    # get current time
    t = EndClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=EndClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *End_txt* updates
    if End_txt.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        End_txt.frameNStart = frameN  # exact frame index
        End_txt.tStart = t  # local t and not account for scr refresh
        End_txt.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(End_txt, 'tStartRefresh')  # time at next scr refresh
        End_txt.setAutoDraw(True)
    
    # *space_4* updates
    waitOnFlip = False
    if space_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        space_4.frameNStart = frameN  # exact frame index
        space_4.tStart = t  # local t and not account for scr refresh
        space_4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(space_4, 'tStartRefresh')  # time at next scr refresh
        space_4.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(space_4.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if space_4.status == STARTED and not waitOnFlip:
        theseKeys = space_4.getKeys(keyList=['space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in EndComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "End"-------
for thisComponent in EndComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "End" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
